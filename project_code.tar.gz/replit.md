# مؤسسة محمد البلوي - نظام الإدارة والمالية

## Overview
This project is an administrative and financial management system designed for the Mohammed Al-Balawi Interior and Exterior Design Institute. Its primary purpose is to streamline project lifecycle management, financial tracking, and employee coordination for interior, exterior, and facade design projects. The system features a fully Arabic RTL interface, role-based access control, and aims to enhance operational efficiency, financial transparency, and client satisfaction. It manages everything from client acquisition and contract creation to project execution, payment processing, and employee compensation.

## User Preferences
I prefer clear, concise summaries for architectural decisions. I want the system to be robust and scalable, focusing on user experience, especially for the Arabic RTL interface. For financial calculations, accuracy and transparency are paramount. I prefer the agent to prioritize high-level features and design patterns over granular implementation details.

## System Architecture
The system employs a modern web stack:
- **Frontend**: React with Vite for fast development, `shadcn/ui` for UI components, `TanStack Query` for data fetching, and `wouter` for routing.
- **Backend**: Express.js with TypeScript for a robust and type-safe API.
- **Database**: PostgreSQL combined with Drizzle ORM for relational data management.
- **Authentication**: Session-based authentication using Passport.js (local strategy), `express-session`, and `connect-pg-simple` for session storage in PostgreSQL.
- **UI/UX**: Arabic RTL interface with a professional color scheme (`#2563EB` primary, dark sidebar, specific status colors). Project cards use color-coded right borders to indicate urgency.
- **Role-Based Access Control**: Three distinct roles (admin, employee, freelancer) with granular permissions for routing and API access. Routes are protected, and `/api/my/*` endpoints filter data based on the logged-in user's `employeeId`.
- **Contract-First Workflow**: A core design pattern where contract creation automatically triggers the setup of clients, projects, phases, and payments, ensuring data consistency and automation.
- **Flexible Payment Schedules**: Supports 1, 2, or 3 payment installments, customizable per project.
- **Project Lifecycle Management**: Detailed tracking of project phases with specific requirements (e.g., file upload before phase completion) and visual progress indicators. Phases are dynamically generated based on project type (interior, exterior, facades).
- **Financial Management**: Comprehensive tracking of revenue, VAT, salaries, commissions, and manual commitments to calculate net profit. Features include auto-calculation of employee commissions, salary deductions, and PDF export for payroll.
- **Notifications System**: Automated notifications for contract creation, phase completion, first payment overdue, and field visits.
- **Capacity & Availability Management**: Employees can set their availability, and admins have a matrix view. Capacity planning includes settings for project limits and rates.
- **Partners Management**: A `partners` table tracks profit-sharing partners (e.g., سمر البلوي 25%, مها البلوي 18%). Admin can add/edit/delete partners from the Salaries page. Each partner's profit share is calculated against the global net profit from `/api/reports/financial`.
- **Financial Reports**: Three new admin-only report tabs in the Reports page: (1) "كشف المصروفات" — expense breakdown with Excel (CSV) and PDF export; (2) "الإيرادات بالنوع" — revenue breakdown by project type (interior/exterior/facades), each with CSV+PDF export; (3) "تقرير الشركاء" — comprehensive partners overview with all revenue, expenses, net profit, and each partner's share, exportable as PDF.
- **Freelancer Bulk PDF**: A dedicated "PDF فريلانسرز" button on the Salaries page exports all freelancers' commissions for the selected month as a single PDF. Fixed to include all freelancers with assigned projects (not just those with totalCommission > 0).
- **Digital Signature on PDFs**: All salary PDF exports (individual, bulk, freelancer, monthly partners) include محمد البلوي's signature image from /signature.png in the stamp area.
- **Forgot Password Flow**: Login page has a "نسيت كلمة المرور؟" link that expands a form to send a reset email. Backend: POST /api/auth/forgot-password, POST /api/auth/reset-password. Uses nodemailer (SMTP_HOST/SMTP_PORT/SMTP_USER/SMTP_PASS env vars) or devMode fallback.
- **Reset Password Page**: Standalone page at /reset-password (accessible without login) for users clicking reset links. Accepts token via URL param.
- **Full User Management CRUD**: Admin-only page at /user-management with add, edit, delete users. Fields: name, username, password, email, role, linked employee. Routes: GET/POST/PUT/DELETE /api/users.
- **Freelancer Task Fee**: Tasks now have a `fee` numeric field for specifying freelancer compensation per task. Shown in the task creation/edit dialog.
- **bcryptjs**: Installed for password hashing in user creation and reset.
- **Reporting**: Advanced reporting with time period and city filters, employee ranking, and marketing insights.
- **AI-Powered Tools**: Includes a rule-based AI Project Estimator and a Price Quote tool that calculates suggested pricing, duration, and generates professional PDF quotes.
- **Integrated Tools**: Inline pricing tool in project details for dynamic adjustments, and a client pricing tool within contract creation for price suggestions based on area and project type.

## External Dependencies
- **PostgreSQL**: Primary database for all application data and session storage.
- **Passport.js**: Authentication middleware.
- **Express.js**: Backend web framework.
- **React**: Frontend library.
- **Vite**: Frontend build tool.
- **shadcn/ui**: UI component library.
- **TanStack Query**: Data fetching and state management.
- **wouter**: Frontend routing library.
- **Drizzle ORM**: Object-relational mapper for PostgreSQL.
- **IBM Plex Sans Arabic**: Custom font for Arabic text rendering.
- **Google Maps**: Integration for project locations and field visits (via `googleMapsUrl` field).