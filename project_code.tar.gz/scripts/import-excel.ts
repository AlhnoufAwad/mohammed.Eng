import XLSX from 'xlsx';
import { readFileSync } from 'fs';
import { Pool } from 'pg';
import { randomUUID } from 'crypto';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function excelDateToISO(serial: number): string | null {
  if (!serial || isNaN(serial) || serial < 30000) return null;
  const date = new Date(Math.round((serial - 25569) * 86400 * 1000));
  return date.toISOString().split('T')[0];
}

function mapProjectType(typeStr: string): 'interior' | 'exterior' | 'facades' {
  const t = typeStr.trim();
  if (t.includes('داخلي') || t.includes('شاليه')) return 'interior';
  if (t.includes('واجهة') || t.includes('واجهات') || t.includes('واجهه')) return 'facades';
  return 'exterior';
}

async function run() {
  const filePath = './attached_assets/2026نسخة_من_كشف_عملاء_التصميم_1774803811718.xlsx';
  const buf = readFileSync(filePath);
  const wb = XLSX.read(buf, { type: 'buffer' });

  const existingClientsRes = await pool.query('SELECT id, name FROM clients');
  const clientMap = new Map<string, string>(existingClientsRes.rows.map((r: any) => [r.name.trim(), r.id]));

  let clientsCreated = 0, projectsCreated = 0, paymentsCreated = 0;
  const projectByClientName = new Map<string, string[]>();

  const designSheets = ['كشف عملاء التصميم الخارجي ', 'كشف عملاء التصميم الداخلي'];

  for (const sheetName of designSheets) {
    const sheet = wb.Sheets[sheetName];
    if (!sheet) { console.log('Sheet not found:', sheetName); continue; }
    const data = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' }) as any[][];

    console.log(`Processing sheet: ${sheetName} (${data.length} rows)`);

    for (let i = 2; i < data.length; i++) {
      const row = data[i];
      if (!row || row.length === 0) continue;

      const employeeName = String(row[0] || '').trim();
      const clientName = String(row[1] || '').trim();
      const designType = String(row[2] || '').trim();
      const area = parseFloat(String(row[3])) || null;
      const contractDateSerial = typeof row[4] === 'number' && row[4] > 30000 ? row[4] : null;
      const durationDays = typeof row[5] === 'number' ? row[5] : null;
      const city = String(row[7] || '').trim() || null;
      const notes = String(row[16] || '').trim() || null;

      if (!clientName || clientName.length < 2) continue;
      if (employeeName.startsWith('شهر') || clientName.startsWith('شهر')) continue;
      if (!designType || designType.startsWith('شهر')) continue;

      // Get or create client
      let clientId = clientMap.get(clientName);
      if (!clientId) {
        const clientRes = await pool.query(
          'INSERT INTO clients (id, name, phone, city) VALUES ($1, $2, $3, $4) RETURNING id',
          [randomUUID(), clientName, '', city]
        );
        clientId = clientRes.rows[0].id;
        clientMap.set(clientName, clientId);
        clientsCreated++;
      }

      const projectType = mapProjectType(designType);
      const contractDate = contractDateSerial ? excelDateToISO(contractDateSerial) : null;
      const totalValue = area ? Math.round(area * 100) : 1000;

      const projectId = randomUUID();
      await pool.query(
        `INSERT INTO projects (id, client_id, project_type, title, area_sqm, total_value, start_date, location, status, execution_days, payment_schedule, current_phase)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'active', $9, 3, 1)`,
        [projectId, clientId, projectType, `${clientName} - ${designType}`, area, totalValue, contractDate, city, durationDays]
      );
      projectsCreated++;

      if (!projectByClientName.has(clientName)) projectByClientName.set(clientName, []);
      projectByClientName.get(clientName)!.push(projectId);
    }
  }

  // Import payments
  const paymentSheet = wb.Sheets['الدفعات'];
  if (paymentSheet) {
    const data = XLSX.utils.sheet_to_json(paymentSheet, { header: 1, defval: '' }) as any[][];
    console.log(`Processing payments sheet (${data.length} rows)`);

    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (!row || row.length === 0) continue;

      const clientName = String(row[0] || '').trim();
      if (!clientName || clientName.length < 2) continue;

      const p1Amount = parseFloat(String(row[2])) || 0;
      const p1Done = String(row[3] || '').trim() === 'تم';
      const p2Amount = parseFloat(String(row[4])) || 0;
      const p2Done = String(row[5] || '').trim() === 'تم';
      const p3Amount = parseFloat(String(row[6])) || 0;
      const p3Done = String(row[7] || '').trim() === 'تم';
      const total = parseFloat(String(row[10])) || 0;

      if (!total || total <= 0) continue;

      let projectId: string | null = null;
      if (projectByClientName.has(clientName)) {
        projectId = projectByClientName.get(clientName)![0];
      } else {
        for (const [name, ids] of projectByClientName.entries()) {
          if (name.includes(clientName) || clientName.includes(name.substring(0, 8))) {
            projectId = ids[0];
            break;
          }
        }
      }

      if (!projectId) continue;

      await pool.query('UPDATE projects SET total_value = $1 WHERE id = $2', [total, projectId]);

      const paymentTypes = ['first_payment', 'second_payment', 'third_payment'];
      const amounts = [p1Amount, p2Amount, p3Amount];
      const dones = [p1Done, p2Done, p3Done];
      const percentages = [50, 30, 20];

      for (let pi = 0; pi < 3; pi++) {
        if (amounts[pi] > 0) {
          await pool.query(
            'INSERT INTO payments (id, project_id, payment_number, amount, percentage, payment_type, status) VALUES ($1, $2, $3, $4, $5, $6, $7)',
            [randomUUID(), projectId, pi + 1, amounts[pi], percentages[pi], paymentTypes[pi], dones[pi] ? 'paid' : 'pending']
          );
          paymentsCreated++;
        }
      }
    }
  }

  console.log('\n✅ Import complete!');
  console.log(`   Clients created: ${clientsCreated}`);
  console.log(`   Projects created: ${projectsCreated}`);
  console.log(`   Payments created: ${paymentsCreated}`);

  await pool.end();
}

run().catch(err => {
  console.error('❌ Import error:', err.message);
  process.exit(1);
});
