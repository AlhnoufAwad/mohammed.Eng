import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("ar-SA", {
    style: "currency",
    currency: "SAR",
    minimumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return "—";
  try {
    return new Date(dateStr).toLocaleDateString("ar-SA");
  } catch {
    return dateStr;
  }
}

export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    active: "نشط",
    completed: "مكتمل",
    paused: "متوقف",
    cancelled: "ملغي",
    pending: "قيد الانتظار",
    in_progress: "جاري",
    paid: "مدفوع",
    overdue: "متأخر",
    interior: "تصميم داخلي",
    exterior: "تصميم خارجي",
    internal: "موظف داخلي",
    freelancer: "مستقل",
    low: "منخفض",
    medium: "متوسط",
    high: "عالي",
    present: "حاضر",
    absent: "غائب",
    late: "متأخر",
  };
  return labels[status] || status;
}

export function getProjectTypeLabel(type: string): string {
  if (type === "interior") return "تصميم داخلي";
  if (type === "facades") return "واجهات";
  return "تصميم خارجي";
}

export function getEmployeeTypeLabel(type: string): string {
  return type === "internal" ? "موظف داخلي" : "مستقل (فريلانسر)";
}

export function getDaysUntil(dateStr: string | null | undefined): number | null {
  if (!dateStr) return null;
  const now = new Date();
  const due = new Date(dateStr);
  const diff = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  return diff;
}

export function getStatusBadgeVariant(status: string): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "active":
    case "paid":
    case "completed":
      return "default";
    case "pending":
    case "in_progress":
      return "secondary";
    case "overdue":
    case "cancelled":
      return "destructive";
    default:
      return "outline";
  }
}
