import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Calculator, Brain, Clock, DollarSign, Ruler, Users, BarChart2, ArrowLeftRight, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

type EstimationResult = {
  areaSqm: number;
  projectType: string;
  sizeCategory: string;
  complexity: string;
  estimatedDays: number;
  estimatedWeeks: number;
  estimatedMonths: number;
  recommendedTeam: number;
  maxConcurrent: number;
  totalValue: number;
  pricePerSqm: number;
  payments: { first: number; second: number; third: number };
  phases: { name: string; days: number; percentage: number }[];
};

const complexityColors: Record<string, string> = {
  "بسيط": "bg-foreground/5 text-foreground border border-foreground/10",
  "متوسط": "bg-foreground/10 text-foreground border border-foreground/15",
  "معقد": "bg-foreground text-background",
};

const sizeColors: Record<string, string> = {
  "صغير": "bg-foreground/5 text-foreground border border-foreground/10",
  "متوسط": "bg-foreground/10 text-foreground border border-foreground/15",
  "كبير": "bg-foreground/20 text-foreground border border-foreground/20",
  "كبير جداً": "bg-foreground text-background",
};

export default function ProjectCalculator() {
  const { user } = useAuth();
  const [area, setArea] = useState("");
  const [type, setType] = useState("interior");
  const [customPrice, setCustomPrice] = useState("");
  const [result, setResult] = useState<EstimationResult | null>(null);

  const { data: capacity } = useQuery<any>({
    queryKey: ["/api/my/capacity"],
    enabled: user?.role !== "admin",
  });

  const estimateMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/tools/estimate", {
        areaSqm: parseFloat(area),
        projectType: type,
      });
      return res.json();
    },
    onSuccess: (data: EstimationResult) => {
      if (customPrice) {
        const price = parseFloat(customPrice);
        data.pricePerSqm = price;
        data.totalValue = data.areaSqm * price;
        data.payments = {
          first: data.totalValue * 0.5,
          second: data.totalValue * 0.3,
          third: data.totalValue * 0.2,
        };
      }
      setResult(data);
    },
  });

  const isLargeProject = parseFloat(area) > (capacity?.threshold || 300);
  const canTakeLarge = capacity?.canTakeLargeProject !== false;

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-3" data-testid="text-page-title">
          <Brain className="h-7 w-7" />
          أداة القياس الذكية
        </h1>
        <p className="text-muted-foreground">تقدير ذكي للمدة الزمنية والتكلفة وتقسيم الدفعات</p>
      </div>

      {capacity && !canTakeLarge && isLargeProject && (
        <Card className="border-orange-300 bg-orange-50">
          <CardContent className="pt-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-orange-600" />
            <div>
              <p className="font-medium text-orange-800">تنبيه: تجاوز الحد الأقصى للمشاريع الكبيرة</p>
              <p className="text-sm text-orange-700">لديك حالياً {capacity.largeActiveProjects} مشروع كبير من أصل {capacity.maxLargeProjects} كحد أقصى</p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Calculator className="h-5 w-5" />بيانات المشروع</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>المساحة (متر مربع)</Label>
              <Input
                type="number"
                value={area}
                onChange={e => setArea(e.target.value)}
                placeholder="مثال: 350"
                data-testid="input-area"
              />
            </div>
            <div className="space-y-2">
              <Label>نوع المشروع</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger data-testid="select-type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="interior">تصميم داخلي</SelectItem>
                  <SelectItem value="exterior">تصميم خارجي</SelectItem>
                  <SelectItem value="facades">واجهات</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>سعر المتر المخصص (اختياري)</Label>
              <Input
                type="number"
                value={customPrice}
                onChange={e => setCustomPrice(e.target.value)}
                placeholder="اتركه فارغاً للسعر الافتراضي"
                data-testid="input-custom-price"
              />
            </div>
            <Button
              className="w-full"
              disabled={!area || estimateMutation.isPending}
              onClick={() => estimateMutation.mutate()}
              data-testid="button-estimate"
            >
              {estimateMutation.isPending ? "جاري الحساب..." : "حساب التقدير الذكي"}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="lg:col-span-2 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Card>
                <CardContent className="pt-4 text-center">
                  <Ruler className="h-5 w-5 mx-auto text-foreground mb-1" />
                  <p className="text-xs text-muted-foreground">المساحة</p>
                  <p className="text-lg font-bold">{result.areaSqm} م²</p>
                  <Badge className={sizeColors[result.sizeCategory]} variant="secondary">{result.sizeCategory}</Badge>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <Clock className="h-5 w-5 mx-auto text-foreground mb-1" />
                  <p className="text-xs text-muted-foreground">المدة المقدرة</p>
                  <p className="text-lg font-bold">{result.estimatedDays} يوم</p>
                  <p className="text-xs text-muted-foreground">{result.estimatedWeeks} أسبوع / {result.estimatedMonths} شهر</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <Users className="h-5 w-5 mx-auto text-foreground mb-1" />
                  <p className="text-xs text-muted-foreground">الفريق الموصى</p>
                  <p className="text-lg font-bold">{result.recommendedTeam} أشخاص</p>
                  <Badge className={complexityColors[result.complexity]} variant="secondary">{result.complexity}</Badge>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 text-center">
                  <DollarSign className="h-5 w-5 mx-auto text-foreground mb-1" />
                  <p className="text-xs text-muted-foreground">القيمة الإجمالية</p>
                  <p className="text-lg font-bold">{formatCurrency(result.totalValue)}</p>
                  <p className="text-xs text-muted-foreground">{result.pricePerSqm} ر.س/م²</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader><CardTitle className="text-base flex items-center gap-2"><ArrowLeftRight className="h-4 w-4" />تقسيم الدفعات</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg border bg-foreground text-center">
                    <p className="text-xs text-background/60 mb-1">الدفعة الأولى (50%)</p>
                    <p className="text-lg font-bold text-background">{formatCurrency(result.payments.first)}</p>
                    <p className="text-xs text-background/50 mt-1">عند توقيع العقد</p>
                  </div>
                  <div className="p-4 rounded-lg border bg-foreground/80 text-center">
                    <p className="text-xs text-background/60 mb-1">الدفعة الثانية (30%)</p>
                    <p className="text-lg font-bold text-background">{formatCurrency(result.payments.second)}</p>
                    <p className="text-xs text-background/50 mt-1">عند اعتماد الهيكل</p>
                  </div>
                  <div className="p-4 rounded-lg border bg-foreground/60 text-center">
                    <p className="text-xs text-background/70 mb-1">الدفعة الثالثة (20%)</p>
                    <p className="text-lg font-bold text-background">{formatCurrency(result.payments.third)}</p>
                    <p className="text-xs text-background/50 mt-1">عند اعتماد التصميم</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-base flex items-center gap-2"><BarChart2 className="h-4 w-4" />الجدول الزمني للمراحل</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {result.phases.map((phase, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{phase.name}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">{phase.days} يوم</span>
                        <span className="text-xs font-medium">{phase.percentage}%</span>
                      </div>
                    </div>
                    <Progress value={phase.percentage} className="h-2" />
                  </div>
                ))}
                <Separator className="my-3" />
                <div className="flex items-center justify-between font-medium">
                  <span>الإجمالي</span>
                  <span>{result.estimatedDays} يوم عمل</span>
                </div>
              </CardContent>
            </Card>

            {capacity && (
              <Card>
                <CardHeader><CardTitle className="text-base">تحليل القدرة الاستيعابية</CardTitle></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-sm text-muted-foreground">مشاريعي النشطة</p>
                      <p className="text-xl font-bold">{capacity.activeProjects}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">مشاريع كبيرة نشطة</p>
                      <p className="text-xl font-bold">{capacity.largeActiveProjects}/{capacity.maxLargeProjects}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">الحد الأقصى للتزامن</p>
                      <p className="text-xl font-bold">{result.maxConcurrent}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
