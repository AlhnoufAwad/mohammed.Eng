import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { formatCurrency, getStatusLabel, getProjectTypeLabel } from "@/lib/utils";
import type { Project, Client, Employee, Task, Payment } from "@shared/schema";
import { TrendingUp, FolderOpen, Users, CheckSquare, DollarSign, Calendar, Filter, Download, FileText, Star } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

function escapeHtml(str: string): string {
  return (str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function fmtN(n: number): string {
  return Math.round(n).toLocaleString("ar-SA");
}

interface FinancialReport {
  totalRevenue: number;
  totalVat: number;
  revenueAfterVat: number;
  netProfit: number;
  revenueByType: { interior: number; exterior: number; facades: number };
  projectsByType: { interior: ProjectSummary[]; exterior: ProjectSummary[]; facades: ProjectSummary[] };
  expenses: {
    baseSalaries: number;
    commissions: number;
    freelancerCosts: number;
    commitments: number;
    commitmentDetails: Array<{ id: string; title: string; amount: number; month?: string }>;
    total: number;
  };
  partnersSummary: Array<{ id: string; name: string; profitPercentage: number; shareAmount: number; isActive: boolean }>;
}

interface ProjectSummary {
  id: string;
  title: string;
  clientName: string;
  type: string;
  totalValue: number;
  paidRevenue: number;
  pendingRevenue: number;
  freelancerCosts: number;
  status: string;
  endDate?: string | null;
}

function exportExpensesCSV(data: FinancialReport) {
  const bom = "\uFEFF";
  const rows = [
    ["البند", "المبلغ (ر.س)"],
    ["الرواتب الأساسية", Math.round(data.expenses.baseSalaries)],
    ["العمولات", Math.round(data.expenses.commissions)],
    ["تكاليف الفريلانسرز", Math.round(data.expenses.freelancerCosts)],
    ["الالتزامات المالية", Math.round(data.expenses.commitments)],
    ["إجمالي المصروفات", Math.round(data.expenses.total)],
    [],
    ["تفاصيل الالتزامات", ""],
    ...data.expenses.commitmentDetails.map(c => [c.title, Math.round(c.amount)]),
  ];
  const csv = bom + rows.map(r => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = "كشف_المصروفات.csv"; a.click();
  URL.revokeObjectURL(url);
}

function exportExpensesPDF(data: FinancialReport) {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;
  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const rows = [
    { label: "الرواتب الأساسية", amount: data.expenses.baseSalaries, cls: "" },
    { label: "العمولات", amount: data.expenses.commissions, cls: "" },
    { label: "تكاليف الفريلانسرز", amount: data.expenses.freelancerCosts, cls: "" },
    { label: "الالتزامات المالية", amount: data.expenses.commitments, cls: "" },
  ];
  const tableRows = rows.map(r => `<tr><td>${escapeHtml(r.label)}</td><td>${fmtN(r.amount)} ر.س</td></tr>`).join("");
  const detailRows = data.expenses.commitmentDetails.map(c => `<tr><td>${escapeHtml(c.title)}</td><td>${fmtN(c.amount)} ر.س</td><td>${escapeHtml(c.month || "—")}</td></tr>`).join("");
  printWindow.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">
<title>كشف المصروفات</title>
<style>@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'IBM Plex Sans Arabic',sans-serif;background:#fff;color:#111;padding:32px;direction:rtl;}
.header{text-align:center;margin-bottom:24px;border-bottom:3px solid #2563EB;padding-bottom:16px;}
.header h1{font-size:22px;font-weight:700;color:#1e3a8a;}.header h2{font-size:16px;color:#2563EB;margin-top:4px;}
table{width:100%;border-collapse:collapse;font-size:12px;margin-top:16px;}
th{background:#2563EB;color:#fff;padding:8px 10px;font-weight:600;}
td{padding:7px 10px;border-bottom:1px solid #e5e7eb;}
.total-row{background:#fee2e2 !important;font-weight:700;}
.section-title{font-size:14px;font-weight:700;margin:20px 0 8px;color:#1e3a8a;}
.footer{text-align:center;margin-top:24px;font-size:11px;color:#6b7280;border-top:1px solid #e5e7eb;padding-top:12px;}
.btn-print{display:block;margin:16px auto;padding:10px 28px;background:#2563EB;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;}
@media print{.btn-print{display:none;}}</style></head><body>
<div class="header"><h1>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</h1><h2>كشف المصروفات</h2></div>
<p class="section-title">ملخص المصروفات</p>
<table><thead><tr><th>البند</th><th>المبلغ</th></tr></thead><tbody>${tableRows}
<tr class="total-row"><td>إجمالي المصروفات</td><td>${fmtN(data.expenses.total)} ر.س</td></tr>
</tbody></table>
${detailRows ? `<p class="section-title">تفاصيل الالتزامات المالية</p>
<table><thead><tr><th>الالتزام</th><th>المبلغ</th><th>الشهر</th></tr></thead><tbody>${detailRows}</tbody></table>` : ""}
<div class="footer">تم الطباعة بتاريخ ${today}</div>
<button class="btn-print" onclick="window.print()">طباعة / تصدير PDF</button>
</body></html>`);
  printWindow.document.close();
}

function exportRevenueByTypePDF(data: FinancialReport, type: "interior" | "exterior" | "facades") {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;
  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const typeLabel = type === "interior" ? "تصميم داخلي" : type === "exterior" ? "تصميم خارجي" : "واجهات";
  const projects = data.projectsByType[type] || [];
  const totalPaid = projects.reduce((s, p) => s + p.paidRevenue, 0);
  const totalValue = projects.reduce((s, p) => s + p.totalValue, 0);
  const rows = projects.map((p, idx) => `<tr>
    <td>${idx + 1}</td>
    <td>${escapeHtml(p.title)}</td>
    <td>${escapeHtml(p.clientName)}</td>
    <td>${fmtN(p.totalValue)} ر.س</td>
    <td>${fmtN(p.paidRevenue)} ر.س</td>
    <td>${fmtN(p.pendingRevenue)} ر.س</td>
    <td>${fmtN(p.freelancerCosts)} ر.س</td>
    <td>${escapeHtml(p.status === "completed" ? "مكتمل" : p.status === "active" ? "نشط" : p.status === "paused" ? "متوقف" : p.status)}</td>
  </tr>`).join("");
  printWindow.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">
<title>تقرير الإيرادات - ${typeLabel}</title>
<style>@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'IBM Plex Sans Arabic',sans-serif;background:#fff;color:#111;padding:32px;direction:rtl;}
.header{text-align:center;margin-bottom:24px;border-bottom:3px solid #2563EB;padding-bottom:16px;}
.header h1{font-size:22px;font-weight:700;color:#1e3a8a;}.header h2{font-size:16px;color:#2563EB;margin-top:4px;}
table{width:100%;border-collapse:collapse;font-size:11px;margin-top:16px;}
th{background:#2563EB;color:#fff;padding:8px 6px;font-weight:600;font-size:11px;}
td{padding:6px 6px;border-bottom:1px solid #e5e7eb;font-size:11px;}
.total-row{background:#dbeafe !important;font-weight:700;}
.footer{text-align:center;margin-top:24px;font-size:11px;color:#6b7280;border-top:1px solid #e5e7eb;padding-top:12px;}
.btn-print{display:block;margin:16px auto;padding:10px 28px;background:#2563EB;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;}
@media print{.btn-print{display:none;}}</style></head><body>
<div class="header"><h1>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</h1><h2>تقرير الإيرادات — ${typeLabel} (${projects.length} مشروع)</h2></div>
<table><thead><tr><th>#</th><th>المشروع</th><th>العميل</th><th>القيمة الإجمالية</th><th>المحصل</th><th>المتبقي</th><th>تكاليف فريلانسر</th><th>الحالة</th></tr></thead>
<tbody>${rows}
<tr class="total-row"><td colspan="3">الإجمالي</td><td>${fmtN(totalValue)} ر.س</td><td>${fmtN(totalPaid)} ر.س</td><td>${fmtN(totalValue - totalPaid)} ر.س</td><td></td><td></td></tr>
</tbody></table>
<div class="footer">تم الطباعة بتاريخ ${today}</div>
<button class="btn-print" onclick="window.print()">طباعة / تصدير PDF</button>
</body></html>`);
  printWindow.document.close();
}

function exportRevenueByTypeCSV(data: FinancialReport, type: "interior" | "exterior" | "facades") {
  const bom = "\uFEFF";
  const typeLabel = type === "interior" ? "داخلي" : type === "exterior" ? "خارجي" : "واجهات";
  const projects = data.projectsByType[type] || [];
  const rows = [
    ["المشروع", "العميل", "القيمة الإجمالية", "المحصل", "المتبقي", "تكاليف فريلانسر", "الحالة"],
    ...projects.map(p => [p.title, p.clientName, Math.round(p.totalValue), Math.round(p.paidRevenue), Math.round(p.pendingRevenue), Math.round(p.freelancerCosts), p.status]),
  ];
  const csv = bom + rows.map(r => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = `إيرادات_${typeLabel}.csv`; a.click();
  URL.revokeObjectURL(url);
}

function exportPartnersReportPDF(data: FinancialReport) {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;
  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const partnerRows = data.partnersSummary.filter(p => p.isActive).map((p, idx) => `<tr>
    <td>${idx + 1}</td>
    <td><strong>${escapeHtml(p.name)}</strong></td>
    <td>${p.profitPercentage}%</td>
    <td style="font-weight:700;color:#16a34a">${fmtN(p.shareAmount)} ر.س</td>
  </tr>`).join("");
  const totalShares = data.partnersSummary.filter(p => p.isActive).reduce((s, p) => s + p.shareAmount, 0);
  const typeRows = [
    { label: "تصميم داخلي", amount: data.revenueByType.interior, count: data.projectsByType.interior.length },
    { label: "تصميم خارجي", amount: data.revenueByType.exterior, count: data.projectsByType.exterior.length },
    { label: "واجهات", amount: data.revenueByType.facades, count: data.projectsByType.facades.length },
  ].map(r => `<tr><td>${r.label}</td><td>${r.count} مشروع</td><td>${fmtN(r.amount)} ر.س</td></tr>`).join("");
  printWindow.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">
<title>تقرير الشركاء</title>
<style>@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'IBM Plex Sans Arabic',sans-serif;background:#fff;color:#111;padding:32px;direction:rtl;}
.header{text-align:center;margin-bottom:24px;border-bottom:3px solid #2563EB;padding-bottom:16px;}
.header h1{font-size:22px;font-weight:700;color:#1e3a8a;}.header h2{font-size:16px;color:#2563EB;margin-top:4px;}
.kpi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:16px 0;}
.kpi-box{border:1px solid #e5e7eb;border-radius:8px;padding:12px;text-align:center;}
.kpi-box .value{font-size:18px;font-weight:700;color:#2563EB;}.kpi-box .label{font-size:11px;color:#6b7280;margin-top:4px;}
table{width:100%;border-collapse:collapse;font-size:12px;margin-top:12px;}
th{background:#2563EB;color:#fff;padding:8px 10px;font-weight:600;}
td{padding:7px 10px;border-bottom:1px solid #e5e7eb;}
.total-row{background:#dbeafe !important;font-weight:700;}
.section-title{font-size:14px;font-weight:700;margin:20px 0 8px;color:#1e3a8a;}
.footer{text-align:center;margin-top:24px;font-size:11px;color:#6b7280;border-top:1px solid #e5e7eb;padding-top:12px;}
.btn-print{display:block;margin:16px auto;padding:10px 28px;background:#2563EB;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;}
@media print{.btn-print{display:none;}}</style></head><body>
<div class="header"><h1>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</h1><h2>تقرير الشركاء والأرباح الشاملة</h2></div>
<div class="kpi-grid">
  <div class="kpi-box"><div class="value">${fmtN(data.totalRevenue)} ر.س</div><div class="label">إجمالي الإيرادات</div></div>
  <div class="kpi-box"><div class="value">${fmtN(data.expenses.total)} ر.س</div><div class="label">إجمالي المصروفات</div></div>
  <div class="kpi-box"><div class="value" style="color:#16a34a">${fmtN(data.netProfit)} ر.س</div><div class="label">صافي الربح</div></div>
</div>
<p class="section-title">الإيرادات حسب نوع المشروع</p>
<table><thead><tr><th>النوع</th><th>عدد المشاريع</th><th>الإيرادات المحصلة</th></tr></thead>
<tbody>${typeRows}</tbody></table>
<p class="section-title">ملخص المصروفات</p>
<table><thead><tr><th>البند</th><th>المبلغ</th></tr></thead><tbody>
<tr><td>الرواتب الأساسية</td><td>${fmtN(data.expenses.baseSalaries)} ر.س</td></tr>
<tr><td>العمولات</td><td>${fmtN(data.expenses.commissions)} ر.س</td></tr>
<tr><td>تكاليف الفريلانسرز</td><td>${fmtN(data.expenses.freelancerCosts)} ر.س</td></tr>
<tr><td>الالتزامات المالية</td><td>${fmtN(data.expenses.commitments)} ر.س</td></tr>
<tr class="total-row"><td>الإجمالي</td><td>${fmtN(data.expenses.total)} ر.س</td></tr>
</tbody></table>
<p class="section-title">حصص الشركاء</p>
<table><thead><tr><th>#</th><th>الشريك</th><th>نسبة الربح</th><th>حصة الربح</th></tr></thead>
<tbody>${partnerRows}
<tr class="total-row"><td colspan="3">إجمالي حصص الشركاء</td><td>${fmtN(totalShares)} ر.س</td></tr>
</tbody></table>
<div class="footer">تم الطباعة بتاريخ ${today}</div>
<button class="btn-print" onclick="window.print()">طباعة / تصدير PDF</button>
</body></html>`);
  printWindow.document.close();
}

const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];

function getDateRange(period: string): { start: Date; end: Date } {
  const now = new Date();
  const end = new Date(now);
  let start = new Date(now);
  switch (period) {
    case "week":
      start.setDate(now.getDate() - 7);
      break;
    case "month":
      start.setMonth(now.getMonth() - 1);
      break;
    case "quarter":
      start.setMonth(now.getMonth() - 3);
      break;
    case "year":
      start.setFullYear(now.getFullYear() - 1);
      break;
    default:
      start = new Date(2020, 0, 1);
  }
  return { start, end };
}

function isInRange(dateStr: string | null | undefined, range: { start: Date; end: Date }, period: string): boolean {
  if (!dateStr) return period === "all";
  const d = new Date(dateStr);
  return d >= range.start && d <= range.end;
}

export default function Reports() {
  const { user } = useAuth();
  const [timePeriod, setTimePeriod] = useState("all");
  const [cityFilter, setCityFilter] = useState("all");

  const { data: projects = [], isLoading: pLoading } = useQuery<Project[]>({ queryKey: ["/api/projects"] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const { data: tasks = [] } = useQuery<Task[]>({ queryKey: ["/api/tasks"] });
  const { data: payments = [] } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });
  const { data: financialData, isLoading: fLoading } = useQuery<FinancialReport>({
    queryKey: ["/api/reports/financial"],
    enabled: user?.role === "admin",
  });

  const dateRange = useMemo(() => getDateRange(timePeriod), [timePeriod]);

  const allCities = useMemo(() => {
    const cities = new Set<string>();
    projects.forEach(p => {
      if (p.location) cities.add(p.location.split(",")[0].trim());
    });
    return Array.from(cities).sort();
  }, [projects]);

  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      const inTime = isInRange(p.startDate, dateRange, timePeriod);
      const inCity = cityFilter === "all" || (p.location && p.location.split(",")[0].trim() === cityFilter);
      return inTime && inCity;
    });
  }, [projects, dateRange, cityFilter, timePeriod]);

  const filteredPayments = useMemo(() => {
    const projectIds = new Set(filteredProjects.map(p => p.id));
    return payments.filter(p => projectIds.has(p.projectId));
  }, [payments, filteredProjects]);

  const filteredTasks = useMemo(() => {
    const projectIds = new Set(filteredProjects.map(p => p.id));
    return tasks.filter(t => !t.projectId || projectIds.has(t.projectId));
  }, [tasks, filteredProjects]);

  const totalRevenue = filteredPayments.filter(p => p.status === "paid").reduce((s, p) => s + p.amount, 0);
  const totalContractValue = filteredProjects.reduce((s, p) => s + p.totalValue, 0);
  const completedProjects = filteredProjects.filter(p => p.status === "completed");
  const activeProjects = filteredProjects.filter(p => p.status === "active");

  const projectsByType = [
    { name: "خارجي", value: filteredProjects.filter(p => p.projectType === "exterior").length },
    { name: "داخلي", value: filteredProjects.filter(p => p.projectType === "interior").length },
  ].filter(d => d.value > 0);

  const projectsByStatus = [
    { name: "نشط", value: activeProjects.length },
    { name: "مكتمل", value: completedProjects.length },
    { name: "متوقف", value: filteredProjects.filter(p => p.status === "paused").length },
    { name: "ملغي", value: filteredProjects.filter(p => p.status === "cancelled").length },
  ].filter(d => d.value > 0);

  const taskStats = [
    { name: "معلقة", value: filteredTasks.filter(t => t.status === "pending").length },
    { name: "جارية", value: filteredTasks.filter(t => t.status === "in_progress").length },
    { name: "مكتملة", value: filteredTasks.filter(t => t.status === "completed").length },
  ];

  const revenueByProject = filteredProjects.slice(0, 8).map(p => ({
    name: p.title.substring(0, 12) + (p.title.length > 12 ? "..." : ""),
    قيمة: p.totalValue,
    محصل: filteredPayments.filter(pay => pay.projectId === p.id && pay.status === "paid").reduce((s, pay) => s + pay.amount, 0),
  }));

  const employeeTaskPerformance = employees.map(e => {
    const empTasks = filteredTasks.filter(t => t.employeeId === e.id);
    const completed = empTasks.filter(t => t.status === "completed").length;
    return {
      name: e.name.split(" ")[0],
      fullName: e.name,
      specialty: e.specialty,
      مهام: empTasks.length,
      مكتملة: completed,
      rate: empTasks.length > 0 ? Math.round((completed / empTasks.length) * 100) : 0,
    };
  }).filter(e => e.مهام > 0).sort((a, b) => b.rate - a.rate).slice(0, 10);

  const cityDistribution = filteredProjects.reduce((acc: Record<string, { count: number; value: number }>, p) => {
    const city = p.location ? p.location.split(",")[0].trim() : "غير محدد";
    if (!acc[city]) acc[city] = { count: 0, value: 0 };
    acc[city].count += 1;
    acc[city].value += p.totalValue;
    return acc;
  }, {});

  const cityData = Object.entries(cityDistribution)
    .map(([name, data]) => ({ name, count: data.count, value: data.value }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  const monthlyRevenue = useMemo(() => {
    const months: Record<string, { month: string; revenue: number; contracts: number }> = {};
    filteredPayments.filter(p => p.status === "paid" && p.paidDate).forEach(p => {
      const d = new Date(p.paidDate!);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleDateString("ar-SA", { month: "short", year: "numeric" });
      if (!months[key]) months[key] = { month: label, revenue: 0, contracts: 0 };
      months[key].revenue += p.amount;
      months[key].contracts += 1;
    });
    return Object.entries(months).sort(([a], [b]) => a.localeCompare(b)).map(([, v]) => v).slice(-12);
  }, [filteredPayments]);

  if (pLoading) return (
    <div className="p-6">
      <Skeleton className="h-8 w-48 mb-6" />
      <div className="grid grid-cols-2 gap-4 mb-6">
        {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
      </div>
    </div>
  );

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-reports-title">التقارير</h1>
          <p className="text-muted-foreground text-sm mt-1">تحليلات شاملة لأداء المؤسسة</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <Select value={timePeriod} onValueChange={setTimePeriod}>
              <SelectTrigger className="w-[130px] h-8 text-xs" data-testid="select-time-period">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                <SelectItem value="week">آخر أسبوع</SelectItem>
                <SelectItem value="month">آخر شهر</SelectItem>
                <SelectItem value="quarter">آخر 3 أشهر</SelectItem>
                <SelectItem value="year">آخر سنة</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-1.5">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={cityFilter} onValueChange={setCityFilter}>
              <SelectTrigger className="w-[130px] h-8 text-xs" data-testid="select-city-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل المدن</SelectItem>
                {allCities.map(city => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {(timePeriod !== "all" || cityFilter !== "all") && (
            <Badge variant="secondary" className="text-xs cursor-pointer" onClick={() => { setTimePeriod("all"); setCityFilter("all"); }} data-testid="button-clear-filters">
              مسح الفلاتر
            </Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: "إجمالي قيمة العقود", value: formatCurrency(totalContractValue), icon: DollarSign },
          { label: "الإيرادات المحصلة", value: formatCurrency(totalRevenue), icon: TrendingUp },
          { label: "مشاريع مكتملة", value: `${completedProjects.length} / ${filteredProjects.length}`, icon: FolderOpen },
          { label: "مهام منجزة", value: `${filteredTasks.filter(t => t.status === "completed").length} / ${filteredTasks.length}`, icon: CheckSquare },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-md bg-foreground/5">
                  <stat.icon className="h-4 w-4 text-foreground/70" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="font-bold text-sm mt-0.5" data-testid={`report-stat-${stat.label}`}>{stat.value}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="projects" dir="rtl">
        <TabsList className="mb-4 flex-wrap h-auto gap-1">
          <TabsTrigger value="projects" data-testid="tab-report-projects">تقرير المشاريع</TabsTrigger>
          <TabsTrigger value="finance" data-testid="tab-report-finance">تقرير مالي</TabsTrigger>
          <TabsTrigger value="employees" data-testid="tab-report-employees">تقرير الموظفين</TabsTrigger>
          <TabsTrigger value="geography" data-testid="tab-report-geography">التوزيع الجغرافي</TabsTrigger>
          <TabsTrigger value="marketing" data-testid="tab-report-marketing">الاستهداف التسويقي</TabsTrigger>
          {user?.role === "admin" && (
            <>
              <TabsTrigger value="expenses" data-testid="tab-report-expenses">كشف المصروفات</TabsTrigger>
              <TabsTrigger value="revenue-type" data-testid="tab-report-revenue-type">الإيرادات بالنوع</TabsTrigger>
              <TabsTrigger value="partners-report" data-testid="tab-report-partners">تقرير الشركاء</TabsTrigger>
              <TabsTrigger value="projects-by-month" data-testid="tab-report-projects-by-month">المشاريع بالشهر</TabsTrigger>
            </>
          )}
        </TabsList>

        <TabsContent value="projects">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">توزيع المشاريع حسب النوع</CardTitle></CardHeader>
              <CardContent>
                {projectsByType.length > 0 ? (
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={projectsByType} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                        {projectsByType.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                ) : <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">لا توجد بيانات</div>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">حالات المشاريع</CardTitle></CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={projectsByStatus}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                    <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                    <Tooltip />
                    <Bar dataKey="value" name="عدد المشاريع" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader className="pb-2"><CardTitle className="text-sm">قائمة المشاريع المكتملة</CardTitle></CardHeader>
              <CardContent>
                {completedProjects.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">لا توجد مشاريع مكتملة بعد</div>
                ) : (
                  <div className="space-y-2">
                    {completedProjects.map(p => {
                      const client = clients.find(c => c.id === p.clientId);
                      return (
                        <div key={p.id} className="flex items-center justify-between gap-3 p-3 border border-border rounded-md" data-testid={`row-completed-project-${p.id}`}>
                          <div>
                            <p className="text-sm font-medium">{p.title}</p>
                            <p className="text-xs text-muted-foreground">{client?.name} • {getProjectTypeLabel(p.projectType)} • {p.location || "غير محدد"}</p>
                          </div>
                          <span className="font-bold text-primary text-sm">{formatCurrency(p.totalValue)}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="finance">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="lg:col-span-2">
              <CardHeader className="pb-2"><CardTitle className="text-sm">مقارنة القيمة المحصلة بالإجمالي لكل مشروع</CardTitle></CardHeader>
              <CardContent>
                {revenueByProject.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={revenueByProject}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} />
                      <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                      <Tooltip formatter={(v: any) => formatCurrency(v)} />
                      <Bar dataKey="قيمة" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="محصل" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : <div className="text-center py-12 text-muted-foreground text-sm">لا توجد بيانات مالية</div>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">ملخص مالي</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[
                  { label: "إجمالي قيمة العقود", value: totalContractValue },
                  { label: "المبالغ المحصلة", value: totalRevenue },
                  { label: "المبالغ المعلقة", value: filteredPayments.filter(p => p.status === "pending").reduce((s, p) => s + p.amount, 0) },
                  { label: "المبالغ المتأخرة", value: filteredPayments.filter(p => p.status === "overdue").reduce((s, p) => s + p.amount, 0) },
                ].map(item => (
                  <div key={item.label} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <span className="text-sm text-muted-foreground">{item.label}</span>
                    <span className="text-sm font-bold">{formatCurrency(item.value)}</span>
                  </div>
                ))}
                <div className="pt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">نسبة التحصيل</span>
                    <span className="text-sm font-bold text-primary">
                      {totalContractValue > 0 ? `${((totalRevenue / totalContractValue) * 100).toFixed(1)}%` : "0%"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">حالة المهام</CardTitle></CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={taskStats.filter(t => t.value > 0)} cx="50%" cy="50%" outerRadius={70} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                      {taskStats.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {monthlyRevenue.length > 0 && (
              <Card className="lg:col-span-2">
                <CardHeader className="pb-2"><CardTitle className="text-sm">الإيرادات الشهرية</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={monthlyRevenue}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="month" tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} />
                      <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                      <Tooltip formatter={(v: any) => formatCurrency(v)} />
                      <Bar dataKey="revenue" name="الإيرادات" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="employees">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">إنجاز الموظفين</CardTitle></CardHeader>
              <CardContent>
                {employeeTaskPerformance.length > 0 ? (
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={employeeTaskPerformance}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                      <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                      <Tooltip />
                      <Bar dataKey="مهام" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="مكتملة" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : <div className="text-center py-10 text-muted-foreground text-sm">لا توجد مهام موزعة</div>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">ترتيب الموظفين حسب الإنجاز</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {employeeTaskPerformance.map((emp, idx) => (
                    <div key={emp.fullName} className="flex items-center justify-between gap-3" data-testid={`row-employee-rank-${idx}`}>
                      <div className="flex items-center gap-2">
                        <div className="h-7 w-7 rounded-full bg-foreground/10 flex items-center justify-center text-xs font-bold">
                          {idx + 1}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{emp.fullName}</p>
                          <p className="text-xs text-muted-foreground">{emp.specialty}</p>
                        </div>
                      </div>
                      <div className="text-left flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">{emp.مكتملة}/{emp.مهام}</span>
                        <Badge variant={emp.rate >= 80 ? "default" : emp.rate >= 50 ? "secondary" : "outline"} className="text-xs min-w-[3rem] justify-center">
                          {emp.rate}%
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {employeeTaskPerformance.length === 0 && (
                    <p className="text-center text-muted-foreground text-sm py-6">لا يوجد موظفون بمهام</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader className="pb-2"><CardTitle className="text-sm">تفاصيل الموظفين</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {employees.filter(e => e.isActive).map(emp => {
                    const empTasks = filteredTasks.filter(t => t.employeeId === emp.id);
                    const completed = empTasks.filter(t => t.status === "completed").length;
                    const rate = empTasks.length > 0 ? Math.round((completed / empTasks.length) * 100) : 0;
                    return (
                      <div key={emp.id} className="flex items-center justify-between gap-3 p-3 border border-border rounded-md" data-testid={`row-employee-detail-${emp.id}`}>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-foreground/10 flex items-center justify-center">
                            <span className="text-xs font-bold">{emp.name.charAt(0)}</span>
                          </div>
                          <div>
                            <p className="text-sm font-medium">{emp.name}</p>
                            <p className="text-xs text-muted-foreground">{emp.specialty} • {emp.employeeType === "internal" ? "داخلي" : "فريلانسر"}</p>
                          </div>
                        </div>
                        <div className="text-left flex items-center gap-3">
                          <div>
                            <p className="text-xs text-muted-foreground">{empTasks.length} مهام • {completed} منجزة</p>
                            {emp.designPercentage && <p className="text-xs text-muted-foreground">تصميم: {emp.designPercentage}%</p>}
                          </div>
                          <span className="text-sm font-bold">{rate}%</span>
                        </div>
                      </div>
                    );
                  })}
                  {employees.filter(e => e.isActive).length === 0 && (
                    <p className="text-center text-muted-foreground text-sm py-6">لا يوجد موظفون نشطون</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="geography">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">توزيع المشاريع حسب المدينة</CardTitle></CardHeader>
              <CardContent>
                {cityData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={cityData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                      <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                      <Tooltip />
                      <Bar dataKey="count" name="عدد المشاريع" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : <div className="text-center py-10 text-muted-foreground text-sm">لا توجد بيانات جغرافية</div>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">المشاريع والقيم حسب المدينة</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {cityData.map((city, i) => (
                    <div key={city.name} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                        <span className="text-sm">{city.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground">{city.count} مشروع</span>
                        <span className="text-sm font-bold">{formatCurrency(city.value)}</span>
                      </div>
                    </div>
                  ))}
                  {cityData.length === 0 && (
                    <p className="text-center text-muted-foreground text-sm py-6">أضف مواقع للمشاريع لعرض التوزيع</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="marketing">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">ملخص الاستهداف التسويقي</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[
                  { label: "إجمالي العملاء", value: clients.length },
                  { label: "المشاريع لكل عميل (متوسط)", value: clients.length > 0 ? (filteredProjects.length / clients.length).toFixed(1) : "0" },
                  { label: "متوسط قيمة المشروع", value: formatCurrency(filteredProjects.length > 0 ? totalContractValue / filteredProjects.length : 0) },
                  { label: "نسبة التحويل للمشاريع النشطة", value: `${filteredProjects.length > 0 ? Math.round((activeProjects.length / filteredProjects.length) * 100) : 0}%` },
                ].map(item => (
                  <div key={item.label} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <span className="text-sm text-muted-foreground">{item.label}</span>
                    <span className="text-sm font-bold">{item.value}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">أفضل العملاء (حسب قيمة المشاريع)</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {clients
                    .map(c => ({
                      ...c,
                      totalValue: filteredProjects.filter(p => p.clientId === c.id).reduce((s, p) => s + p.totalValue, 0),
                      projectCount: filteredProjects.filter(p => p.clientId === c.id).length,
                    }))
                    .filter(c => c.projectCount > 0)
                    .sort((a, b) => b.totalValue - a.totalValue)
                    .slice(0, 8)
                    .map((client, idx) => (
                      <div key={client.id} className="flex items-center justify-between py-2 border-b border-border last:border-0" data-testid={`row-top-client-${idx}`}>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-muted-foreground w-5">{idx + 1}</span>
                          <div>
                            <p className="text-sm font-medium">{client.name}</p>
                            <p className="text-xs text-muted-foreground">{client.city || "غير محدد"} • {client.projectCount} مشاريع</p>
                          </div>
                        </div>
                        <span className="text-sm font-bold">{formatCurrency(client.totalValue)}</span>
                      </div>
                    ))}
                  {clients.length === 0 && (
                    <p className="text-center text-muted-foreground text-sm py-6">لا يوجد عملاء</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader className="pb-2"><CardTitle className="text-sm">توزيع الإيرادات حسب نوع المشروع</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {["interior", "exterior"].map(type => {
                    const typeProjects = filteredProjects.filter(p => p.projectType === type);
                    const typeValue = typeProjects.reduce((s, p) => s + p.totalValue, 0);
                    const typePaid = filteredPayments.filter(p => p.status === "paid" && typeProjects.some(tp => tp.id === p.projectId)).reduce((s, p) => s + p.amount, 0);
                    return (
                      <div key={type} className="p-4 border border-border rounded-lg">
                        <p className="text-sm font-medium mb-2">{type === "interior" ? "التصميم الداخلي" : "التصميم الخارجي"}</p>
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">عدد المشاريع</span>
                            <span className="font-bold">{typeProjects.length}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">إجمالي القيمة</span>
                            <span className="font-bold">{formatCurrency(typeValue)}</span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">المحصل</span>
                            <span className="font-bold">{formatCurrency(typePaid)}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {user?.role === "admin" && (
          <>
            <TabsContent value="expenses">
              {fLoading ? (
                <div className="space-y-4"><Skeleton className="h-32" /><Skeleton className="h-64" /></div>
              ) : !financialData ? (
                <p className="text-center text-muted-foreground py-8">لا توجد بيانات</p>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-bold">كشف المصروفات</h2>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={() => exportExpensesCSV(financialData)} data-testid="button-export-expenses-csv">
                        <Download className="h-4 w-4 ml-1" /> تصدير Excel
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => exportExpensesPDF(financialData)} data-testid="button-export-expenses-pdf">
                        <FileText className="h-4 w-4 ml-1" /> تصدير PDF
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { label: "الرواتب الأساسية", value: financialData.expenses.baseSalaries, color: "blue" },
                      { label: "العمولات", value: financialData.expenses.commissions, color: "emerald" },
                      { label: "تكاليف الفريلانسرز", value: financialData.expenses.freelancerCosts, color: "amber" },
                      { label: "الالتزامات المالية", value: financialData.expenses.commitments, color: "red" },
                    ].map(item => (
                      <Card key={item.label}>
                        <CardContent className="pt-4 pb-4">
                          <p className="text-xs text-muted-foreground">{item.label}</p>
                          <p className="text-xl font-bold mt-1">{formatCurrency(item.value)}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>إجمالي المصروفات</span>
                        <span className="text-xl font-bold text-red-600">{formatCurrency(financialData.expenses.total)}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {[
                          { label: "الرواتب الأساسية", amount: financialData.expenses.baseSalaries, pct: financialData.expenses.total > 0 ? (financialData.expenses.baseSalaries / financialData.expenses.total * 100) : 0 },
                          { label: "العمولات", amount: financialData.expenses.commissions, pct: financialData.expenses.total > 0 ? (financialData.expenses.commissions / financialData.expenses.total * 100) : 0 },
                          { label: "تكاليف الفريلانسرز", amount: financialData.expenses.freelancerCosts, pct: financialData.expenses.total > 0 ? (financialData.expenses.freelancerCosts / financialData.expenses.total * 100) : 0 },
                          { label: "الالتزامات المالية", amount: financialData.expenses.commitments, pct: financialData.expenses.total > 0 ? (financialData.expenses.commitments / financialData.expenses.total * 100) : 0 },
                        ].map(item => (
                          <div key={item.label} className="flex items-center gap-3">
                            <span className="text-sm w-36 shrink-0">{item.label}</span>
                            <div className="flex-1 bg-muted rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: `${item.pct}%` }} />
                            </div>
                            <span className="text-sm font-semibold w-28 text-left">{formatCurrency(item.amount)}</span>
                            <span className="text-xs text-muted-foreground w-10">{item.pct.toFixed(1)}%</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                  {financialData.expenses.commitmentDetails.length > 0 && (
                    <Card>
                      <CardHeader className="pb-2"><CardTitle className="text-sm">تفاصيل الالتزامات المالية</CardTitle></CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {financialData.expenses.commitmentDetails.map((c, idx) => (
                            <div key={c.id || idx} className="flex items-center justify-between py-2 border-b border-border last:border-0" data-testid={`row-commitment-${idx}`}>
                              <span className="text-sm">{c.title}</span>
                              <div className="flex items-center gap-3">
                                {c.month && <span className="text-xs text-muted-foreground">{c.month}</span>}
                                <span className="text-sm font-semibold">{formatCurrency(c.amount)}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="revenue-type">
              {fLoading ? (
                <div className="space-y-4"><Skeleton className="h-32" /><Skeleton className="h-64" /></div>
              ) : !financialData ? (
                <p className="text-center text-muted-foreground py-8">لا توجد بيانات</p>
              ) : (
                <div className="space-y-6">
                  <h2 className="text-lg font-bold">الإيرادات حسب نوع المشروع</h2>
                  <div className="grid md:grid-cols-3 gap-4">
                    {[
                      { type: "interior" as const, label: "تصميم داخلي", color: "blue" },
                      { type: "exterior" as const, label: "تصميم خارجي", color: "emerald" },
                      { type: "facades" as const, label: "واجهات", color: "amber" },
                    ].map(({ type, label, color }) => (
                      <Card key={type} data-testid={`card-revenue-${type}`}>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm flex items-center justify-between">
                            <span>{label}</span>
                            <Badge variant="outline">{financialData.projectsByType[type].length} مشروع</Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-2xl font-bold" data-testid={`text-revenue-${type}`}>{formatCurrency(financialData.revenueByType[type])}</p>
                          <div className="flex gap-2 mt-2">
                            <Button size="sm" variant="outline" onClick={() => exportRevenueByTypeCSV(financialData, type)} data-testid={`button-csv-${type}`}>
                              <Download className="h-3 w-3 ml-1" /> Excel
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => exportRevenueByTypePDF(financialData, type)} data-testid={`button-pdf-${type}`}>
                              <FileText className="h-3 w-3 ml-1" /> PDF
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  {(["interior", "exterior", "facades"] as const).map(type => {
                    const typeLabel = type === "interior" ? "تصميم داخلي" : type === "exterior" ? "تصميم خارجي" : "واجهات";
                    const projects = financialData.projectsByType[type];
                    if (projects.length === 0) return null;
                    return (
                      <Card key={type}>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm">{typeLabel} — تفاصيل المشاريع</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="border-b border-border text-muted-foreground text-xs">
                                  <th className="text-right pb-2">المشروع</th>
                                  <th className="text-right pb-2">العميل</th>
                                  <th className="text-right pb-2">القيمة الإجمالية</th>
                                  <th className="text-right pb-2">المحصل</th>
                                  <th className="text-right pb-2">المتبقي</th>
                                  <th className="text-right pb-2">الحالة</th>
                                </tr>
                              </thead>
                              <tbody>
                                {projects.map(p => (
                                  <tr key={p.id} className="border-b border-border last:border-0" data-testid={`row-project-${p.id}`}>
                                    <td className="py-2 font-medium">{p.title}</td>
                                    <td className="py-2 text-muted-foreground">{p.clientName}</td>
                                    <td className="py-2">{formatCurrency(p.totalValue)}</td>
                                    <td className="py-2 text-emerald-600 font-medium">{formatCurrency(p.paidRevenue)}</td>
                                    <td className="py-2 text-amber-600">{formatCurrency(p.pendingRevenue)}</td>
                                    <td className="py-2">
                                      <Badge variant="outline" className="text-[10px]">
                                        {p.status === "completed" ? "مكتمل" : p.status === "active" ? "نشط" : p.status === "paused" ? "متوقف" : p.status}
                                      </Badge>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="partners-report">
              {fLoading ? (
                <div className="space-y-4"><Skeleton className="h-32" /><Skeleton className="h-64" /></div>
              ) : !financialData ? (
                <p className="text-center text-muted-foreground py-8">لا توجد بيانات</p>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-bold flex items-center gap-2">
                      <Star className="h-5 w-5 text-amber-500" />
                      تقرير الشركاء والأرباح الشاملة
                    </h2>
                    <Button variant="outline" size="sm" onClick={() => exportPartnersReportPDF(financialData)} data-testid="button-export-partners-report-pdf">
                      <FileText className="h-4 w-4 ml-1" /> تصدير PDF
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { label: "إجمالي الإيرادات", value: financialData.totalRevenue, color: "blue" },
                      { label: "الإيرادات بعد الضريبة", value: financialData.revenueAfterVat, color: "indigo" },
                      { label: "إجمالي المصروفات", value: financialData.expenses.total, color: "red" },
                      { label: "صافي الربح", value: financialData.netProfit, color: "emerald" },
                    ].map(item => (
                      <Card key={item.label}>
                        <CardContent className="pt-4 pb-4">
                          <p className="text-xs text-muted-foreground">{item.label}</p>
                          <p className="text-xl font-bold mt-1" data-testid={`text-financial-${item.label.replace(/\s/g, "-")}`}>{formatCurrency(item.value)}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  <div className="grid md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="pb-2"><CardTitle className="text-sm">الإيرادات حسب النوع</CardTitle></CardHeader>
                      <CardContent className="space-y-3">
                        {[
                          { label: "تصميم داخلي", value: financialData.revenueByType.interior, count: financialData.projectsByType.interior.length },
                          { label: "تصميم خارجي", value: financialData.revenueByType.exterior, count: financialData.projectsByType.exterior.length },
                          { label: "واجهات", value: financialData.revenueByType.facades, count: financialData.projectsByType.facades.length },
                        ].map(item => (
                          <div key={item.label} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                            <div>
                              <p className="text-sm font-medium">{item.label}</p>
                              <p className="text-xs text-muted-foreground">{item.count} مشروع</p>
                            </div>
                            <span className="text-sm font-bold">{formatCurrency(item.value)}</span>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2"><CardTitle className="text-sm">المصروفات</CardTitle></CardHeader>
                      <CardContent className="space-y-2">
                        {[
                          { label: "الرواتب الأساسية", value: financialData.expenses.baseSalaries },
                          { label: "العمولات", value: financialData.expenses.commissions },
                          { label: "تكاليف الفريلانسرز", value: financialData.expenses.freelancerCosts },
                          { label: "الالتزامات", value: financialData.expenses.commitments },
                        ].map(item => (
                          <div key={item.label} className="flex items-center justify-between py-1.5 border-b border-border last:border-0 text-sm">
                            <span className="text-muted-foreground">{item.label}</span>
                            <span className="font-semibold">{formatCurrency(item.value)}</span>
                          </div>
                        ))}
                        <div className="flex items-center justify-between pt-2 font-bold text-red-600">
                          <span>الإجمالي</span>
                          <span>{formatCurrency(financialData.expenses.total)}</span>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-1"><Star className="h-4 w-4 text-amber-500" />حصص الشركاء</CardTitle></CardHeader>
                      <CardContent className="space-y-3">
                        {financialData.partnersSummary.filter(p => p.isActive).length === 0 ? (
                          <p className="text-sm text-muted-foreground text-center py-4">لا يوجد شركاء</p>
                        ) : financialData.partnersSummary.filter(p => p.isActive).map(partner => (
                          <div key={partner.id} className="flex items-center justify-between py-2 border-b border-border last:border-0" data-testid={`row-partner-share-${partner.id}`}>
                            <div>
                              <p className="text-sm font-medium">{partner.name}</p>
                              <p className="text-xs text-muted-foreground">{partner.profitPercentage}% من صافي الربح</p>
                            </div>
                            <span className="text-sm font-bold text-emerald-600">{formatCurrency(partner.shareAmount)}</span>
                          </div>
                        ))}
                        {financialData.partnersSummary.filter(p => p.isActive).length > 0 && (
                          <div className="flex items-center justify-between pt-2 font-bold text-amber-600">
                            <span>إجمالي الحصص</span>
                            <span>{formatCurrency(financialData.partnersSummary.filter(p => p.isActive).reduce((s, p) => s + p.shareAmount, 0))}</span>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="projects-by-month">
              {(() => {
                const monthMap: Record<string, { label: string; projects: typeof projects; totalValue: number; paidRevenue: number; count: number; interior: number; exterior: number; facades: number }> = {};
                projects.forEach(p => {
                  const d = p.startDate ? new Date(p.startDate) : null;
                  if (!d) return;
                  const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
                  const label = d.toLocaleDateString("ar-SA", { year: "numeric", month: "long" });
                  if (!monthMap[key]) monthMap[key] = { label, projects: [], totalValue: 0, paidRevenue: 0, count: 0, interior: 0, exterior: 0, facades: 0 };
                  monthMap[key].projects.push(p);
                  monthMap[key].totalValue += p.totalValue || 0;
                  monthMap[key].paidRevenue += p.paidRevenue || 0;
                  monthMap[key].count++;
                  if (p.type === "interior") monthMap[key].interior++;
                  else if (p.type === "exterior") monthMap[key].exterior++;
                  else if (p.type === "facades") monthMap[key].facades++;
                });
                const months = Object.entries(monthMap).sort((a, b) => b[0].localeCompare(a[0]));
                if (months.length === 0) return (
                  <Card><CardContent className="py-12 text-center text-muted-foreground">لا توجد مشاريع بتواريخ محددة</CardContent></Card>
                );
                return (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-2">
                      <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground mb-1">إجمالي المشاريع</p>
                        <p className="text-xl font-bold text-blue-700 dark:text-blue-400">{projects.length}</p>
                      </div>
                      <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground mb-1">إجمالي قيمة العقود</p>
                        <p className="text-lg font-bold text-emerald-700 dark:text-emerald-400">{formatCurrency(projects.reduce((s, p) => s + (p.totalValue || 0), 0))}</p>
                      </div>
                      <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground mb-1">إجمالي المُحصَّل</p>
                        <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{formatCurrency(projects.reduce((s, p) => s + (p.paidRevenue || 0), 0))}</p>
                      </div>
                      <div className="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground mb-1">الأشهر النشطة</p>
                        <p className="text-xl font-bold">{months.length}</p>
                      </div>
                    </div>
                    {months.map(([key, m]) => (
                      <Card key={key} data-testid={`card-month-${key}`}>
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between flex-wrap gap-2">
                            <CardTitle className="text-base">{m.label}</CardTitle>
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="outline" className="text-[11px]">{m.count} مشروع</Badge>
                              {m.interior > 0 && <Badge className="text-[11px] bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300">داخلي: {m.interior}</Badge>}
                              {m.exterior > 0 && <Badge className="text-[11px] bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">خارجي: {m.exterior}</Badge>}
                              {m.facades > 0 && <Badge className="text-[11px] bg-orange-50 text-orange-700 dark:bg-orange-950 dark:text-orange-300">واجهات: {m.facades}</Badge>}
                            </div>
                          </div>
                          <div className="flex gap-4 mt-2 text-sm">
                            <span>قيمة العقود: <strong className="text-emerald-600">{formatCurrency(m.totalValue)}</strong></span>
                            <span>المُحصَّل: <strong className="text-amber-600">{formatCurrency(m.paidRevenue)}</strong></span>
                            <span>المتبقي: <strong className="text-red-600">{formatCurrency(m.totalValue - m.paidRevenue)}</strong></span>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {m.projects.map((p, idx) => {
                              const client = clients.find(c => c.id === p.clientId);
                              return (
                                <div key={p.id} className="flex items-center justify-between py-2 border-b border-border last:border-0 text-sm" data-testid={`row-month-project-${p.id}`}>
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs text-muted-foreground w-5">{idx + 1}</span>
                                    <div>
                                      <p className="font-medium">{client?.name || p.title}</p>
                                      <div className="flex items-center gap-1 mt-0.5">
                                        <Badge variant="outline" className="text-[10px]">
                                          {p.type === "interior" ? "داخلي" : p.type === "exterior" ? "خارجي" : "واجهات"}
                                        </Badge>
                                        <Badge className={`text-[10px] ${p.status === "completed" ? "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300" : p.status === "active" ? "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300" : "bg-slate-50 text-slate-700 dark:bg-slate-900 dark:text-slate-300"}`}>
                                          {p.status === "completed" ? "مكتمل" : p.status === "active" ? "نشط" : p.status === "on-hold" ? "متوقف" : p.status}
                                        </Badge>
                                        {p.contractArea > 0 && <span className="text-xs text-muted-foreground">{p.contractArea} م²</span>}
                                      </div>
                                    </div>
                                  </div>
                                  <div className="text-left">
                                    <p className="font-semibold">{formatCurrency(p.totalValue || 0)}</p>
                                    <p className="text-xs text-muted-foreground">محصَّل: {formatCurrency(p.paidRevenue || 0)}</p>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                );
              })()}
            </TabsContent>
          </>
        )}
      </Tabs>
    </div>
  );
}
