import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  FolderOpen, Users, UserCheck, DollarSign,
  CheckSquare, TrendingUp, Clock, AlertTriangle
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { useLocation } from "wouter";

interface DashboardStats {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  totalClients: number;
  totalEmployees: number;
  totalRevenue: number;
  pendingRevenue: number;
  pendingTasks: number;
}

interface Task {
  id: string;
  title: string;
  status: string;
  dueDate: string | null;
  priority: string;
}

interface Payment {
  id: string;
  projectId: string;
  paymentType: string;
  amount: number;
  status: string;
  dueDate: string | null;
}

interface Project {
  id: string;
  title: string;
  projectType: string;
  status: string;
  endDate: string | null;
  totalValue: number;
  clientId: string;
}

const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))"];

export default function Dashboard() {
  const [, navigate] = useLocation();

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard"],
  });

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: payments = [] } = useQuery<Payment[]>({
    queryKey: ["/api/payments"],
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const urgentTasks = tasks.filter(t => {
    if (t.status === "completed") return false;
    if (!t.dueDate) return false;
    const days = Math.ceil((new Date(t.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    return days <= 7;
  }).slice(0, 5);

  const urgentProjects = projects.filter(p => {
    if (p.status !== "active") return false;
    if (!p.endDate) return false;
    const days = Math.ceil((new Date(p.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    return days <= 20;
  }).sort((a, b) => {
    const daysA = a.endDate ? Math.ceil((new Date(a.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 999;
    const daysB = b.endDate ? Math.ceil((new Date(b.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 999;
    return daysA - daysB;
  }).slice(0, 5);

  const pendingPayments = payments.filter(p => p.status === "pending").slice(0, 5);

  const projectPieData = stats ? [
    { name: "نشطة", value: stats.activeProjects },
    { name: "مكتملة", value: stats.completedProjects },
    { name: "الكل", value: stats.totalProjects - stats.activeProjects - stats.completedProjects },
  ].filter(d => d.value > 0) : [];

  const revenueData = [
    { name: "المحصل", value: stats?.totalRevenue || 0 },
    { name: "المعلق", value: stats?.pendingRevenue || 0 },
  ];

  const statCards = [
    {
      title: "إجمالي المشاريع",
      value: stats?.totalProjects ?? 0,
      sub: `${stats?.activeProjects ?? 0} نشط`,
      icon: FolderOpen,
      color: "text-foreground",
      bg: "bg-foreground/5 dark:bg-foreground/10",
      onClick: () => navigate("/projects"),
    },
    {
      title: "العملاء",
      value: stats?.totalClients ?? 0,
      sub: "إجمالي العملاء",
      icon: Users,
      color: "text-foreground",
      bg: "bg-foreground/5 dark:bg-foreground/10",
      onClick: () => navigate("/clients"),
    },
    {
      title: "الموظفون",
      value: stats?.totalEmployees ?? 0,
      sub: "موظف نشط",
      icon: UserCheck,
      color: "text-foreground",
      bg: "bg-foreground/5 dark:bg-foreground/10",
      onClick: () => navigate("/employees"),
    },
    {
      title: "الإيرادات المحصلة",
      value: formatCurrency(stats?.totalRevenue ?? 0),
      sub: `${formatCurrency(stats?.pendingRevenue ?? 0)} معلق`,
      icon: DollarSign,
      color: "text-foreground",
      bg: "bg-foreground/5 dark:bg-foreground/10",
      onClick: () => navigate("/finance"),
    },
    {
      title: "المهام المعلقة",
      value: stats?.pendingTasks ?? 0,
      sub: `${urgentTasks.length} عاجلة`,
      icon: CheckSquare,
      color: "text-foreground",
      bg: "bg-foreground/5 dark:bg-foreground/10",
      onClick: () => navigate("/tasks"),
    },
    {
      title: "المشاريع المكتملة",
      value: stats?.completedProjects ?? 0,
      sub: "مشروع منجز",
      icon: TrendingUp,
      color: "text-foreground",
      bg: "bg-foreground/5 dark:bg-foreground/10",
      onClick: () => navigate("/reports"),
    },
  ];

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">لوحة التحكم</h1>
        <p className="text-muted-foreground text-sm mt-1">مرحباً بك في نظام مؤسسة محمد البلوي للتصميم</p>
      </div>

      {urgentProjects.length > 0 && (
        <Card className="mb-6 border-red-200 dark:border-red-800 bg-red-50/50 dark:bg-red-950/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2 text-red-700 dark:text-red-400">
              <AlertTriangle className="h-4 w-4" />
              مشاريع تقترب من التسليم (خلال 20 يوم)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {urgentProjects.map(proj => {
                const days = proj.endDate ? Math.ceil((new Date(proj.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : null;
                const isOverdue = days !== null && days < 0;
                return (
                  <div
                    key={proj.id}
                    className="flex items-center justify-between gap-3 p-3 rounded-lg bg-white dark:bg-gray-900 border cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => navigate(`/projects/${proj.id}`)}
                    data-testid={`urgent-project-${proj.id}`}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{proj.title}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Badge variant="outline" className="text-[10px]">
                          {proj.projectType === "interior" ? "داخلي" : proj.projectType === "facades" ? "واجهات" : "خارجي"}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{formatCurrency(proj.totalValue)}</span>
                      </div>
                    </div>
                    <div className={`text-sm font-bold flex-shrink-0 ${isOverdue ? "text-red-600" : days !== null && days <= 7 ? "text-red-500" : "text-amber-600"}`}>
                      {isOverdue
                        ? `متأخر ${Math.abs(days!)} يوم`
                        : `${days} يوم متبقي`}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        {statCards.map((card) => (
          <Card
            key={card.title}
            className="cursor-pointer hover-elevate"
            data-testid={`stat-card-${card.title}`}
            onClick={card.onClick}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground truncate">{card.title}</p>
                  {statsLoading ? (
                    <Skeleton className="h-6 w-16 mt-1" />
                  ) : (
                    <p className="text-xl font-bold text-foreground mt-1">{card.value}</p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1 truncate">{card.sub}</p>
                </div>
                <div className={`p-2 rounded-md ${card.bg} flex-shrink-0`}>
                  <card.icon className={`h-4 w-4 ${card.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">الإيرادات</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? (
              <Skeleton className="h-48 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
                  <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                  <Tooltip formatter={(v: any) => formatCurrency(v)} />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">توزيع المشاريع</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? (
              <Skeleton className="h-48 w-full" />
            ) : projectPieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie
                    data={projectPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={70}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}`}
                    labelLine={false}
                  >
                    {projectPieData.map((_, index) => (
                      <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">
                لا توجد مشاريع بعد
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              المهام العاجلة
            </CardTitle>
          </CardHeader>
          <CardContent>
            {urgentTasks.length === 0 ? (
              <div className="text-center text-muted-foreground text-sm py-6">لا توجد مهام عاجلة</div>
            ) : (
              <div className="space-y-2">
                {urgentTasks.map((task) => {
                  const days = task.dueDate
                    ? Math.ceil((new Date(task.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
                    : null;
                  return (
                    <div key={task.id} className="flex items-center justify-between gap-2 py-2 border-b border-border last:border-0">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{task.title}</p>
                        {days !== null && (
                          <p className={`text-xs mt-0.5 ${days <= 0 ? "text-foreground font-semibold" : days <= 3 ? "text-foreground/70" : "text-muted-foreground"}`}>
                            {days <= 0 ? "متأخرة" : `${days} يوم متبقي`}
                          </p>
                        )}
                      </div>
                      <Badge variant={task.priority === "high" ? "destructive" : "secondary"} className="flex-shrink-0 text-xs">
                        {task.priority === "high" ? "عاجل" : task.priority === "medium" ? "متوسط" : "منخفض"}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4" />
              الدفعات المعلقة
            </CardTitle>
          </CardHeader>
          <CardContent>
            {pendingPayments.length === 0 ? (
              <div className="text-center text-muted-foreground text-sm py-6">لا توجد دفعات معلقة</div>
            ) : (
              <div className="space-y-2">
                {pendingPayments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between gap-2 py-2 border-b border-border last:border-0">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{payment.paymentType}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{payment.dueDate ? `تاريخ الاستحقاق: ${new Date(payment.dueDate).toLocaleDateString("ar-SA")}` : "—"}</p>
                    </div>
                    <span className="text-sm font-semibold text-foreground flex-shrink-0">
                      {formatCurrency(payment.amount)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
