import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { KeyRound, CheckCircle2 } from "lucide-react";
import logoIcon from "@assets/WhatsApp_Image_2026-02-24_at_11.25.33_PM_1771964913996.jpeg";

export default function ResetPasswordPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const t = params.get("token");
    if (t) setToken(t);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      toast({ title: "خطأ", description: "كلمتا المرور غير متطابقتين", variant: "destructive" });
      return;
    }
    if (password.length < 6) {
      toast({ title: "خطأ", description: "كلمة المرور يجب أن تكون 6 أحرف على الأقل", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      await apiRequest("POST", "/api/auth/reset-password", { token, newPassword: password });
      setSuccess(true);
      toast({ title: "تم تغيير كلمة المرور" });
      setTimeout(() => setLocation("/auth"), 2500);
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message || "الرابط منتهي الصلاحية أو غير صحيح", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background" dir="rtl">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full overflow-hidden mb-4 shadow-xl ring-4 ring-foreground/10">
            <img src={logoIcon} alt="logo" className="h-full w-full object-cover" />
          </div>
          <h1 className="text-lg font-bold">إعادة تعيين كلمة المرور</h1>
          <p className="text-muted-foreground text-sm mt-1">نظام الإدارة — MOHAMMED AL BALWI GROUP</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <KeyRound className="h-4 w-4" />
              {success ? "تم بنجاح" : "كلمة مرور جديدة"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {success ? (
              <div className="text-center py-6 space-y-3">
                <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto" />
                <p className="font-medium">تم تغيير كلمة المرور بنجاح</p>
                <p className="text-sm text-muted-foreground">سيتم توجيهك لصفحة تسجيل الدخول...</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {!token && (
                  <div>
                    <Label>رمز التحقق</Label>
                    <Input
                      value={token}
                      onChange={e => setToken(e.target.value)}
                      placeholder="أدخل رمز التحقق..."
                      dir="ltr"
                      data-testid="input-reset-token"
                    />
                  </div>
                )}
                <div>
                  <Label>كلمة المرور الجديدة</Label>
                  <Input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    data-testid="input-new-password"
                  />
                </div>
                <div>
                  <Label>تأكيد كلمة المرور</Label>
                  <Input
                    type="password"
                    value={confirm}
                    onChange={e => setConfirm(e.target.value)}
                    placeholder="••••••••"
                    required
                    data-testid="input-confirm-password"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading || !token} data-testid="button-reset-password">
                  {loading ? "جاري الحفظ..." : "تغيير كلمة المرور"}
                </Button>
                <div className="text-center">
                  <button type="button" className="text-xs text-muted-foreground underline" onClick={() => setLocation("/auth")}>
                    العودة لتسجيل الدخول
                  </button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
