import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useParams, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowRight, Building2, Calendar, DollarSign, Users,
  CheckCircle2, Circle, Clock, FileText, Plus, Edit, MapPin, Trash2, Link2, ExternalLink, Phone, User, Info
} from "lucide-react";
import { formatCurrency, formatDate, getStatusLabel, getProjectTypeLabel } from "@/lib/utils";
import type { Project, Client, ProjectPhase, Payment, Employee, EmployeeAssignment, Task, Contract, FieldVisit, ProjectFile, ContractTerm } from "@shared/schema";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";

function getEmployeePhaseRole(employee: Employee | undefined): string | null {
  if (!employee) return null;
  const spec = ((employee as any).jobTitle || employee.specialty || "");
  if (spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي")) return "ALL_INTERIOR";
  if (spec.includes("خدمة عملاء") || spec.includes("تسويق")) return "خدمة عملاء";
  if (spec.includes("مخطط") || spec.includes("مساح") || spec.includes("رسم") || spec.includes("مقاسات") || spec.includes("هيكل")) return "مساح";
  if (spec.includes("مصمم")) return "مصمم";
  return null;
}

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [phaseDialog, setPhaseDialog] = useState<ProjectPhase | null>(null);
  const [paymentDialog, setPaymentDialog] = useState<Payment | null>(null);
  const [assignDialog, setAssignDialog] = useState(false);
  const [newAssignment, setNewAssignment] = useState({ employeeId: "", role: "", assignedAmount: "", workType: "" });
  const [editPricing, setEditPricing] = useState(false);
  const [pricingData, setPricingData] = useState({ areaSqm: "", pricePerSqm: "", totalValue: "" });
  const [visitDialog, setVisitDialog] = useState(false);
  const [newVisit, setNewVisit] = useState({ employeeId: "", visitDate: "", visitTime: "", visitStatus: "planned", location: "", googleMapsUrl: "", purpose: "", notes: "", findings: "" });
  const [fileDialog, setFileDialog] = useState(false);
  const [phaseFileDialog, setPhaseFileDialog] = useState<string | null>(null);
  const [newFile, setNewFile] = useState({ fileName: "", fileUrl: "", fileType: "google_drive", description: "" });
  const [termDialog, setTermDialog] = useState<{ id?: string; termText: string; termOrder: number } | null>(null);
  const [editingTermId, setEditingTermId] = useState<string | null>(null);
  const [editingTermText, setEditingTermText] = useState("");
  const [freelancerTaskDialog, setFreelancerTaskDialog] = useState<string | null>(null);
  const [freelancerTask, setFreelancerTask] = useState({ workType: "design", areaSqm: "", pricePerSqm: "", description: "", dueDate: "" });
  const [employeeTaskDialog, setEmployeeTaskDialog] = useState<string | null>(null);
  const [employeeTask, setEmployeeTask] = useState({ title: "", description: "", dueDate: "", priority: "medium" });

  const { data: project, isLoading: pLoading } = useQuery<Project>({ queryKey: ["/api/projects", id] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: phases = [] } = useQuery<ProjectPhase[]>({ queryKey: ["/api/projects", id, "phases"] });
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const myEmployee = user?.employeeId ? employees.find(e => e.id === user.employeeId) : undefined;
  const myPhaseRole = getEmployeePhaseRole(myEmployee);
  const isInteriorManager = myPhaseRole === "ALL_INTERIOR";
  const isCustomerService = myPhaseRole === "خدمة عملاء";
  const isAdmin = user?.role === "admin";
  const isInternalEmployee = myEmployee?.employeeType === "internal";
  const isExteriorTeam = myPhaseRole === "مصمم" || myPhaseRole === "مساح";
  const hasFullAccess = isAdmin || (isInteriorManager && project?.projectType === "interior");
  const canManageTasks = hasFullAccess || isCustomerService;
  const canViewPhasesPayments = hasFullAccess || isInternalEmployee;
  const canUploadFiles = hasFullAccess || canManageTasks || isExteriorTeam;
  const { data: payments = [] } = useQuery<Payment[]>({ queryKey: ["/api/projects", id, "payments"], enabled: canViewPhasesPayments });
  const { data: assignments = [] } = useQuery<EmployeeAssignment[]>({ queryKey: ["/api/projects", id, "assignments"], enabled: hasFullAccess || canManageTasks });
  const { data: tasks = [] } = useQuery<Task[]>({ queryKey: ["/api/projects", id, "tasks"] });
  const { data: contract } = useQuery<Contract | null>({ queryKey: ["/api/projects", id, "contract"], enabled: hasFullAccess });
  const { data: contractTermsData = [] } = useQuery<ContractTerm[]>({
    queryKey: ["/api/contracts", contract?.id, "terms"],
    enabled: !!contract?.id,
  });
  const { data: visits = [] } = useQuery<FieldVisit[]>({ queryKey: ["/api/projects", id, "visits"], enabled: hasFullAccess });
  const { data: projectFiles = [] } = useQuery<ProjectFile[]>({ queryKey: ["/api/projects", id, "files"] });

  const updatePhase = useMutation({
    mutationFn: ({ phaseId, data }: { phaseId: string; data: any }) =>
      apiRequest("PUT", `/api/phases/${phaseId}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "phases"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم تحديث المرحلة" });
      setPhaseDialog(null);
    },
    onError: (e: any) => {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    },
  });

  const updatePayment = useMutation({
    mutationFn: ({ payId, data }: { payId: string; data: any }) =>
      apiRequest("PUT", `/api/payments/${payId}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم تحديث الدفعة" });
      setPaymentDialog(null);
    },
  });

  const createAssignment = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/assignments", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "assignments"] });
      toast({ title: "تم تعيين الموظف" });
      setAssignDialog(false);
      setNewAssignment({ employeeId: "", role: "", assignedAmount: "", workType: "" });
    },
  });

  const updateProject = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/projects/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم تحديث بيانات المشروع" });
      setEditPricing(false);
    },
    onError: () => toast({ title: "خطأ في التحديث", variant: "destructive" }),
  });

  const deleteAssignment = useMutation({
    mutationFn: (assignId: string) => apiRequest("DELETE", `/api/assignments/${assignId}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "assignments"] }),
  });

  const sendFreelancerTask = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/freelancer-tasks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "assignments"] });
      toast({ title: "تم إرسال المهمة للمستقل" });
      setFreelancerTaskDialog(null);
      setFreelancerTask({ workType: "design", areaSqm: "", pricePerSqm: "", description: "", dueDate: "" });
    },
    onError: () => toast({ title: "خطأ في إرسال المهمة", variant: "destructive" }),
  });

  const sendEmployeeTask = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/tasks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "tasks"] });
      toast({ title: "تم إرسال المهمة للموظف" });
      setEmployeeTaskDialog(null);
      setEmployeeTask({ title: "", description: "", dueDate: "", priority: "medium" });
    },
    onError: () => toast({ title: "خطأ في إرسال المهمة", variant: "destructive" }),
  });

  const approveFreelancerTask = useMutation({
    mutationFn: (taskId: string) => apiRequest("POST", `/api/freelancer-tasks/${taskId}/approve`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "assignments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      toast({ title: "تمت الموافقة وتم إشعار الإدارة بالتكلفة" });
    },
    onError: () => toast({ title: "خطأ في الموافقة", variant: "destructive" }),
  });

  const createContract = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/contracts", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "contract"] });
      toast({ title: "تم إنشاء العقد" });
    },
  });

  const addContractTerm = useMutation({
    mutationFn: (data: { contractId: string; termText: string; termOrder: number }) =>
      apiRequest("POST", `/api/contracts/${data.contractId}/terms`, { termText: data.termText, termOrder: data.termOrder }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts", contract?.id, "terms"] });
      toast({ title: "تم إضافة البند" });
      setTermDialog(null);
    },
    onError: () => toast({ title: "خطأ في إضافة البند", variant: "destructive" }),
  });

  const updateContractTerm = useMutation({
    mutationFn: ({ termId, termText }: { termId: string; termText: string }) =>
      apiRequest("PUT", `/api/contract-terms/${termId}`, { termText }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts", contract?.id, "terms"] });
      toast({ title: "تم تعديل البند" });
      setEditingTermId(null);
    },
    onError: () => toast({ title: "خطأ في تعديل البند", variant: "destructive" }),
  });

  const deleteContractTerm = useMutation({
    mutationFn: (termId: string) => apiRequest("DELETE", `/api/contract-terms/${termId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts", contract?.id, "terms"] });
      toast({ title: "تم حذف البند" });
    },
    onError: () => toast({ title: "خطأ في حذف البند", variant: "destructive" }),
  });

  const loadDefaultTerms = useMutation({
    mutationFn: (contractId: string) => apiRequest("POST", `/api/contracts/${contractId}/default-terms`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts", contract?.id, "terms"] });
      toast({ title: "تم تحميل البنود الافتراضية" });
    },
    onError: () => toast({ title: "البنود الافتراضية محملة مسبقاً أو حدث خطأ", variant: "destructive" }),
  });

  const createVisit = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/visits", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "visits"] });
      toast({ title: "تم إضافة الزيارة الميدانية" });
      setVisitDialog(false);
      setNewVisit({ employeeId: "", visitDate: "", visitTime: "", visitStatus: "planned", location: "", googleMapsUrl: "", purpose: "", notes: "", findings: "" });
    },
  });

  const deleteVisit = useMutation({
    mutationFn: (visitId: string) => apiRequest("DELETE", `/api/visits/${visitId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "visits"] });
      toast({ title: "تم حذف الزيارة" });
    },
  });

  const createFile = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/files", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "files"] });
      toast({ title: "تم إضافة الملف" });
      setFileDialog(false);
      setPhaseFileDialog(null);
      setNewFile({ fileName: "", fileUrl: "", fileType: "google_drive", description: "" });
    },
  });

  const deleteFile = useMutation({
    mutationFn: (fileId: string) => apiRequest("DELETE", `/api/files/${fileId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", id, "files"] });
      toast({ title: "تم حذف الملف" });
    },
  });

  if (pLoading) return <div className="p-6"><Skeleton className="h-64 w-full" /></div>;
  if (!project) return <div className="p-6 text-center">المشروع غير موجود</div>;

  const client = clients.find(c => c.id === project.clientId);
  const sortedPhases = [...phases].sort((a, b) => a.phaseOrder - b.phaseOrder);
  const completedPhases = phases.filter(p => p.status === "completed").length;
  const progressPct = phases.length > 0 ? (completedPhases / phases.length) * 100 : 0;
  const paidAmount = payments.filter(p => p.status === "paid").reduce((s, p) => s + p.amount, 0);

  const myPhases = canViewPhasesPayments ? sortedPhases : sortedPhases.filter(phase => {
    if (!myPhaseRole || myPhaseRole === "ALL_INTERIOR") return false;
    return (phase as any).responsibleRole === myPhaseRole;
  });

  const canCompletePhase = (phase: ProjectPhase) => {
    if (hasFullAccess) return true;
    if (canManageTasks) return true;
    if (isExteriorTeam) return true;
    if (myPhaseRole && myPhaseRole !== "ALL_INTERIOR" && (phase as any).responsibleRole === myPhaseRole) return true;
    return false;
  };

  const getPhaseFiles = (phaseId: string) => projectFiles.filter(f => (f as any).phaseId === phaseId);
  const phaseHasFiles = (phaseId: string) => getPhaseFiles(phaseId).length > 0;

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate(isAdmin ? "/projects" : "/my-projects")}>
          <ArrowRight className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-bold">{project.title}</h1>
            <Badge className={project.projectType === "interior" ? "bg-violet-50 text-violet-700 dark:bg-violet-950 dark:text-violet-300" : "bg-sky-50 text-sky-700 dark:bg-sky-950 dark:text-sky-300"}>
              {getProjectTypeLabel(project.projectType)}
            </Badge>
            <Badge variant={project.status === "active" ? "default" : "secondary"}>
              {getStatusLabel(project.status || "active")}
            </Badge>
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <p className="text-muted-foreground text-sm">{client?.name} • {project.location || "—"}</p>
            {(project as any).googleMapsUrl && (
              <a
                href={(project as any).googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary text-xs hover:underline flex items-center gap-1"
                data-testid="link-project-map"
              >
                <MapPin className="h-3 w-3" />
                الخريطة
              </a>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <Card className="cursor-pointer hover:ring-2 hover:ring-primary/30 transition-all" onClick={() => {
          if (hasFullAccess && !editPricing) {
            setPricingData({
              areaSqm: String(project.areaSqm || ""),
              pricePerSqm: String(project.pricePerSqm || ""),
              totalValue: String(project.totalValue || ""),
            });
            setEditPricing(true);
          }
        }}>
          <CardContent className="p-4 text-center">
            <DollarSign className="h-5 w-5 text-primary mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">قيمة العقد</p>
            <p className="font-bold text-sm mt-0.5" data-testid="text-total-value">{formatCurrency(project.totalValue)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <CheckCircle2 className="h-5 w-5 text-emerald-500 mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">المحصل</p>
            <p className="font-bold text-sm mt-0.5">{formatCurrency(paidAmount)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Building2 className="h-5 w-5 text-blue-500 mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">المساحة</p>
            <p className="font-bold text-sm mt-0.5">{project.areaSqm ? `${project.areaSqm} م²` : "—"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <DollarSign className="h-5 w-5 text-blue-500 mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">سعر المتر</p>
            <p className="font-bold text-sm mt-0.5">{project.pricePerSqm ? `${project.pricePerSqm} ر.س` : "—"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Calendar className="h-5 w-5 text-amber-500 mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">تاريخ الانتهاء</p>
            <p className="font-bold text-sm mt-0.5">{formatDate(project.endDate)}</p>
          </CardContent>
        </Card>
      </div>

      {editPricing && (
        <Card className="mb-4 border-primary/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Edit className="h-4 w-4" />
              أداة القياس — تعديل الأسعار
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-xs text-muted-foreground">المساحة (م²)</label>
                <Input
                  type="number"
                  value={pricingData.areaSqm}
                  onChange={(e) => {
                    const area = e.target.value;
                    const total = pricingData.totalValue;
                    const newPricePerSqm = area && total && parseFloat(area) > 0
                      ? (parseFloat(total) / parseFloat(area)).toFixed(2) : pricingData.pricePerSqm;
                    setPricingData({ ...pricingData, areaSqm: area, pricePerSqm: newPricePerSqm });
                  }}
                  data-testid="input-edit-area"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">سعر المتر (ر.س)</label>
                <Input
                  type="number"
                  value={pricingData.pricePerSqm}
                  onChange={(e) => {
                    const price = e.target.value;
                    const area = pricingData.areaSqm;
                    const newTotal = area && price ? (parseFloat(area) * parseFloat(price)).toFixed(0) : pricingData.totalValue;
                    setPricingData({ ...pricingData, pricePerSqm: price, totalValue: newTotal });
                  }}
                  data-testid="input-edit-price-sqm"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">الإجمالي (ر.س)</label>
                <Input
                  type="number"
                  value={pricingData.totalValue}
                  onChange={(e) => {
                    const total = e.target.value;
                    const area = pricingData.areaSqm;
                    const newPrice = area && total && parseFloat(area) > 0
                      ? (parseFloat(total) / parseFloat(area)).toFixed(2) : pricingData.pricePerSqm;
                    setPricingData({ ...pricingData, totalValue: total, pricePerSqm: newPrice });
                  }}
                  data-testid="input-edit-total"
                />
              </div>
            </div>
            <div className="flex gap-2 mt-3">
              <Button
                size="sm"
                onClick={() => updateProject.mutate({
                  areaSqm: pricingData.areaSqm ? parseFloat(pricingData.areaSqm) : null,
                  pricePerSqm: pricingData.pricePerSqm ? parseFloat(pricingData.pricePerSqm) : null,
                  totalValue: pricingData.totalValue ? parseFloat(pricingData.totalValue) : project.totalValue,
                })}
                disabled={updateProject.isPending}
                data-testid="button-save-pricing"
              >
                حفظ التعديلات
              </Button>
              <Button size="sm" variant="outline" onClick={() => setEditPricing(false)}>إلغاء</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between gap-2">
            <CardTitle className="text-sm">تقدم المشروع</CardTitle>
            <span className="text-sm font-bold text-primary">{Math.round(progressPct)}%</span>
          </div>
        </CardHeader>
        <CardContent>
          <Progress value={progressPct} className="h-2 mb-3" />
          <p className="text-xs text-muted-foreground">{completedPhases} من {phases.length} مراحل مكتملة</p>
        </CardContent>
      </Card>

      <Tabs defaultValue="info" dir="rtl">
        <TabsList className="mb-4 flex-wrap h-auto">
          <TabsTrigger value="info" data-testid="tab-info">تفاصيل المشروع</TabsTrigger>
          <TabsTrigger value="phases" data-testid="tab-phases">{canViewPhasesPayments ? "المراحل والدفعات" : "مراحلي"}</TabsTrigger>
          {(hasFullAccess || canManageTasks) && <TabsTrigger value="team" data-testid="tab-team">الفريق</TabsTrigger>}
          <TabsTrigger value="tasks" data-testid="tab-tasks">المهام</TabsTrigger>
          {hasFullAccess && <TabsTrigger value="visits" data-testid="tab-visits">الزيارات الميدانية</TabsTrigger>}
          {canUploadFiles && <TabsTrigger value="files" data-testid="tab-files">الملفات</TabsTrigger>}
          {hasFullAccess && <TabsTrigger value="contract" data-testid="tab-contract">العقد</TabsTrigger>}
        </TabsList>

        {/* ─── تفاصيل المشروع ─── */}
        <TabsContent value="info">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* بيانات العميل */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <User className="h-4 w-4 text-primary" />
                  بيانات العميل
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">الاسم</span>
                  <span className="font-semibold">{client?.name || "—"}</span>
                </div>
                {(client as any)?.phone && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الجوال</span>
                    <a href={`tel:${(client as any).phone}`} className="font-semibold text-primary flex items-center gap-1">
                      <Phone className="h-3.5 w-3.5" />
                      {(client as any).phone}
                    </a>
                  </div>
                )}
                {(client as any)?.city && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">المدينة</span>
                    <span className="font-semibold">{(client as any).city}</span>
                  </div>
                )}
                {(client as any)?.email && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">البريد الإلكتروني</span>
                    <span className="font-semibold text-xs">{(client as any).email}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* بيانات المشروع */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-primary" />
                  بيانات المشروع
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">التصنيف</span>
                  <Badge className={project.projectType === "interior" ? "bg-violet-50 text-violet-700 dark:bg-violet-950 dark:text-violet-300" : project.projectType === "facades" ? "bg-orange-50 text-orange-700 dark:bg-orange-950 dark:text-orange-300" : "bg-sky-50 text-sky-700 dark:bg-sky-950 dark:text-sky-300"}>
                    {getProjectTypeLabel(project.projectType)}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">الحالة</span>
                  <Badge variant={project.status === "active" ? "default" : "secondary"}>
                    {getStatusLabel(project.status || "active")}
                  </Badge>
                </div>
                {project.areaSqm && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">المساحة</span>
                    <span className="font-semibold">{project.areaSqm} م²</span>
                  </div>
                )}
                {project.pricePerSqm && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">سعر المتر</span>
                    <span className="font-semibold">{Number(project.pricePerSqm).toLocaleString("ar-SA")} ر.س</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">قيمة العقد</span>
                  <span className="font-bold text-primary">{formatCurrency(project.totalValue)}</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-muted-foreground">ضريبة 15%</span>
                  <span className="font-semibold">{formatCurrency(project.totalValue * 0.15)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">الإجمالي شامل الضريبة</span>
                  <span className="font-bold">{formatCurrency(project.totalValue * 1.15)}</span>
                </div>
              </CardContent>
            </Card>

            {/* التواريخ والمواعيد */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-primary" />
                  التواريخ والمواعيد
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2.5 text-sm">
                {project.startDate && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">تاريخ البدء</span>
                    <span className="font-semibold">{formatDate(project.startDate)}</span>
                  </div>
                )}
                {project.endDate && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">تاريخ الانتهاء</span>
                    <span className="font-semibold">{formatDate(project.endDate)}</span>
                  </div>
                )}
                {(project as any).executionDays && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">مدة التنفيذ</span>
                    <span className="font-semibold">{(project as any).executionDays} يوم</span>
                  </div>
                )}
                {project.endDate && (
                  <div className="flex justify-between border-t pt-2">
                    <span className="text-muted-foreground">الأيام المتبقية</span>
                    {(() => {
                      const days = Math.ceil((new Date(project.endDate).getTime() - Date.now()) / 86400000);
                      return (
                        <span className={`font-bold ${days < 0 ? "text-red-600" : days <= 7 ? "text-amber-600" : "text-emerald-600"}`}>
                          {days < 0 ? `متأخر ${Math.abs(days)} يوم` : `${days} يوم`}
                        </span>
                      );
                    })()}
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">جدول الدفعات</span>
                  <span className="font-semibold">{project.paymentSchedule === 1 ? "دفعة واحدة" : project.paymentSchedule === 2 ? "دفعتان" : "3 دفعات"}</span>
                </div>
              </CardContent>
            </Card>

            {/* الموقع */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  الموقع والوصف
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2.5 text-sm">
                {project.location && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الموقع</span>
                    <span className="font-semibold">{project.location}</span>
                  </div>
                )}
                {(project as any).googleMapsUrl && (
                  <a
                    href={(project as any).googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-primary hover:underline font-medium"
                    data-testid="link-info-map"
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                    عرض على قوقل ماب
                  </a>
                )}
                {project.description && (
                  <div className="pt-2 border-t">
                    <p className="text-muted-foreground mb-1">الوصف</p>
                    <p className="text-foreground leading-relaxed">{project.description}</p>
                  </div>
                )}
                {!project.location && !(project as any).googleMapsUrl && !project.description && (
                  <p className="text-muted-foreground text-center py-4">لا يوجد معلومات إضافية</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="phases">
          <div className="mb-6">
            <div className="flex items-center gap-1 overflow-x-auto pb-2">
              {sortedPhases.map((phase, idx) => {
                const isMine = canCompletePhase(phase);
                const isFinancial = (phase as any).phaseType === "financial";
                return (
                <div key={phase.id} className="flex items-center">
                  <div className={`flex flex-col items-center min-w-[80px] ${
                    phase.status === "completed" ? "opacity-100" :
                    phase.status === "in_progress" ? "opacity-100" :
                    !canViewPhasesPayments && !isMine ? "opacity-30" : "opacity-50"
                  }`}>
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center border-2 ${
                      phase.status === "completed" ? "bg-emerald-500 border-emerald-500 text-white" :
                      phase.status === "in_progress" ? (isFinancial ? "bg-amber-500 border-amber-500 text-white animate-pulse" : "bg-blue-500 border-blue-500 text-white animate-pulse") :
                      isMine ? "bg-background border-primary/50 text-primary" :
                      "bg-background border-muted-foreground/30 text-muted-foreground"
                    }`}>
                      {phase.status === "completed" ? (
                        <CheckCircle2 className="h-4 w-4" />
                      ) : isFinancial ? (
                        <DollarSign className="h-4 w-4" />
                      ) : phase.status === "in_progress" ? (
                        <Clock className="h-4 w-4" />
                      ) : (
                        <span className="text-xs font-bold">{phase.phaseOrder}</span>
                      )}
                    </div>
                    <p className={`text-[10px] text-center mt-1 font-medium leading-tight max-w-[80px] ${isFinancial ? "text-amber-600 dark:text-amber-400" : ""}`}>{phase.phaseName}</p>
                  </div>
                  {idx < sortedPhases.length - 1 && (
                    <div className={`h-0.5 w-6 mx-1 mt-[-16px] ${
                      phase.status === "completed" ? "bg-emerald-500" : "bg-muted-foreground/20"
                    }`} />
                  )}
                </div>
              );
              })}
            </div>
          </div>

          {!canViewPhasesPayments && myPhases.length === 0 && (
            <Card><CardContent className="p-6 text-center text-muted-foreground">لا توجد مراحل مسندة إليك في هذا المشروع</CardContent></Card>
          )}

          <div className="space-y-3">
            {myPhases.map((phase, idx) => {
              const responsible = (phase as any).responsibleEmployeeId
                ? employees.find(e => e.id === (phase as any).responsibleEmployeeId)
                : null;
              const isMine = canCompletePhase(phase);
              const isFinancialPhase = (phase as any).phaseType === "financial";
              const phaseFilesList = getPhaseFiles(phase.id);
              const hasReceipt = phaseFilesList.length > 0;
              return (
              <Card key={phase.id} className={`hover-elevate ${phase.status === "in_progress" ? (isFinancialPhase ? "ring-2 ring-amber-500/30" : "ring-2 ring-blue-500/30") : ""}`} data-testid={`card-phase-${phase.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                      phase.status === "completed" ? "bg-emerald-100 dark:bg-emerald-900" :
                      phase.status === "in_progress" ? (isFinancialPhase ? "bg-amber-100 dark:bg-amber-900" : "bg-blue-100 dark:bg-blue-900") :
                      "bg-muted"
                    }`}>
                      {phase.status === "completed" ? (
                        <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                      ) : isFinancialPhase ? (
                        <DollarSign className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                      ) : phase.status === "in_progress" ? (
                        <Clock className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      ) : (
                        <Circle className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs text-muted-foreground">المرحلة {phase.phaseOrder}</span>
                        {isFinancialPhase && <Badge className="text-xs bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300">مالية</Badge>}
                        {phase.isApproved && <Badge className="text-xs bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">معتمدة</Badge>}
                      </div>
                      <p className="font-medium text-sm mt-0.5">{phase.phaseName}</p>
                      <div className="flex items-center gap-3 mt-1">
                        {responsible && (
                          <span className="text-xs text-blue-600 dark:text-blue-400 flex items-center gap-1">
                            <Users className="h-3 w-3" />{responsible.name}
                          </span>
                        )}
                        {phase.dueDate && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />{formatDate(phase.dueDate)}
                          </span>
                        )}
                        {phase.completionDate && (
                          <span className="text-xs text-emerald-600 flex items-center gap-1">
                            <CheckCircle2 className="h-3 w-3" />أُنجز: {formatDate(phase.completionDate)}
                          </span>
                        )}
                      </div>
                      {isFinancialPhase && (() => {
                        const phasePaymentPct = (phase as any).paymentPercentage;
                        const financialPhases = myPhases.filter(ph => (ph as any).phaseType === "financial");
                        const financialIdx = financialPhases.indexOf(phase);
                        const matchingPayment = payments.find(p => p.paymentNumber === financialIdx + 1) 
                          || payments.find(p => p.percentage === phasePaymentPct);
                        return (
                          <>
                            {matchingPayment && (
                              <div className="mt-1.5 p-2 bg-amber-50 dark:bg-amber-950/30 rounded text-xs">
                                <div className="flex items-center justify-between">
                                  <span className="text-amber-700 dark:text-amber-400">
                                    دفعة {matchingPayment.paymentNumber} — {matchingPayment.percentage}%
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <span className="font-semibold text-amber-800 dark:text-amber-300">{formatCurrency(matchingPayment.amount)}</span>
                                    {hasFullAccess && (
                                      <Button size="sm" variant="ghost" className="h-5 w-5 p-0" onClick={() => setPaymentDialog(matchingPayment)} data-testid={`button-edit-payment-${matchingPayment.id}`}>
                                        <Edit className="h-3 w-3" />
                                      </Button>
                                    )}
                                  </div>
                                </div>
                                <div className="flex items-center justify-between mt-0.5">
                                  <span className="text-amber-600/70">{matchingPayment.paymentType}</span>
                                  <Badge variant={matchingPayment.status === "paid" ? "default" : "secondary"} className="text-[9px] h-4">
                                    {matchingPayment.status === "paid" ? "مدفوعة" : matchingPayment.status === "overdue" ? "متأخرة" : "معلقة"}
                                  </Badge>
                                </div>
                                {matchingPayment.paidDate && (
                                  <span className="text-emerald-600 text-[10px]">تم الدفع: {formatDate(matchingPayment.paidDate)}</span>
                                )}
                              </div>
                            )}
                            {phase.status === "in_progress" && !hasReceipt && (
                              <p className="text-xs text-amber-600 dark:text-amber-400 mt-1.5 flex items-center gap-1">
                                <FileText className="h-3 w-3" />
                                يجب رفع إيصال الدفعة قبل إتمام هذه المرحلة
                              </p>
                            )}
                          </>
                        );
                      })()}
                    </div>
                    {isMine && phase.status !== "completed" && (
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setPhaseFileDialog(phase.id);
                            setNewFile({ fileName: "", fileUrl: "", fileType: "google_drive", description: "" });
                          }}
                          data-testid={`button-upload-phase-file-${phase.id}`}
                        >
                          <Link2 className="h-4 w-4 ml-1" />
                          {isFinancialPhase ? "رفع إيصال" : "رفع ملف"}
                        </Button>
                        <Button
                          size="sm"
                          className={isFinancialPhase ? "bg-amber-600 hover:bg-amber-700 text-white" : "bg-emerald-600 hover:bg-emerald-700 text-white"}
                          onClick={() => updatePhase.mutate({
                            phaseId: phase.id,
                            data: {
                              status: "completed",
                              completionDate: new Date().toISOString().split("T")[0],
                              responsibleEmployeeId: user?.employeeId || (phase as any).responsibleEmployeeId,
                            }
                          })}
                          disabled={updatePhase.isPending}
                          data-testid={`button-complete-phase-${phase.id}`}
                        >
                          <CheckCircle2 className="h-4 w-4 ml-1" />
                          تم
                        </Button>
                      </div>
                    )}
                    {phase.status === "completed" && (
                      <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300 flex-shrink-0">
                        <CheckCircle2 className="h-3 w-3 ml-1" />مكتملة
                      </Badge>
                    )}
                    {hasFullAccess && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setPhaseDialog(phase)}
                        data-testid={`button-edit-phase-${phase.id}`}
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                  {getPhaseFiles(phase.id).length > 0 && (
                    <div className="mt-3 pt-3 border-t border-border">
                      <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1"><Link2 className="h-3 w-3" />ملفات المرحلة:</p>
                      <div className="flex flex-wrap gap-2">
                        {getPhaseFiles(phase.id).map(f => (
                          <a key={f.id} href={f.fileUrl} target="_blank" rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-muted text-xs hover:bg-muted/80 transition-colors"
                            data-testid={`link-phase-file-${f.id}`}>
                            <ExternalLink className="h-3 w-3" />{f.fileName}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
            })}
          </div>

          {canViewPhasesPayments && payments.length > 0 && (
            <Card className="mt-4" data-testid="payments-summary">
              <CardContent className="p-4">
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-amber-600" />
                  ملخص الدفعات
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {payments.map(pay => (
                    <div
                      key={pay.id}
                      className={`p-2 rounded-lg border text-center cursor-pointer transition-colors ${
                        pay.status === "paid" ? "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800" : "bg-muted/50 border-muted"
                      }`}
                      onClick={() => setPaymentDialog(pay)}
                      data-testid={`payment-summary-${pay.id}`}
                    >
                      <p className="text-[10px] text-muted-foreground">{pay.paymentType}</p>
                      <p className="text-sm font-bold">{formatCurrency(pay.amount)}</p>
                      <Badge variant={pay.status === "paid" ? "default" : "secondary"} className="text-[9px] h-4 mt-1">
                        {pay.status === "paid" ? "مدفوعة" : pay.status === "overdue" ? "متأخرة" : "معلقة"}
                      </Badge>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-2 border-t flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">المدفوع</span>
                  <span className="font-bold text-emerald-600">{formatCurrency(payments.filter(p => p.status === "paid").reduce((s, p) => s + (p.amount || 0), 0))}</span>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>


        <TabsContent value="team">
          {canManageTasks && (
            <div className="flex justify-end mb-3">
              <Button size="sm" onClick={() => setAssignDialog(true)} data-testid="button-assign-employee">
                <Plus className="h-4 w-4 ml-2" />
                تعيين موظف
              </Button>
            </div>
          )}
          <div className="space-y-3">
            {assignments.length === 0 ? (
              <Card><CardContent className="py-10 text-center text-muted-foreground text-sm">لم يتم تعيين موظفين بعد</CardContent></Card>
            ) : assignments.map((assign) => {
              const emp = employees.find(e => e.id === assign.employeeId);
              const isFreelancer = emp?.employeeType === "freelancer";
              const workType = (assign as any).workType;
              return (
                <Card key={assign.id} className="hover-elevate" data-testid={`card-assignment-${assign.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className={`h-9 w-9 rounded-full flex items-center justify-center ${isFreelancer ? "bg-amber-100 dark:bg-amber-900" : "bg-primary/10"}`}>
                          <span className={`text-sm font-bold ${isFreelancer ? "text-amber-600" : "text-primary"}`}>{emp?.name.charAt(0) || "؟"}</span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm">{emp?.name || "موظف محذوف"}</p>
                            {isFreelancer && <Badge variant="secondary" className="text-[10px] px-1.5 py-0">مستقل</Badge>}
                          </div>
                          <p className="text-xs text-muted-foreground">{assign.role || emp?.specialty}</p>
                          {workType && (
                            <Badge variant="outline" className="text-[10px] mt-0.5">
                              {workType === "blueprints" ? "مخططات" : workType === "structural" ? "هيكل إنشائي" : "تصميم"}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {assign.assignedAmount && (
                          <span className="text-sm font-semibold">{formatCurrency(assign.assignedAmount)}</span>
                        )}
                        <Badge variant={assign.isPaid ? "default" : "secondary"} className="text-xs">
                          {assign.isPaid ? "مدفوع" : "غير مدفوع"}
                        </Badge>
                        {canManageTasks && isFreelancer && !assign.isPaid && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs border-blue-300 text-blue-700 dark:text-blue-400"
                            onClick={() => {
                              setFreelancerTaskDialog(assign.employeeId);
                              setFreelancerTask({
                                workType: workType || "design",
                                areaSqm: String(project?.areaSqm || ""),
                                pricePerSqm: "",
                                description: "",
                                dueDate: "",
                              });
                            }}
                            data-testid={`button-send-task-${assign.id}`}
                          >
                            <FileText className="h-3 w-3 ml-1" />
                            إرسال مهمة
                          </Button>
                        )}
                        {canManageTasks && !isFreelancer && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs border-green-300 text-green-700 dark:text-green-400"
                            onClick={() => {
                              setEmployeeTaskDialog(assign.employeeId);
                              setEmployeeTask({ title: "", description: "", dueDate: "", priority: "medium" });
                            }}
                            data-testid={`button-send-employee-task-${assign.id}`}
                          >
                            <FileText className="h-3 w-3 ml-1" />
                            إرسال مهمة
                          </Button>
                        )}
                        <Button size="icon" variant="outline" onClick={() => deleteAssignment.mutate(assign.id)}>
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-destructive"><path d="M3 6h18M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="tasks">
          <div className="space-y-3">
            {tasks.length === 0 ? (
              <Card><CardContent className="py-10 text-center text-muted-foreground text-sm">
                لا توجد مهام لهذا المشروع
                <div className="mt-3">
                  <Button size="sm" onClick={() => navigate("/tasks")}>إضافة مهمة</Button>
                </div>
              </CardContent></Card>
            ) : tasks.map(task => {
              let taskMeta: any = {};
              try { taskMeta = task.notes ? JSON.parse(task.notes) : {}; } catch {}
              const isFreelancerTask = taskMeta.isFreelancerTask;
              const taskEmployee = task.employeeId ? employees.find(e => e.id === task.employeeId) : null;
              const canApprove = canManageTasks && isFreelancerTask && task.status !== "completed";
              return (
              <Card key={task.id} className={`hover-elevate ${isFreelancerTask ? "border-l-2 border-l-amber-500" : ""}`} data-testid={`card-task-${task.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="font-medium text-sm">{task.title}</p>
                        {isFreelancerTask && <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300">مهمة مستقل</Badge>}
                      </div>
                      {taskEmployee && <p className="text-xs text-muted-foreground">{taskEmployee.name}</p>}
                      {task.description && <p className="text-xs text-muted-foreground mt-1 whitespace-pre-line line-clamp-2">{task.description}</p>}
                      {task.dueDate && <p className="text-xs text-muted-foreground mt-0.5">الموعد: {formatDate(task.dueDate)}</p>}
                      {isFreelancerTask && taskMeta.totalCost && (
                        <p className="text-xs font-semibold text-amber-700 dark:text-amber-400 mt-1">التكلفة: {taskMeta.totalCost.toLocaleString("ar-SA")} ر.س</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Badge variant={task.priority === "high" ? "destructive" : "secondary"} className="text-xs">
                        {getStatusLabel(task.priority || "medium")}
                      </Badge>
                      <Badge variant={task.status === "completed" ? "default" : "outline"} className="text-xs">
                        {getStatusLabel(task.status || "pending")}
                      </Badge>
                      {canApprove && (
                        <Button
                          size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs"
                          onClick={() => approveFreelancerTask.mutate(task.id)}
                          disabled={approveFreelancerTask.isPending}
                          data-testid={`button-approve-task-${task.id}`}
                        >
                          <CheckCircle2 className="h-3 w-3 ml-1" />
                          اعتماد
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="visits">
          <div className="flex justify-end mb-3">
            <Button size="sm" onClick={() => setVisitDialog(true)} data-testid="button-add-visit">
              <Plus className="h-4 w-4 ml-2" />
              إضافة زيارة ميدانية
            </Button>
          </div>
          <div className="space-y-3">
            {visits.length === 0 ? (
              <Card><CardContent className="py-10 text-center text-muted-foreground text-sm">لا توجد زيارات ميدانية لهذا المشروع</CardContent></Card>
            ) : visits.map(visit => {
              const emp = employees.find(e => e.id === visit.employeeId);
              return (
                <Card key={visit.id} className="hover-elevate" data-testid={`card-visit-${visit.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center flex-shrink-0">
                          <MapPin className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-medium text-sm">{visit.purpose || "زيارة ميدانية"}</p>
                            <Badge
                              variant={visit.status === "completed" ? "default" : visit.status === "cancelled" ? "destructive" : "secondary"}
                              className="text-xs"
                            >
                              {visit.status === "completed" ? "مكتملة" : visit.status === "cancelled" ? "ملغاة" : "مخططة"}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                            <span>{formatDate(visit.visitDate)}{visit.visitDate?.includes(" ") ? ` — ${visit.visitDate.split(" ")[1]}` : ""}</span>
                            {visit.location && <span>{visit.location}</span>}
                            {emp && <span>{emp.name}</span>}
                            {(visit as any).googleMapsUrl && (
                              <a
                                href={(visit as any).googleMapsUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline flex items-center gap-1"
                                data-testid={`link-visit-map-${visit.id}`}
                              >
                                <ExternalLink className="h-3 w-3" />
                                قوقل ماب
                              </a>
                            )}
                          </div>
                          {visit.findings && (
                            <div className="mt-2 p-2 bg-muted/50 rounded text-xs whitespace-pre-line">{visit.findings}</div>
                          )}
                          {visit.notes && (
                            <p className="text-xs text-muted-foreground mt-1">{visit.notes}</p>
                          )}
                        </div>
                      </div>
                      <Button size="icon" variant="outline" onClick={() => deleteVisit.mutate(visit.id)} data-testid={`button-delete-visit-${visit.id}`}>
                        <Trash2 className="h-3.5 w-3.5 text-destructive" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="files">
          <div className="flex justify-end mb-3">
            <Button size="sm" onClick={() => setFileDialog(true)} data-testid="button-add-file">
              <Plus className="h-4 w-4 ml-2" />
              إضافة ملف
            </Button>
          </div>
          <div className="space-y-3">
            {projectFiles.length === 0 ? (
              <Card><CardContent className="py-10 text-center text-muted-foreground text-sm">
                <Link2 className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                لا توجد ملفات مرفقة لهذا المشروع
              </CardContent></Card>
            ) : projectFiles.map((file) => (
              <Card key={file.id} className="hover-elevate" data-testid={`card-file-${file.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Link2 className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{file.fileName}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <Badge variant="secondary" className="text-xs">
                            {file.fileType === "google_drive" ? "Google Drive" : file.fileType === "telegram" ? "Telegram" : "رابط آخر"}
                          </Badge>
                          {file.description && <span className="text-xs text-muted-foreground truncate">{file.description}</span>}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="icon" variant="outline" asChild data-testid={`button-open-file-${file.id}`}>
                        <a href={file.fileUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                      <Button size="icon" variant="outline" onClick={() => deleteFile.mutate(file.id)} data-testid={`button-delete-file-${file.id}`}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contract">
          {contract ? (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    العقد رقم: {contract.contractNumber}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground">تاريخ العقد</p>
                      <p className="font-medium text-sm">{formatDate(contract.contractDate)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">توقيع العميل</p>
                      <Badge variant={contract.clientSigned ? "default" : "outline"} className="text-xs">
                        {contract.clientSigned ? "موقع" : "غير موقع"}
                      </Badge>
                    </div>
                  </div>
                  {contract.specialConditions && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">الشروط الخاصة</p>
                      <p className="text-sm bg-muted rounded-md p-3">{contract.specialConditions}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">بنود العقد ({contractTermsData.length})</CardTitle>
                    <div className="flex items-center gap-2">
                      {contractTermsData.length === 0 && hasFullAccess && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => loadDefaultTerms.mutate(contract.id)}
                          disabled={loadDefaultTerms.isPending}
                          data-testid="button-load-default-terms"
                        >
                          <FileText className="h-4 w-4 ml-1" />
                          تحميل البنود الافتراضية
                        </Button>
                      )}
                      {hasFullAccess && (
                        <Button
                          size="sm"
                          onClick={() => setTermDialog({ termText: "", termOrder: contractTermsData.length + 1 })}
                          data-testid="button-add-term"
                        >
                          <Plus className="h-4 w-4 ml-1" />
                          إضافة بند
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {contractTermsData.length > 0 ? (
                    <div className="space-y-2">
                      {contractTermsData.map((term, idx) => (
                        <div key={term.id} className="flex gap-3 p-3 border rounded-lg group" data-testid={`contract-term-${term.id}`}>
                          <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold mt-0.5">
                            {idx + 1}
                          </div>
                          <div className="flex-1 min-w-0">
                            {editingTermId === term.id ? (
                              <div className="space-y-2">
                                <Textarea
                                  value={editingTermText}
                                  onChange={(e) => setEditingTermText(e.target.value)}
                                  className="text-sm min-h-[80px]"
                                  data-testid={`input-edit-term-${term.id}`}
                                />
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() => updateContractTerm.mutate({ termId: term.id, termText: editingTermText })}
                                    disabled={updateContractTerm.isPending}
                                    data-testid={`button-save-term-${term.id}`}
                                  >
                                    حفظ
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => setEditingTermId(null)}>
                                    إلغاء
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <p className="text-sm leading-relaxed">{term.termText}</p>
                            )}
                          </div>
                          {hasFullAccess && editingTermId !== term.id && (
                            <div className="flex-shrink-0 flex items-start gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7"
                                onClick={() => { setEditingTermId(term.id); setEditingTermText(term.termText); }}
                                data-testid={`button-edit-term-${term.id}`}
                              >
                                <Edit className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-destructive"
                                onClick={() => deleteContractTerm.mutate(term.id)}
                                data-testid={`button-delete-term-${term.id}`}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-sm text-muted-foreground">
                      لا توجد بنود مضافة للعقد
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="py-10 text-center">
                <FileText className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">لا يوجد عقد لهذا المشروع</p>
                {hasFullAccess && (
                  <Button
                    className="mt-4"
                    size="sm"
                    onClick={() => createContract.mutate({
                      projectId: id,
                      contractNumber: `C-${Date.now()}`,
                      contractDate: new Date().toISOString().split("T")[0],
                      clientSigned: false,
                      companySigned: false,
                      terms: "",
                      specialConditions: "",
                      notes: "",
                    })}
                    data-testid="button-create-contract"
                  >
                    <Plus className="h-4 w-4 ml-2" />
                    إنشاء عقد
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Phase Dialog */}
      <Dialog open={!!phaseDialog} onOpenChange={() => setPhaseDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>تحديث المرحلة: {phaseDialog?.phaseName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">الحالة</label>
              <Select
                value={phaseDialog?.status || "pending"}
                onValueChange={(v) => phaseDialog && setPhaseDialog({ ...phaseDialog, status: v as any })}
              >
                <SelectTrigger className="mt-1.5" data-testid="select-phase-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="in_progress">جاري</SelectItem>
                  <SelectItem value="completed">مكتمل</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">الموظف المسؤول</label>
              <Select
                value={(phaseDialog as any)?.responsibleEmployeeId || "none"}
                onValueChange={(v) => phaseDialog && setPhaseDialog({ ...phaseDialog, responsibleEmployeeId: v === "none" ? null : v } as any)}
              >
                <SelectTrigger className="mt-1.5" data-testid="select-phase-employee">
                  <SelectValue placeholder="اختر الموظف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">غير محدد</SelectItem>
                  {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.name} — {e.specialty}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">تاريخ الموعد</label>
              <Input
                type="date"
                className="mt-1.5"
                value={phaseDialog?.dueDate || ""}
                onChange={(e) => phaseDialog && setPhaseDialog({ ...phaseDialog, dueDate: e.target.value })}
                data-testid="input-phase-due-date"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="approved"
                checked={phaseDialog?.isApproved || false}
                onChange={(e) => phaseDialog && setPhaseDialog({ ...phaseDialog, isApproved: e.target.checked })}
                className="h-4 w-4"
                data-testid="checkbox-phase-approved"
              />
              <label htmlFor="approved" className="text-sm">معتمدة</label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPhaseDialog(null)}>إلغاء</Button>
            <Button
              onClick={() => phaseDialog && updatePhase.mutate({
                phaseId: phaseDialog.id,
                data: {
                  status: phaseDialog.status,
                  dueDate: phaseDialog.dueDate,
                  isApproved: phaseDialog.isApproved,
                  responsibleEmployeeId: (phaseDialog as any).responsibleEmployeeId,
                  completionDate: phaseDialog.status === "completed" && !phaseDialog.completionDate
                    ? new Date().toISOString().split("T")[0] : phaseDialog.completionDate,
                }
              })}
              disabled={updatePhase.isPending}
              data-testid="button-save-phase"
            >
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={!!paymentDialog} onOpenChange={() => setPaymentDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>تحديث الدفعة: {paymentDialog?.paymentType}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">الحالة</label>
              <Select
                value={paymentDialog?.status || "pending"}
                onValueChange={(v) => paymentDialog && setPaymentDialog({ ...paymentDialog, status: v as any })}
              >
                <SelectTrigger className="mt-1.5" data-testid="select-payment-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">معلقة</SelectItem>
                  <SelectItem value="paid">مدفوعة</SelectItem>
                  <SelectItem value="overdue">متأخرة</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">تاريخ الدفع</label>
              <Input
                type="date"
                className="mt-1.5"
                value={paymentDialog?.paidDate || ""}
                onChange={(e) => paymentDialog && setPaymentDialog({ ...paymentDialog, paidDate: e.target.value })}
                data-testid="input-payment-paid-date"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPaymentDialog(null)}>إلغاء</Button>
            <Button
              onClick={() => paymentDialog && updatePayment.mutate({
                payId: paymentDialog.id,
                data: { status: paymentDialog.status, paidDate: paymentDialog.paidDate }
              })}
              disabled={updatePayment.isPending}
              data-testid="button-save-payment"
            >
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Employee Dialog */}
      <Dialog open={assignDialog} onOpenChange={setAssignDialog}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>تعيين موظف للمشروع</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">الموظف</label>
              <Select value={newAssignment.employeeId} onValueChange={(v) => setNewAssignment({ ...newAssignment, employeeId: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-assign-employee">
                  <SelectValue placeholder="اختر الموظف" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(e => (
                    <SelectItem key={e.id} value={e.id}>
                      {e.name} — {e.specialty}
                      {e.employeeType === "freelancer" ? " (مستقل)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {(() => {
              const selectedEmp = employees.find(e => e.id === newAssignment.employeeId);
              const isFreelancer = selectedEmp?.employeeType === "freelancer";
              return (
                <>
                  {isFreelancer && (
                    <div>
                      <label className="text-sm font-medium">نوع العمل</label>
                      <Select value={newAssignment.workType} onValueChange={(v) => setNewAssignment({ ...newAssignment, workType: v })}>
                        <SelectTrigger className="mt-1.5" data-testid="select-work-type">
                          <SelectValue placeholder="اختر نوع العمل" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="design">تصميم</SelectItem>
                          <SelectItem value="blueprints">مخططات</SelectItem>
                          <SelectItem value="structural">هيكل إنشائي</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div>
                    <label className="text-sm font-medium">الدور في المشروع</label>
                    <Input
                      className="mt-1.5"
                      placeholder="مصمم رئيسي، مصمم واجهات..."
                      value={newAssignment.role}
                      onChange={(e) => setNewAssignment({ ...newAssignment, role: e.target.value })}
                      data-testid="input-assign-role"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">{isFreelancer ? "سعر العمل (ريال)" : "المبلغ المخصص (ريال)"}</label>
                    <Input
                      type="number"
                      className="mt-1.5"
                      placeholder="0"
                      value={newAssignment.assignedAmount}
                      onChange={(e) => setNewAssignment({ ...newAssignment, assignedAmount: e.target.value })}
                      data-testid="input-assign-amount"
                    />
                    {isFreelancer && newAssignment.assignedAmount && (
                      <p className="text-xs text-muted-foreground mt-1">
                        سيتم خصم هذا المبلغ من قيمة المشروع كمصروف {newAssignment.workType === "blueprints" ? "مخططات" : newAssignment.workType === "structural" ? "هيكل إنشائي" : "تصميم"}
                      </p>
                    )}
                  </div>
                </>
              );
            })()}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignDialog(false)}>إلغاء</Button>
            <Button
              onClick={() => createAssignment.mutate({
                projectId: id,
                employeeId: newAssignment.employeeId,
                role: newAssignment.role,
                workType: newAssignment.workType || null,
                assignedAmount: newAssignment.assignedAmount ? Number(newAssignment.assignedAmount) : null,
                isPaid: false,
              })}
              disabled={!newAssignment.employeeId || createAssignment.isPending}
              data-testid="button-save-assignment"
            >
              تعيين
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Freelancer Task Dialog */}
      <Dialog open={!!freelancerTaskDialog} onOpenChange={() => setFreelancerTaskDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إرسال مهمة للمستقل</DialogTitle>
          </DialogHeader>
          {(() => {
            const selectedFreelancer = employees.find(e => e.id === freelancerTaskDialog);
            const totalCost = freelancerTask.areaSqm && freelancerTask.pricePerSqm
              ? parseFloat(freelancerTask.areaSqm) * parseFloat(freelancerTask.pricePerSqm) : 0;
            return (
              <div className="space-y-4">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm font-medium">{selectedFreelancer?.name}</p>
                  <p className="text-xs text-muted-foreground">{project?.title}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">نوع العمل *</label>
                  <Select value={freelancerTask.workType} onValueChange={v => setFreelancerTask({ ...freelancerTask, workType: v })}>
                    <SelectTrigger className="mt-1.5" data-testid="select-freelancer-work-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="design">تصميم</SelectItem>
                      <SelectItem value="blueprints">مخططات</SelectItem>
                      <SelectItem value="structural">هيكل إنشائي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium">المساحة (م²)</label>
                    <Input
                      type="number"
                      className="mt-1.5"
                      placeholder="0"
                      value={freelancerTask.areaSqm}
                      onChange={e => setFreelancerTask({ ...freelancerTask, areaSqm: e.target.value })}
                      data-testid="input-freelancer-area"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">سعر المتر (ر.س)</label>
                    <Input
                      type="number"
                      className="mt-1.5"
                      placeholder="0"
                      value={freelancerTask.pricePerSqm}
                      onChange={e => setFreelancerTask({ ...freelancerTask, pricePerSqm: e.target.value })}
                      data-testid="input-freelancer-price"
                    />
                  </div>
                </div>
                {totalCost > 0 && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg" data-testid="freelancer-cost-preview">
                    <p className="text-xs text-amber-700 dark:text-amber-400">التكلفة الإجمالية</p>
                    <p className="text-lg font-bold text-amber-800 dark:text-amber-300">{totalCost.toLocaleString("ar-SA")} ر.س</p>
                    <p className="text-[10px] text-amber-600">ستُخصم من قيمة المشروع كتكاليف بعد خصم الضريبة</p>
                  </div>
                )}
                <div>
                  <label className="text-sm font-medium">ملاحظات إضافية</label>
                  <Textarea
                    className="mt-1.5"
                    rows={2}
                    placeholder="تفاصيل المهمة..."
                    value={freelancerTask.description}
                    onChange={e => setFreelancerTask({ ...freelancerTask, description: e.target.value })}
                    data-testid="input-freelancer-notes"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">الموعد النهائي</label>
                  <Input
                    type="date"
                    className="mt-1.5"
                    value={freelancerTask.dueDate}
                    onChange={e => setFreelancerTask({ ...freelancerTask, dueDate: e.target.value })}
                    data-testid="input-freelancer-due-date"
                  />
                </div>
              </div>
            );
          })()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setFreelancerTaskDialog(null)}>إلغاء</Button>
            <Button
              onClick={() => sendFreelancerTask.mutate({
                projectId: id,
                employeeId: freelancerTaskDialog,
                workType: freelancerTask.workType,
                areaSqm: freelancerTask.areaSqm,
                pricePerSqm: freelancerTask.pricePerSqm,
                description: freelancerTask.description,
                dueDate: freelancerTask.dueDate,
              })}
              disabled={!freelancerTaskDialog || sendFreelancerTask.isPending}
              data-testid="button-send-freelancer-task"
            >
              إرسال المهمة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Employee Task Dialog */}
      <Dialog open={!!employeeTaskDialog} onOpenChange={() => setEmployeeTaskDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إرسال مهمة للموظف</DialogTitle>
          </DialogHeader>
          {(() => {
            const selectedEmployee = employees.find(e => e.id === employeeTaskDialog);
            return (
              <div className="space-y-4">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm font-medium">{selectedEmployee?.name}</p>
                  <p className="text-xs text-muted-foreground">{project?.title}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">عنوان المهمة *</label>
                  <Input
                    className="mt-1.5"
                    placeholder="مثال: إعداد المخططات التنفيذية"
                    value={employeeTask.title}
                    onChange={e => setEmployeeTask({ ...employeeTask, title: e.target.value })}
                    data-testid="input-employee-task-title"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">الأولوية</label>
                  <Select value={employeeTask.priority} onValueChange={v => setEmployeeTask({ ...employeeTask, priority: v })}>
                    <SelectTrigger className="mt-1.5" data-testid="select-employee-task-priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">منخفضة</SelectItem>
                      <SelectItem value="medium">متوسطة</SelectItem>
                      <SelectItem value="high">عالية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">تفاصيل المهمة</label>
                  <Textarea
                    className="mt-1.5"
                    rows={3}
                    placeholder="وصف تفصيلي للمهمة المطلوبة..."
                    value={employeeTask.description}
                    onChange={e => setEmployeeTask({ ...employeeTask, description: e.target.value })}
                    data-testid="input-employee-task-description"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">الموعد النهائي</label>
                  <Input
                    type="date"
                    className="mt-1.5"
                    value={employeeTask.dueDate}
                    onChange={e => setEmployeeTask({ ...employeeTask, dueDate: e.target.value })}
                    data-testid="input-employee-task-due-date"
                  />
                </div>
              </div>
            );
          })()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEmployeeTaskDialog(null)}>إلغاء</Button>
            <Button
              onClick={() => sendEmployeeTask.mutate({
                projectId: id,
                employeeId: employeeTaskDialog,
                title: employeeTask.title,
                description: employeeTask.description,
                dueDate: employeeTask.dueDate || null,
                priority: employeeTask.priority,
                status: "in_progress",
              })}
              disabled={!employeeTask.title.trim() || sendEmployeeTask.isPending}
              data-testid="button-send-employee-task"
            >
              إرسال المهمة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Field Visit Dialog */}
      <Dialog open={visitDialog} onOpenChange={setVisitDialog}>
        <DialogContent dir="rtl" className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>إضافة زيارة ميدانية</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium">تاريخ الزيارة <span className="text-destructive">*</span></label>
                <Input
                  type="date"
                  className="mt-1.5"
                  value={newVisit.visitDate}
                  onChange={(e) => setNewVisit({ ...newVisit, visitDate: e.target.value })}
                  data-testid="input-visit-date"
                />
              </div>
              <div>
                <label className="text-sm font-medium">وقت الزيارة</label>
                <Input
                  type="time"
                  className="mt-1.5"
                  value={newVisit.visitTime}
                  onChange={(e) => setNewVisit({ ...newVisit, visitTime: e.target.value })}
                  data-testid="input-visit-time"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">حالة الزيارة</label>
              <Select value={newVisit.visitStatus} onValueChange={(v) => setNewVisit({ ...newVisit, visitStatus: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-visit-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planned">مخططة</SelectItem>
                  <SelectItem value="completed">مكتملة</SelectItem>
                  <SelectItem value="cancelled">ملغاة</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">الموظف المسؤول</label>
              <Select value={newVisit.employeeId} onValueChange={(v) => setNewVisit({ ...newVisit, employeeId: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-visit-employee">
                  <SelectValue placeholder="اختر الموظف" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(e => (
                    <SelectItem key={e.id} value={e.id}>{e.name} — {e.specialty}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">الغرض من الزيارة</label>
              <Input
                className="mt-1.5"
                placeholder="قياس المساحات، معاينة الموقع، متابعة التنفيذ..."
                value={newVisit.purpose}
                onChange={(e) => setNewVisit({ ...newVisit, purpose: e.target.value })}
                data-testid="input-visit-purpose"
              />
            </div>
            <div>
              <label className="text-sm font-medium">الموقع</label>
              <Input
                className="mt-1.5"
                placeholder="عنوان الموقع أو الحي"
                value={newVisit.location}
                onChange={(e) => setNewVisit({ ...newVisit, location: e.target.value })}
                data-testid="input-visit-location"
              />
            </div>
            <div>
              <label className="text-sm font-medium">رابط قوقل ماب</label>
              <Input
                className="mt-1.5"
                dir="ltr"
                placeholder="https://maps.google.com/..."
                value={newVisit.googleMapsUrl}
                onChange={(e) => setNewVisit({ ...newVisit, googleMapsUrl: e.target.value })}
                data-testid="input-visit-google-maps"
              />
            </div>
            <div>
              <label className="text-sm font-medium">نتائج وملاحظات الزيارة</label>
              <Textarea
                className="mt-1.5 resize-none"
                rows={3}
                placeholder="القياسات، الملاحظات الميدانية، نتائج المعاينة..."
                value={newVisit.findings}
                onChange={(e) => setNewVisit({ ...newVisit, findings: e.target.value })}
                data-testid="input-visit-findings"
              />
            </div>
            <div>
              <label className="text-sm font-medium">ملاحظات إضافية</label>
              <Textarea
                className="mt-1.5 resize-none"
                rows={2}
                placeholder="أي ملاحظات أخرى..."
                value={newVisit.notes}
                onChange={(e) => setNewVisit({ ...newVisit, notes: e.target.value })}
                data-testid="input-visit-notes"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setVisitDialog(false)}>إلغاء</Button>
            <Button
              onClick={() => createVisit.mutate({
                projectId: id,
                employeeId: newVisit.employeeId || null,
                visitDate: newVisit.visitTime ? `${newVisit.visitDate} ${newVisit.visitTime}` : newVisit.visitDate,
                location: newVisit.location || null,
                googleMapsUrl: newVisit.googleMapsUrl || null,
                purpose: newVisit.purpose || null,
                notes: newVisit.notes || null,
                status: newVisit.visitStatus as any,
                findings: newVisit.findings || null,
              })}
              disabled={!newVisit.visitDate || createVisit.isPending}
              data-testid="button-save-visit"
            >
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Phase File Upload Dialog */}
      <Dialog open={!!phaseFileDialog} onOpenChange={() => setPhaseFileDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>رفع ملف للمرحلة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">اسم الملف</label>
              <Input
                className="mt-1.5"
                placeholder="ملف التصميم..."
                value={newFile.fileName}
                onChange={(e) => setNewFile({ ...newFile, fileName: e.target.value })}
                data-testid="input-phase-file-name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">رابط الملف</label>
              <Input
                className="mt-1.5"
                placeholder="https://drive.google.com/..."
                value={newFile.fileUrl}
                onChange={(e) => setNewFile({ ...newFile, fileUrl: e.target.value })}
                data-testid="input-phase-file-url"
              />
            </div>
            <div>
              <label className="text-sm font-medium">نوع الرابط</label>
              <Select value={newFile.fileType} onValueChange={(v) => setNewFile({ ...newFile, fileType: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-phase-file-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="google_drive">Google Drive</SelectItem>
                  <SelectItem value="telegram">Telegram</SelectItem>
                  <SelectItem value="other">رابط آخر</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPhaseFileDialog(null)}>إلغاء</Button>
            <Button
              onClick={() => createFile.mutate({
                projectId: id,
                phaseId: phaseFileDialog,
                fileName: newFile.fileName,
                fileUrl: newFile.fileUrl,
                fileType: newFile.fileType,
                description: null,
                uploadedBy: user?.employeeId || null,
              })}
              disabled={!newFile.fileName || !newFile.fileUrl || createFile.isPending}
              data-testid="button-save-phase-file"
            >
              رفع
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add File Dialog */}
      <Dialog open={fileDialog} onOpenChange={setFileDialog}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إضافة رابط ملف</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">اسم الملف</label>
              <Input
                className="mt-1.5"
                placeholder="مخطط الطابق الأول..."
                value={newFile.fileName}
                onChange={(e) => setNewFile({ ...newFile, fileName: e.target.value })}
                data-testid="input-file-name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">رابط الملف</label>
              <Input
                className="mt-1.5"
                placeholder="https://drive.google.com/..."
                value={newFile.fileUrl}
                onChange={(e) => setNewFile({ ...newFile, fileUrl: e.target.value })}
                data-testid="input-file-url"
              />
            </div>
            <div>
              <label className="text-sm font-medium">نوع الرابط</label>
              <Select value={newFile.fileType} onValueChange={(v) => setNewFile({ ...newFile, fileType: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-file-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="google_drive">Google Drive</SelectItem>
                  <SelectItem value="telegram">Telegram</SelectItem>
                  <SelectItem value="other">رابط آخر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">الوصف</label>
              <Input
                className="mt-1.5"
                placeholder="وصف اختياري للملف..."
                value={newFile.description}
                onChange={(e) => setNewFile({ ...newFile, description: e.target.value })}
                data-testid="input-file-description"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFileDialog(false)}>إلغاء</Button>
            <Button
              onClick={() => createFile.mutate({
                projectId: id,
                fileName: newFile.fileName,
                fileUrl: newFile.fileUrl,
                fileType: newFile.fileType,
                description: newFile.description || null,
                uploadedBy: null,
              })}
              disabled={!newFile.fileName || !newFile.fileUrl || createFile.isPending}
              data-testid="button-save-file"
            >
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Term Dialog */}
      <Dialog open={!!termDialog} onOpenChange={() => setTermDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إضافة بند جديد</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">نص البند</label>
              <Textarea
                className="mt-1.5 min-h-[120px]"
                placeholder="اكتب نص البند هنا..."
                value={termDialog?.termText || ""}
                onChange={(e) => termDialog && setTermDialog({ ...termDialog, termText: e.target.value })}
                data-testid="input-term-text"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTermDialog(null)}>إلغاء</Button>
            <Button
              onClick={() => termDialog && contract && addContractTerm.mutate({
                contractId: contract.id,
                termText: termDialog.termText,
                termOrder: termDialog.termOrder,
              })}
              disabled={!termDialog?.termText || addContractTerm.isPending}
              data-testid="button-save-term"
            >
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
