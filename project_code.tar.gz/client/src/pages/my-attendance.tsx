import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, CheckCircle, Clock, XCircle } from "lucide-react";
import type { Attendance } from "@shared/schema";

const statusLabels: Record<string, string> = {
  present: "حاضر",
  absent: "غائب",
  late: "متأخر",
  leave: "إجازة",
};
const statusColors: Record<string, string> = {
  present: "bg-green-100 text-green-700",
  absent: "bg-red-100 text-red-700",
  late: "bg-yellow-100 text-yellow-700",
  leave: "bg-blue-100 text-blue-700",
};
const statusIcons: Record<string, any> = {
  present: CheckCircle,
  absent: XCircle,
  late: Clock,
  leave: Calendar,
};

export default function MyAttendance() {
  const { data: records, isLoading } = useQuery<Attendance[]>({ queryKey: ["/api/my/attendance"] });

  if (isLoading) {
    return (
      <div className="p-6 space-y-4 overflow-auto h-full" dir="rtl">
        <Skeleton className="h-10 w-48" />
        <div className="space-y-3">{[1, 2, 3].map(i => <Skeleton key={i} className="h-16" />)}</div>
      </div>
    );
  }

  const presentCount = records?.filter(r => r.status === "present").length || 0;
  const absentCount = records?.filter(r => r.status === "absent").length || 0;
  const lateCount = records?.filter(r => r.status === "late").length || 0;

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-page-title">سجل الحضور</h1>
        <p className="text-muted-foreground">سجل حضوري وغيابي</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <div>
              <p className="text-sm text-muted-foreground">حضور</p>
              <p className="text-xl font-bold" data-testid="text-present-count">{presentCount}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <Clock className="h-5 w-5 text-yellow-500" />
            <div>
              <p className="text-sm text-muted-foreground">تأخير</p>
              <p className="text-xl font-bold" data-testid="text-late-count">{lateCount}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <XCircle className="h-5 w-5 text-red-500" />
            <div>
              <p className="text-sm text-muted-foreground">غياب</p>
              <p className="text-xl font-bold" data-testid="text-absent-count">{absentCount}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">السجل التفصيلي</CardTitle></CardHeader>
        <CardContent>
          {(!records || records.length === 0) ? (
            <p className="text-muted-foreground text-center py-8">لا توجد سجلات حضور</p>
          ) : (
            <div className="space-y-2">
              {records.map(record => {
                const Icon = statusIcons[record.status] || Calendar;
                return (
                  <div key={record.id} className="flex items-center justify-between p-3 rounded-lg border" data-testid={`attendance-${record.id}`}>
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium text-sm">{record.date}</p>
                        {record.notes && <p className="text-xs text-muted-foreground">{record.notes}</p>}
                      </div>
                    </div>
                    <Badge className={statusColors[record.status]} variant="secondary">
                      {statusLabels[record.status]}
                    </Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
