import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertProjectSchema, type Project, type InsertProject, type Client, type Payment } from "@shared/schema";
import { z } from "zod";
import { Plus, Search, Edit, Trash2, FolderOpen, Eye, MapPin, Calendar, AlertTriangle, Clock, ExternalLink, LayoutGrid, Tag } from "lucide-react";
import { useLocation } from "wouter";
import { formatCurrency, getStatusLabel, getProjectTypeLabel, formatDate, getDaysUntil } from "@/lib/utils";

const projectFormSchema = insertProjectSchema.extend({
  totalValue: z.coerce.number().min(1, "يجب إدخال قيمة العقد"),
  areaSqm: z.coerce.number().optional(),
  pricePerSqm: z.coerce.number().optional(),
  paymentSchedule: z.coerce.number().min(1).max(3).default(3),
  googleMapsUrl: z.string().optional(),
});

type ProjectFormData = z.infer<typeof projectFormSchema>;

function getProjectUrgency(project: Project, payments: Payment[]): { level: "urgent" | "warning" | "normal" | "inactive"; label: string; color: string } {
  const daysLeft = getDaysUntil(project.endDate);
  const projectPayments = payments.filter(p => p.projectId === project.id);
  const firstPayment = projectPayments.find(p => p.paymentNumber === 1);

  if (project.status === "completed") return { level: "normal", label: "مكتمل", color: "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300" };
  if (project.status === "paused") return { level: "warning", label: "متوقف", color: "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300" };
  if (project.status === "cancelled") return { level: "inactive", label: "ملغي", color: "bg-gray-50 text-gray-700 dark:bg-gray-950 dark:text-gray-300" };

  if (project.startDate && firstPayment && firstPayment.status !== "paid") {
    const startDate = new Date(project.startDate);
    const now = new Date();
    const daysSinceStart = Math.ceil((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    if (daysSinceStart >= 15) {
      return { level: "inactive", label: "غير نشط - لم تسلم الدفعة الأولى", color: "bg-gray-100 text-gray-600 dark:bg-gray-900 dark:text-gray-400" };
    }
  }

  if (daysLeft !== null) {
    if (daysLeft < 0) return { level: "urgent", label: `متأخر ${Math.abs(daysLeft)} يوم`, color: "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300" };
    if (daysLeft <= 7) return { level: "urgent", label: `${daysLeft} يوم متبقي`, color: "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300" };
    if (daysLeft <= 14) return { level: "warning", label: `${daysLeft} يوم متبقي`, color: "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300" };
  }

  return { level: "normal", label: "نشط", color: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300" };
}

const projectTypeColors: Record<string, string> = {
  interior: "bg-violet-50 text-violet-700 dark:bg-violet-950 dark:text-violet-300",
  exterior: "bg-sky-50 text-sky-700 dark:bg-sky-950 dark:text-sky-300",
  facades: "bg-orange-50 text-orange-700 dark:bg-orange-950 dark:text-orange-300",
};

const urgencyOrder = { urgent: 0, warning: 1, normal: 2, inactive: 3 };

export default function Projects() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editProject, setEditProject] = useState<Project | null>(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [groupBy, setGroupBy] = useState<"urgency" | "type" | "month" | "status">("urgency");

  const { data: projects = [], isLoading } = useQuery<Project[]>({ queryKey: ["/api/projects"] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: payments = [] } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });

  const form = useForm<ProjectFormData>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      clientId: "",
      projectType: "exterior",
      title: "",
      description: "",
      totalValue: 0,
      areaSqm: undefined,
      pricePerSqm: undefined,
      status: "active",
      location: "",
      googleMapsUrl: "",
      startDate: "",
      endDate: "",
      paymentSchedule: 3,
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: ProjectFormData) => apiRequest("POST", "/api/projects", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم إنشاء المشروع بنجاح" });
      setDialogOpen(false);
      form.reset();
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<ProjectFormData> }) =>
      apiRequest("PUT", `/api/projects/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "تم تحديث المشروع" });
      setDialogOpen(false);
      setEditProject(null);
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/projects/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم حذف المشروع" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const filtered = projects
    .filter(p => {
      const matchSearch = p.title.toLowerCase().includes(search.toLowerCase()) ||
        (p.location || "").toLowerCase().includes(search.toLowerCase());
      const matchStatus = filterStatus === "all" || p.status === filterStatus;
      return matchSearch && matchStatus;
    })
    .sort((a, b) => {
      const urgA = getProjectUrgency(a, payments);
      const urgB = getProjectUrgency(b, payments);
      const orderDiff = urgencyOrder[urgA.level] - urgencyOrder[urgB.level];
      if (orderDiff !== 0) return orderDiff;
      const daysA = getDaysUntil(a.endDate);
      const daysB = getDaysUntil(b.endDate);
      if (daysA !== null && daysB !== null) return daysA - daysB;
      if (daysA !== null) return -1;
      if (daysB !== null) return 1;
      return 0;
    });

  const arMonths = ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];

  function getGroupKey(p: Project): string {
    if (groupBy === "type") return p.projectType;
    if (groupBy === "status") return p.status || "active";
    if (groupBy === "month") {
      if (!p.startDate) return "بدون تاريخ";
      const d = new Date(p.startDate);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    }
    return getProjectUrgency(p, payments).level;
  }

  function getGroupLabel(key: string): string {
    if (groupBy === "type") return { interior: "تصميم داخلي", exterior: "تصميم خارجي", facades: "واجهات" }[key] || key;
    if (groupBy === "status") return { active: "نشط", completed: "مكتمل", paused: "متوقف", cancelled: "ملغي" }[key] || key;
    if (groupBy === "month") {
      if (key === "بدون تاريخ") return key;
      const [y, m] = key.split("-");
      return `${arMonths[parseInt(m) - 1]} ${y}`;
    }
    return { urgent: "عاجل", warning: "تحذير", normal: "عادي", inactive: "غير نشط" }[key] || key;
  }

  function getGroupColor(key: string): string {
    if (groupBy === "type") return { interior: "bg-violet-50 border-violet-400 text-violet-700 dark:bg-violet-950 dark:text-violet-300", exterior: "bg-sky-50 border-sky-400 text-sky-700 dark:bg-sky-950 dark:text-sky-300", facades: "bg-orange-50 border-orange-400 text-orange-700 dark:bg-orange-950 dark:text-orange-300" }[key] || "";
    if (groupBy === "status") return { active: "bg-emerald-50 border-emerald-400 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300", completed: "bg-blue-50 border-blue-400 text-blue-700 dark:bg-blue-950 dark:text-blue-300", paused: "bg-amber-50 border-amber-400 text-amber-700 dark:bg-amber-950 dark:text-amber-300", cancelled: "bg-gray-50 border-gray-400 text-gray-700 dark:bg-gray-950 dark:text-gray-300" }[key] || "";
    if (groupBy === "urgency") return { urgent: "bg-red-50 border-red-400 text-red-700 dark:bg-red-950 dark:text-red-300", warning: "bg-amber-50 border-amber-400 text-amber-700 dark:bg-amber-950 dark:text-amber-300", normal: "bg-emerald-50 border-emerald-400 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300", inactive: "bg-gray-50 border-gray-400 text-gray-600 dark:bg-gray-900 dark:text-gray-400" }[key] || "";
    return "bg-muted border-muted-foreground/30 text-foreground";
  }

  const groupedMap = new Map<string, Project[]>();
  filtered.forEach(p => {
    const k = getGroupKey(p);
    if (!groupedMap.has(k)) groupedMap.set(k, []);
    groupedMap.get(k)!.push(p);
  });

  const groupOrder = groupBy === "urgency"
    ? ["urgent", "warning", "normal", "inactive"]
    : groupBy === "type"
    ? ["interior", "exterior", "facades"]
    : groupBy === "status"
    ? ["active", "completed", "paused", "cancelled"]
    : Array.from(groupedMap.keys()).sort();

  const sortedGroups = groupOrder.filter(k => groupedMap.has(k))
    .concat(Array.from(groupedMap.keys()).filter(k => !groupOrder.includes(k)).sort());

  function openAdd() {
    setEditProject(null);
    form.reset();
    setDialogOpen(true);
  }

  function openEdit(p: Project) {
    setEditProject(p);
    form.reset({
      clientId: p.clientId,
      projectType: p.projectType,
      title: p.title,
      description: p.description || "",
      totalValue: p.totalValue,
      areaSqm: p.areaSqm || undefined,
      pricePerSqm: p.pricePerSqm || undefined,
      status: p.status || "active",
      location: p.location || "",
      googleMapsUrl: (p as any).googleMapsUrl || "",
      startDate: p.startDate || "",
      endDate: p.endDate || "",
      paymentSchedule: p.paymentSchedule || 3,
    });
    setDialogOpen(true);
  }

  function onSubmit(data: ProjectFormData) {
    if (editProject) {
      updateMutation.mutate({ id: editProject.id, data });
    } else {
      createMutation.mutate(data);
    }
  }

  const getClientName = (id: string) => clients.find(c => c.id === id)?.name || "غير معروف";

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">المشاريع</h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة مشاريع التصميم الداخلي والخارجي والواجهات</p>
        </div>
        <Button onClick={openAdd} data-testid="button-add-project">
          <Plus className="h-4 w-4 ml-2" />
          مشروع جديد
        </Button>
      </div>

      <div className="flex gap-3 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بعنوان المشروع أو الموقع..."
            className="pr-10"
            value={search}
            onChange={e => setSearch(e.target.value)}
            data-testid="input-search-projects"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-36" data-testid="select-filter-status">
            <SelectValue placeholder="الحالة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="active">نشط</SelectItem>
            <SelectItem value="completed">مكتمل</SelectItem>
            <SelectItem value="paused">متوقف</SelectItem>
            <SelectItem value="cancelled">ملغي</SelectItem>
          </SelectContent>
        </Select>
        <Select value={groupBy} onValueChange={(v: any) => setGroupBy(v)}>
          <SelectTrigger className="w-40" data-testid="select-group-by">
            <Tag className="h-3.5 w-3.5 ml-1 text-muted-foreground" />
            <SelectValue placeholder="تجميع حسب" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="urgency">الأولوية</SelectItem>
            <SelectItem value="type">التصنيف</SelectItem>
            <SelectItem value="month">الشهر</SelectItem>
            <SelectItem value="status">الحالة</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <FolderOpen className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground font-medium">لا توجد مشاريع</p>
            <Button onClick={openAdd} className="mt-4">
              <Plus className="h-4 w-4 ml-2" />
              مشروع جديد
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {sortedGroups.map(groupKey => {
            const groupProjects = groupedMap.get(groupKey) || [];
            const groupTotal = groupProjects.reduce((s, p) => s + p.totalValue, 0);
            const colorClass = getGroupColor(groupKey);
            return (
              <div key={groupKey}>
                <div className={`flex items-center gap-3 mb-3 px-3 py-2 rounded-lg border ${colorClass}`}>
                  <span className="font-bold text-sm">{getGroupLabel(groupKey)}</span>
                  <Badge variant="secondary" className="text-xs">{groupProjects.length} مشروع</Badge>
                  <span className="text-xs font-semibold mr-auto">{formatCurrency(groupTotal)}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {groupProjects.map((project) => {
            const urgency = getProjectUrgency(project, payments);
            const cardBg = urgency.level === "urgent" ? "bg-red-50/60 dark:bg-red-950/20 border-r-4 border-r-red-500" :
              urgency.level === "inactive" ? "bg-gray-50/60 dark:bg-gray-900/30 border-r-4 border-r-gray-400 opacity-70" :
              urgency.level === "warning" ? "bg-amber-50/40 dark:bg-amber-950/15 border-r-4 border-r-amber-500" :
              project.status === "completed" ? "bg-emerald-50/40 dark:bg-emerald-950/15 border-r-4 border-r-emerald-500" :
              "border-r-4 border-r-blue-500";
            return (
            <Card key={project.id} className={`hover-elevate ${cardBg}`} data-testid={`card-project-${project.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <Badge className={`text-xs ${projectTypeColors[project.projectType] || projectTypeColors.exterior}`}>
                        {getProjectTypeLabel(project.projectType)}
                      </Badge>
                      <Badge className={`text-xs ${urgency.color}`}>
                        {urgency.level === "urgent" && <AlertTriangle className="h-3 w-3 ml-1" />}
                        {urgency.label}
                      </Badge>
                    </div>
                    <CardTitle className="text-base leading-tight">{project.title}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-0.5">{getClientName(project.clientId)}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">قيمة العقد</span>
                    <span className="text-sm font-bold text-primary">{formatCurrency(project.totalValue)}</span>
                  </div>
                  {project.areaSqm && (
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">المساحة</span>
                      <span className="text-sm">{project.areaSqm} م²</span>
                    </div>
                  )}
                  {project.location && (
                    <div className="flex items-center gap-1.5">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{project.location}</span>
                    </div>
                  )}
                  {(project as any).googleMapsUrl && (
                    <a
                      href={(project as any).googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 text-primary hover:underline"
                      data-testid={`link-map-${project.id}`}
                    >
                      <ExternalLink className="h-3 w-3" />
                      <span className="text-xs">عرض على الخريطة</span>
                    </a>
                  )}
                  {(project.startDate || project.endDate) && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <Calendar className="h-3 w-3 text-muted-foreground shrink-0" />
                      {project.startDate && (
                        <span className="text-xs text-muted-foreground">البدء: <span className="font-medium text-foreground">{formatDate(project.startDate)}</span></span>
                      )}
                      {project.startDate && project.endDate && (
                        <span className="text-xs text-muted-foreground">←</span>
                      )}
                      {project.endDate && (
                        <span className="text-xs text-muted-foreground">التسليم: <span className="font-medium text-foreground">{formatDate(project.endDate)}</span></span>
                      )}
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => navigate(`/projects/${project.id}`)}
                    data-testid={`button-view-project-${project.id}`}
                  >
                    <Eye className="h-3.5 w-3.5 ml-1" />
                    التفاصيل
                  </Button>
                  <Button size="icon" variant="outline" onClick={() => openEdit(project)} data-testid={`button-edit-project-${project.id}`}>
                    <Edit className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => deleteMutation.mutate(project.id)}
                    disabled={deleteMutation.isPending}
                    data-testid={`button-delete-project-${project.id}`}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
          })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editProject ? "تعديل المشروع" : "إضافة مشروع جديد"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="clientId" render={({ field }) => (
                <FormItem>
                  <FormLabel>العميل *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-project-client">
                        <SelectValue placeholder="اختر العميل" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {clients.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="projectType" render={({ field }) => (
                  <FormItem>
                    <FormLabel>نوع المشروع *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-project-type">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="interior">تصميم داخلي</SelectItem>
                        <SelectItem value="exterior">تصميم خارجي</SelectItem>
                        <SelectItem value="facades">واجهات</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الحالة</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "active"}>
                      <FormControl>
                        <SelectTrigger data-testid="select-project-status">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="active">نشط</SelectItem>
                        <SelectItem value="completed">مكتمل</SelectItem>
                        <SelectItem value="paused">متوقف</SelectItem>
                        <SelectItem value="cancelled">ملغي</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="title" render={({ field }) => (
                <FormItem>
                  <FormLabel>عنوان المشروع *</FormLabel>
                  <FormControl><Input placeholder="مثال: فيلا الرياض" {...field} data-testid="input-project-title" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="location" render={({ field }) => (
                <FormItem>
                  <FormLabel>الموقع</FormLabel>
                  <FormControl><Input placeholder="المدينة، الحي" {...field} value={field.value ?? ""} data-testid="input-project-location" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="googleMapsUrl" render={({ field }) => (
                <FormItem>
                  <FormLabel>رابط قوقل ماب</FormLabel>
                  <FormControl><Input placeholder="https://maps.google.com/..." {...field} value={field.value ?? ""} data-testid="input-project-google-maps" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-3 gap-3">
                <FormField control={form.control} name="totalValue" render={({ field }) => (
                  <FormItem>
                    <FormLabel>قيمة العقد (ريال) *</FormLabel>
                    <FormControl><Input type="number" placeholder="50000" {...field} data-testid="input-project-value" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="areaSqm" render={({ field }) => (
                  <FormItem>
                    <FormLabel>المساحة (م²)</FormLabel>
                    <FormControl><Input type="number" placeholder="200" {...field} value={field.value ?? ""} data-testid="input-project-area" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="pricePerSqm" render={({ field }) => (
                  <FormItem>
                    <FormLabel>سعر المتر</FormLabel>
                    <FormControl><Input type="number" placeholder="250" {...field} value={field.value ?? ""} data-testid="input-project-price-sqm" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="paymentSchedule" render={({ field }) => (
                <FormItem>
                  <FormLabel>عدد الدفعات</FormLabel>
                  <Select onValueChange={(v) => field.onChange(parseInt(v))} value={String(field.value || 3)}>
                    <FormControl>
                      <SelectTrigger data-testid="select-payment-schedule">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">دفعة واحدة (100% عند التوقيع)</SelectItem>
                      <SelectItem value="2">دفعتان (50% توقيع + 50% اعتماد)</SelectItem>
                      <SelectItem value="3">3 دفعات (50% + 30% + 20%)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="startDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>تاريخ البدء</FormLabel>
                    <FormControl><Input type="date" {...field} value={field.value ?? ""} data-testid="input-project-start" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="endDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>تاريخ الانتهاء</FormLabel>
                    <FormControl><Input type="date" {...field} value={field.value ?? ""} data-testid="input-project-end" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem>
                  <FormLabel>الوصف</FormLabel>
                  <FormControl><Textarea placeholder="وصف المشروع..." {...field} value={field.value ?? ""} data-testid="input-project-description" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <DialogFooter className="gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-project">
                  {editProject ? "حفظ التغييرات" : "إنشاء المشروع"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
