import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CheckSquare, Clock, CheckCircle, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import type { Task, Project, Employee } from "@shared/schema";

const priorityLabels: Record<string, string> = { high: "عالية", medium: "متوسطة", low: "منخفضة" };
const priorityColors: Record<string, string> = {
  high: "bg-red-100 text-red-700",
  medium: "bg-yellow-100 text-yellow-700",
  low: "bg-green-100 text-green-700",
};
const statusLabels: Record<string, string> = {
  pending: "قيد الانتظار",
  in_progress: "جاري التنفيذ",
  completed: "مكتمل",
  overdue: "متأخر",
};

function canSendTasks(employee: Employee | undefined): boolean {
  if (!employee) return false;
  const spec = ((employee as any).jobTitle || employee.specialty || "");
  if (spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي")) return true;
  if (spec.includes("خدمة عملاء") || spec.includes("تسويق")) return true;
  return false;
}

export default function MyTasks() {
  const { toast } = useToast();
  const { user } = useAuth();
  const { data: tasks, isLoading } = useQuery<Task[]>({ queryKey: ["/api/my/tasks"] });
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const { data: myProjects = [] } = useQuery<Project[]>({ queryKey: ["/api/my/projects"] });

  const myEmployee = user?.employeeId ? employees.find(e => e.id === user.employeeId) : undefined;
  const hasSendPermission = canSendTasks(myEmployee);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [newTask, setNewTask] = useState({
    title: "", description: "", projectId: "", employeeId: "", priority: "medium", dueDate: "",
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      await apiRequest("PUT", `/api/tasks/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my/dashboard"] });
      toast({ title: "تم تحديث حالة المهمة" });
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/tasks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my/dashboard"] });
      toast({ title: "تم إرسال المهمة بنجاح" });
      setDialogOpen(false);
      setNewTask({ title: "", description: "", projectId: "", employeeId: "", priority: "medium", dueDate: "" });
    },
    onError: () => toast({ title: "خطأ في إرسال المهمة", variant: "destructive" }),
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-4 overflow-auto h-full" dir="rtl">
        <Skeleton className="h-10 w-48" />
        <div className="space-y-3">{[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-24" />)}</div>
      </div>
    );
  }

  const activeTasks = tasks?.filter(t => t.status !== "completed") || [];
  const completedTasks = tasks?.filter(t => t.status === "completed") || [];

  const internalEmployees = employees.filter(e => e.employeeType === "internal" && e.id !== user?.employeeId);
  const freelancerEmployees = employees.filter(e => e.employeeType === "freelancer");
  const assignableEmployees = [...internalEmployees, ...freelancerEmployees];

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">مهامي</h1>
          <p className="text-muted-foreground">المهام المكلف بها</p>
        </div>
        {hasSendPermission && (
          <Button onClick={() => setDialogOpen(true)} data-testid="button-create-task">
            <Plus className="h-4 w-4 ml-2" />
            إرسال مهمة
          </Button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <Clock className="h-5 w-5 text-orange-500" />
            <div>
              <p className="text-sm text-muted-foreground">معلقة</p>
              <p className="text-xl font-bold">{activeTasks.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <div>
              <p className="text-sm text-muted-foreground">مكتملة</p>
              <p className="text-xl font-bold">{completedTasks.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <CheckSquare className="h-5 w-5 text-blue-500" />
            <div>
              <p className="text-sm text-muted-foreground">الإجمالي</p>
              <p className="text-xl font-bold">{tasks?.length || 0}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {activeTasks.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-lg">المهام النشطة</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {activeTasks.map(task => {
              const taskEmp = task.employeeId ? employees.find(e => e.id === task.employeeId) : null;
              const taskProject = task.projectId ? myProjects.find(p => p.id === task.projectId) : null;
              return (
              <div key={task.id} className="flex items-center justify-between p-4 rounded-lg border" data-testid={`task-active-${task.id}`}>
                <div className="flex-1">
                  <p className="font-medium">{task.title}</p>
                  {task.description && <p className="text-sm text-muted-foreground mt-1">{task.description}</p>}
                  <div className="flex items-center gap-3 mt-2 flex-wrap">
                    {taskEmp && taskEmp.id !== user?.employeeId && (
                      <Badge variant="outline" className="text-xs">المكلف: {taskEmp.name}</Badge>
                    )}
                    {taskProject && (
                      <Badge variant="outline" className="text-xs">{taskProject.title}</Badge>
                    )}
                    {task.dueDate && <span className="text-xs text-muted-foreground">التسليم: {task.dueDate}</span>}
                    <Badge className={priorityColors[task.priority || "medium"]} variant="secondary">
                      {priorityLabels[task.priority || "medium"]}
                    </Badge>
                    <Badge variant="outline">{statusLabels[task.status || "pending"]}</Badge>
                    {!task.projectId && (
                      <Badge variant="outline" className="text-xs" data-testid={`badge-side-task-${task.id}`}>مهمة جانبية</Badge>
                    )}
                  </div>
                </div>
                <div className="flex gap-2 mr-4">
                  {task.status === "pending" && (
                    <Button size="sm" variant="outline" onClick={() => updateMutation.mutate({ id: task.id, status: "in_progress" })} data-testid={`button-start-${task.id}`}>
                      بدء العمل
                    </Button>
                  )}
                  {(task.status === "pending" || task.status === "in_progress") && (
                    <Button size="sm" onClick={() => updateMutation.mutate({ id: task.id, status: "completed" })} data-testid={`button-complete-${task.id}`}>
                      إكمال
                    </Button>
                  )}
                </div>
              </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {completedTasks.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-lg text-muted-foreground">المهام المكتملة</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {completedTasks.map(task => (
              <div key={task.id} className="flex items-center justify-between p-4 rounded-lg border opacity-60" data-testid={`task-completed-${task.id}`}>
                <div className="flex-1">
                  <p className="font-medium line-through">{task.title}</p>
                  <div className="flex items-center gap-3 mt-2">
                    {task.dueDate && <span className="text-xs text-muted-foreground">التسليم: {task.dueDate}</span>}
                    <Badge variant="secondary" className="bg-green-100 text-green-700">مكتمل</Badge>
                    {!task.projectId && (
                      <Badge variant="outline" className="text-xs" data-testid={`badge-side-task-completed-${task.id}`}>مهمة جانبية</Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {(!tasks || tasks.length === 0) && (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckSquare className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">لا توجد مهام مكلف بها حالياً</p>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إرسال مهمة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">عنوان المهمة *</label>
              <Input
                className="mt-1.5"
                placeholder="مثال: مراجعة تصميم الطابق الأول"
                value={newTask.title}
                onChange={e => setNewTask({ ...newTask, title: e.target.value })}
                data-testid="input-task-title"
              />
            </div>
            <div>
              <label className="text-sm font-medium">المشروع</label>
              <Select value={newTask.projectId} onValueChange={v => setNewTask({ ...newTask, projectId: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-task-project">
                  <SelectValue placeholder="اختر المشروع (اختياري)" />
                </SelectTrigger>
                <SelectContent>
                  {myProjects.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">المكلف بالمهمة *</label>
              <Select value={newTask.employeeId} onValueChange={v => setNewTask({ ...newTask, employeeId: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-task-employee">
                  <SelectValue placeholder="اختر الموظف" />
                </SelectTrigger>
                <SelectContent>
                  {assignableEmployees.map(e => (
                    <SelectItem key={e.id} value={e.id}>
                      {e.name} {e.employeeType === "freelancer" ? "(مستقل)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">الأولوية</label>
              <Select value={newTask.priority} onValueChange={v => setNewTask({ ...newTask, priority: v })}>
                <SelectTrigger className="mt-1.5" data-testid="select-task-priority">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">منخفضة</SelectItem>
                  <SelectItem value="medium">متوسطة</SelectItem>
                  <SelectItem value="high">عالية</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">التفاصيل</label>
              <Textarea
                className="mt-1.5"
                rows={3}
                placeholder="وصف تفصيلي للمهمة..."
                value={newTask.description}
                onChange={e => setNewTask({ ...newTask, description: e.target.value })}
                data-testid="input-task-description"
              />
            </div>
            <div>
              <label className="text-sm font-medium">الموعد النهائي</label>
              <Input
                type="date"
                className="mt-1.5"
                value={newTask.dueDate}
                onChange={e => setNewTask({ ...newTask, dueDate: e.target.value })}
                data-testid="input-task-due-date"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button
              onClick={() => createMutation.mutate({
                title: newTask.title,
                projectId: newTask.projectId || null,
                employeeId: newTask.employeeId || null,
                priority: newTask.priority,
                description: newTask.description || null,
                dueDate: newTask.dueDate || null,
                status: "in_progress",
              })}
              disabled={!newTask.title.trim() || !newTask.employeeId || createMutation.isPending}
              data-testid="button-submit-task"
            >
              إرسال المهمة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
