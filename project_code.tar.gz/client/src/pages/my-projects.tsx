import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { FolderOpen, MapPin, Calendar } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import type { Project, Employee } from "@shared/schema";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

const statusLabels: Record<string, string> = {
  active: "نشط",
  completed: "مكتمل",
  paused: "متوقف",
  cancelled: "ملغي",
};
const statusColors: Record<string, string> = {
  active: "bg-blue-100 text-blue-700",
  completed: "bg-green-100 text-green-700",
  paused: "bg-yellow-100 text-yellow-700",
  cancelled: "bg-red-100 text-red-700",
};
const typeLabels: Record<string, string> = { interior: "داخلي", exterior: "خارجي" };

function isInteriorOnly(employee: Employee | undefined): boolean {
  if (!employee) return false;
  const spec = ((employee as any).jobTitle || employee.specialty || "");
  return spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي");
}

export default function MyProjects() {
  const { user } = useAuth();
  const { data: projects, isLoading } = useQuery<Project[]>({ queryKey: ["/api/my/projects"] });
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });

  const myEmployee = user?.employeeId ? employees.find(e => e.id === user.employeeId) : undefined;
  const interiorOnly = isInteriorOnly(myEmployee);
  const filteredProjects = interiorOnly ? projects?.filter(p => p.projectType === "interior") : projects;

  if (isLoading) {
    return (
      <div className="p-6 space-y-4 overflow-auto h-full" dir="rtl">
        <Skeleton className="h-10 w-48" />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-48" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-page-title">مشاريعي</h1>
        <p className="text-muted-foreground">المشاريع المكلف بها ({filteredProjects?.length || 0})</p>
      </div>

      {(!filteredProjects || filteredProjects.length === 0) ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FolderOpen className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">لا توجد مشاريع مكلف بها حالياً</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProjects.map(project => (
            <Link key={project.id} href={`/projects/${project.id}`}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full" data-testid={`card-project-${project.id}`}>
                <CardContent className="pt-6 space-y-3">
                  <div className="flex items-start justify-between">
                    <h3 className="font-semibold">{project.title}</h3>
                    <Badge className={statusColors[project.status || "active"]} variant="secondary">
                      {statusLabels[project.status || "active"]}
                    </Badge>
                  </div>
                  <Badge variant="outline">{typeLabels[project.projectType]}</Badge>
                  {project.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">{project.description}</p>
                  )}
                  <div className="space-y-1.5 text-sm text-muted-foreground">
                    {project.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3.5 w-3.5" />
                        <span>{project.location}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{project.startDate} - {project.endDate || "غير محدد"}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t">
                    <span className="text-sm text-muted-foreground">القيمة</span>
                    <span className="font-semibold text-primary">{formatCurrency(project.totalValue)}</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
