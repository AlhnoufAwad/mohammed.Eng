import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTaskSchema, type Task, type InsertTask, type Project, type Employee } from "@shared/schema";
import { z } from "zod";
import { Plus, Search, Edit, Trash2, CheckSquare, Clock, AlertTriangle, CheckCircle2, Calendar } from "lucide-react";
import { formatDate, getStatusLabel, getDaysUntil } from "@/lib/utils";

const taskFormSchema = insertTaskSchema.extend({
  reminderDays: z.coerce.number().optional(),
  fee: z.coerce.number().nullable().optional(),
});
type TaskForm = z.infer<typeof taskFormSchema>;

const priorityColors: Record<string, string> = {
  low: "bg-gray-50 text-gray-600 dark:bg-gray-900 dark:text-gray-400",
  medium: "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
  high: "bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300",
};

const statusColors: Record<string, string> = {
  pending: "bg-gray-50 text-gray-600 dark:bg-gray-900 dark:text-gray-400",
  in_progress: "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
  completed: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
  overdue: "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300",
};

export default function Tasks() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTask, setEditTask] = useState<Task | null>(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");

  const { data: tasks = [], isLoading } = useQuery<Task[]>({ queryKey: ["/api/tasks"] });
  const { data: projects = [] } = useQuery<Project[]>({ queryKey: ["/api/projects"] });
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });

  const form = useForm<TaskForm>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: "", description: "", priority: "medium", status: "pending",
      dueDate: "", reminderDays: 3, isRecurring: false, notes: "",
      projectId: null, employeeId: null,
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: TaskForm) => apiRequest("POST", "/api/tasks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم إضافة المهمة" });
      setDialogOpen(false);
      form.reset();
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<TaskForm> }) =>
      apiRequest("PUT", `/api/tasks/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم تحديث المهمة" });
      setDialogOpen(false);
      setEditTask(null);
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/tasks/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم حذف المهمة" });
    },
  });

  const toggleComplete = (task: Task) => {
    updateMutation.mutate({
      id: task.id,
      data: { status: task.status === "completed" ? "pending" : "completed" },
    });
  };

  const filtered = tasks.filter(t => {
    const matchSearch = t.title.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "all" || t.status === filterStatus;
    const matchPriority = filterPriority === "all" || t.priority === filterPriority;
    return matchSearch && matchStatus && matchPriority;
  });

  function openAdd() {
    setEditTask(null);
    form.reset({ title: "", description: "", priority: "medium", status: "pending", dueDate: "", reminderDays: 3, isRecurring: false, projectId: null, employeeId: null, notes: "", fee: null });
    setDialogOpen(true);
  }

  function openEdit(task: Task) {
    setEditTask(task);
    form.reset({
      title: task.title, description: task.description || "",
      priority: task.priority || "medium", status: task.status || "pending",
      dueDate: task.dueDate || "", reminderDays: task.reminderDays || 3,
      projectId: task.projectId || null, employeeId: task.employeeId || null,
      isRecurring: task.isRecurring || false, notes: task.notes || "", fee: (task as any).fee || null,
    });
    setDialogOpen(true);
  }

  function onSubmit(data: TaskForm) {
    if (editTask) {
      updateMutation.mutate({ id: editTask.id, data });
    } else {
      createMutation.mutate(data);
    }
  }

  const getProjectName = (id: string | null) => id ? projects.find(p => p.id === id)?.title || "مشروع محذوف" : null;
  const getEmployeeName = (id: string | null) => id ? employees.find(e => e.id === id)?.name || "موظف محذوف" : null;

  const pending = filtered.filter(t => t.status === "pending" || t.status === "in_progress");
  const completed = filtered.filter(t => t.status === "completed");

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">المهام</h1>
          <p className="text-muted-foreground text-sm mt-1">متابعة وتوزيع المهام على الفريق</p>
        </div>
        <Button onClick={openAdd} data-testid="button-add-task">
          <Plus className="h-4 w-4 ml-2" />
          إضافة مهمة
        </Button>
      </div>

      <div className="flex gap-3 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث في المهام..."
            className="pr-10"
            value={search}
            onChange={e => setSearch(e.target.value)}
            data-testid="input-search-tasks"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-32" data-testid="select-filter-task-status">
            <SelectValue placeholder="الحالة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="pending">معلقة</SelectItem>
            <SelectItem value="in_progress">جارية</SelectItem>
            <SelectItem value="completed">مكتملة</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterPriority} onValueChange={setFilterPriority}>
          <SelectTrigger className="w-32" data-testid="select-filter-task-priority">
            <SelectValue placeholder="الأولوية" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="high">عالية</SelectItem>
            <SelectItem value="medium">متوسطة</SelectItem>
            <SelectItem value="low">منخفضة</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center py-16">
            <CheckSquare className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground">لا توجد مهام</p>
            <Button onClick={openAdd} className="mt-4"><Plus className="h-4 w-4 ml-2" />إضافة مهمة</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {pending.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                <Clock className="h-4 w-4" />
                المهام النشطة ({pending.length})
              </h3>
              <div className="space-y-2">
                {pending.map(task => {
                  const days = getDaysUntil(task.dueDate);
                  const isUrgent = days !== null && days <= 3;
                  return (
                    <Card key={task.id} className="hover-elevate" data-testid={`card-task-${task.id}`}>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => toggleComplete(task)}
                            className="flex-shrink-0"
                            data-testid={`button-complete-task-${task.id}`}
                          >
                            <div className={`h-5 w-5 rounded-full border-2 flex items-center justify-center ${
                              task.status === "in_progress" ? "border-blue-500 bg-blue-500" : "border-muted-foreground"
                            }`}>
                              {task.status === "in_progress" && <div className="h-2 w-2 bg-white rounded-full" />}
                            </div>
                          </button>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-medium text-sm">{task.title}</p>
                              {isUrgent && <AlertTriangle className="h-3.5 w-3.5 text-rose-500" />}
                            </div>
                            <div className="flex items-center gap-3 mt-1 flex-wrap">
                              {task.dueDate && (
                                <span className={`text-xs flex items-center gap-1 ${days !== null && days <= 0 ? "text-rose-500" : days !== null && days <= 3 ? "text-amber-500" : "text-muted-foreground"}`}>
                                  <Calendar className="h-3 w-3" />
                                  {days !== null && days <= 0 ? "متأخرة" : task.dueDate}
                                </span>
                              )}
                              {task.projectId ? (
                                <span className="text-xs text-muted-foreground">{getProjectName(task.projectId)}</span>
                              ) : (
                                <Badge variant="outline" className="text-xs" data-testid={`badge-side-task-${task.id}`}>مهمة جانبية</Badge>
                              )}
                              {getEmployeeName(task.employeeId) && (
                                <span className="text-xs text-muted-foreground">{getEmployeeName(task.employeeId)}</span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <Badge className={`text-xs ${priorityColors[task.priority || "medium"]}`}>
                              {getStatusLabel(task.priority || "medium")}
                            </Badge>
                            <Button size="icon" variant="ghost" onClick={() => openEdit(task)} data-testid={`button-edit-task-${task.id}`}>
                              <Edit className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(task.id)} data-testid={`button-delete-task-${task.id}`}>
                              <Trash2 className="h-3.5 w-3.5 text-destructive" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}

          {completed.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                المهام المكتملة ({completed.length})
              </h3>
              <div className="space-y-2">
                {completed.map(task => (
                  <Card key={task.id} className="opacity-60 hover-elevate" data-testid={`card-task-${task.id}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <button onClick={() => toggleComplete(task)} className="flex-shrink-0" data-testid={`button-complete-task-${task.id}`}>
                          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                        </button>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm line-through text-muted-foreground">{task.title}</p>
                          {!task.projectId && (
                            <Badge variant="outline" className="text-xs mt-1" data-testid={`badge-side-task-${task.id}`}>مهمة جانبية</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="icon" variant="ghost" onClick={() => openEdit(task)}><Edit className="h-3.5 w-3.5" /></Button>
                          <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(task.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editTask ? "تعديل المهمة" : "إضافة مهمة جديدة"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="title" render={({ field }) => (
                <FormItem>
                  <FormLabel>عنوان المهمة *</FormLabel>
                  <FormControl><Input placeholder="وصف المهمة..." {...field} data-testid="input-task-title" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="priority" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الأولوية</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "medium"}>
                      <FormControl><SelectTrigger data-testid="select-task-priority"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="low">منخفضة</SelectItem>
                        <SelectItem value="medium">متوسطة</SelectItem>
                        <SelectItem value="high">عالية</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الحالة</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "pending"}>
                      <FormControl><SelectTrigger data-testid="select-task-status"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="pending">معلقة</SelectItem>
                        <SelectItem value="in_progress">جارية</SelectItem>
                        <SelectItem value="completed">مكتملة</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="dueDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>تاريخ الاستحقاق</FormLabel>
                    <FormControl><Input type="date" {...field} value={field.value ?? ""} data-testid="input-task-due-date" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="reminderDays" render={({ field }) => (
                  <FormItem>
                    <FormLabel>التذكير (أيام قبل)</FormLabel>
                    <FormControl><Input type="number" placeholder="3" {...field} value={field.value ?? ""} data-testid="input-task-reminder" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="projectId" render={({ field }) => (
                <FormItem>
                  <FormLabel>المشروع (اختياري)</FormLabel>
                  <Select onValueChange={(v) => field.onChange(v === "none" ? null : v)} value={field.value || "none"}>
                    <FormControl><SelectTrigger data-testid="select-task-project"><SelectValue placeholder="اختر المشروع" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="none">بدون مشروع</SelectItem>
                      {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="employeeId" render={({ field }) => (
                <FormItem>
                  <FormLabel>تكليف الموظف (اختياري)</FormLabel>
                  <Select onValueChange={(v) => field.onChange(v === "none" ? null : v)} value={field.value || "none"}>
                    <FormControl><SelectTrigger data-testid="select-task-employee"><SelectValue placeholder="اختر الموظف" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="none">بدون موظف</SelectItem>
                      {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.name} {(e as any).employeeType === "freelancer" ? "🔸" : ""}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="fee" render={({ field }) => (
                <FormItem>
                  <FormLabel>أتعاب المهمة للفري لانسر (اختياري)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0.00" {...field} value={field.value ?? ""} onChange={e => field.onChange(e.target.value ? Number(e.target.value) : null)} data-testid="input-task-fee" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem>
                  <FormLabel>التفاصيل</FormLabel>
                  <FormControl><Textarea placeholder="تفاصيل إضافية..." {...field} value={field.value ?? ""} data-testid="input-task-description" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <DialogFooter className="gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-task">
                  {editTask ? "حفظ" : "إضافة"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
