import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, FolderOpen, MapPin, Calendar, DollarSign } from "lucide-react";
import { formatCurrency, formatDate, getProjectTypeLabel, getStatusLabel } from "@/lib/utils";
import type { Client, Project } from "@shared/schema";

export default function ClientProjects() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();

  const { data: client, isLoading: cLoading } = useQuery<Client>({ queryKey: ["/api/clients", id] });
  const { data: projects = [], isLoading: pLoading } = useQuery<Project[]>({
    queryKey: ["/api/clients", id, "projects"],
  });

  if (cLoading || pLoading) return <div className="p-6"><Skeleton className="h-64 w-full" /></div>;

  const statusColors: Record<string, string> = {
    active: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
    completed: "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
    paused: "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
    cancelled: "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300",
  };

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/clients")}>
          <ArrowRight className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">{client?.name}</h1>
          <p className="text-muted-foreground text-sm mt-0.5">مشاريع العميل • {projects.length} مشروع</p>
        </div>
      </div>

      {projects.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center py-16">
            <FolderOpen className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground">لا توجد مشاريع لهذا العميل</p>
            <Button className="mt-4" onClick={() => navigate("/projects")}>
              إنشاء مشروع
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map(project => (
            <Card key={project.id} className="hover-elevate cursor-pointer" onClick={() => navigate(`/projects/${project.id}`)}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <Badge className={`text-xs ${project.projectType === "interior" ? "bg-violet-50 text-violet-700 dark:bg-violet-950 dark:text-violet-300" : "bg-sky-50 text-sky-700 dark:bg-sky-950 dark:text-sky-300"}`}>
                        {getProjectTypeLabel(project.projectType)}
                      </Badge>
                      <Badge className={`text-xs ${statusColors[project.status || "active"]}`}>
                        {getStatusLabel(project.status || "active")}
                      </Badge>
                    </div>
                    <CardTitle className="text-base">{project.title}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />قيمة العقد
                    </span>
                    <span className="text-sm font-bold text-primary">{formatCurrency(project.totalValue)}</span>
                  </div>
                  {project.areaSqm && (
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">المساحة</span>
                      <span className="text-sm">{project.areaSqm} م²</span>
                    </div>
                  )}
                  {project.location && (
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>{project.location}</span>
                    </div>
                  )}
                  {project.startDate && (
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(project.startDate)}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
