import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Plus, Trash2, Clock, CheckCircle, AlertCircle, FolderOpen, CalendarClock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import { Link } from "wouter";
import type { AvailabilityScheduleType, Project } from "@shared/schema";

const statusLabels: Record<string, string> = {
  available: "متاح",
  busy: "مشغول",
  partial: "متاح جزئياً",
};
const statusColors: Record<string, string> = {
  available: "bg-green-100 text-green-700",
  busy: "bg-red-100 text-red-700",
  partial: "bg-yellow-100 text-yellow-700",
};
const statusIcons: Record<string, any> = {
  available: CheckCircle,
  busy: AlertCircle,
  partial: Clock,
};

function getWeekDates(): string[] {
  const today = new Date();
  const day = today.getDay();
  const diff = today.getDate() - day + (day === 0 ? -6 : 1);
  const dates: string[] = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date(today);
    d.setDate(diff + i);
    dates.push(d.toISOString().split("T")[0]);
  }
  return dates;
}

const dayNames = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

function getRemainingDays(endDate: string | null | undefined): number | null {
  if (!endDate) return null;
  const end = new Date(endDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  end.setHours(0, 0, 0, 0);
  return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export default function AvailabilitySchedulePage() {
  const { toast } = useToast();
  const { data: schedules, isLoading } = useQuery<AvailabilityScheduleType[]>({ queryKey: ["/api/my/availability"] });
  const { data: projects } = useQuery<Project[]>({ queryKey: ["/api/my/projects"] });
  const [newDate, setNewDate] = useState("");
  const [newStatus, setNewStatus] = useState("available");
  const [newHours, setNewHours] = useState("8");
  const [newNotes, setNewNotes] = useState("");

  const addMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/my/availability", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/availability"] });
      setNewDate("");
      setNewStatus("available");
      setNewHours("8");
      setNewNotes("");
      toast({ title: "تم حفظ جدول التفرغ" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/my/availability/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/availability"] });
      toast({ title: "تم الحذف" });
    },
  });

  const weekDates = getWeekDates();

  const quickAdd = (date: string, status: string) => {
    addMutation.mutate({ date, status, availableHours: status === "available" ? 8 : status === "partial" ? 4 : 0, notes: "" });
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4 overflow-auto h-full" dir="rtl">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-7 gap-2">{Array.from({ length: 14 }).map((_, i) => <Skeleton key={i} className="h-24" />)}</div>
      </div>
    );
  }

  const scheduleMap = new Map(schedules?.map(s => [s.date, s]) || []);

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-page-title">جدول التفرغ</h1>
        <p className="text-muted-foreground">مشاريعك الحالية ومواعيد التسليم</p>
      </div>

      {(() => {
        const activeProjects = projects?.filter(p => p.status === "active") || [];
        const sortedProjects = [...activeProjects].sort((a, b) => {
          const daysA = getRemainingDays(a.endDate);
          const daysB = getRemainingDays(b.endDate);
          if (daysA === null && daysB === null) return 0;
          if (daysA === null) return 1;
          if (daysB === null) return -1;
          return daysA - daysB;
        });
        return sortedProjects.length > 0 ? (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <FolderOpen className="h-5 w-5" />
                مشاريعي ومواعيد التسليم ({activeProjects.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {sortedProjects.map(project => {
                  const days = getRemainingDays(project.endDate);
                  const isOverdue = days !== null && days < 0;
                  const isUrgent = days !== null && days >= 0 && days <= 7;
                  return (
                    <Link key={project.id} href={`/projects/${project.id}`}>
                      <div className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-colors hover:bg-accent/50 ${
                        isOverdue ? "border-red-200 dark:border-red-800" :
                        isUrgent ? "border-amber-200 dark:border-amber-800" : ""
                      }`} data-testid={`schedule-project-${project.id}`}>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm truncate">{project.title}</p>
                            <Badge variant="outline" className="text-[10px]">
                              {project.projectType === "interior" ? "داخلي" : project.projectType === "exterior" ? "خارجي" : "واجهات"}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {project.location && `${project.location} • `}
                            {project.endDate ? `التسليم: ${formatDate(project.endDate)}` : "بدون موعد تسليم"}
                          </p>
                        </div>
                        {days !== null && (
                          <Badge className={`text-xs flex-shrink-0 ${
                            isOverdue ? "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300" :
                            isUrgent ? "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300" :
                            days <= 20 ? "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300" :
                            "bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300"
                          }`} variant="secondary">
                            {isOverdue ? `متأخر ${Math.abs(days)} يوم` :
                             days === 0 ? "التسليم اليوم" :
                             `باقي ${days} يوم`}
                          </Badge>
                        )}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ) : null;
      })()}

      <Card>
        <CardHeader><CardTitle className="text-lg">الأسبوعين القادمين</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {dayNames.map(name => (
              <div key={name} className="text-center text-xs font-medium text-muted-foreground py-1">{name}</div>
            ))}
            {weekDates.map(date => {
              const schedule = scheduleMap.get(date);
              const d = new Date(date);
              const dayNum = d.getDate();
              const isFriday = d.getDay() === 5;
              const Icon = schedule ? statusIcons[schedule.status] : Calendar;
              return (
                <div
                  key={date}
                  className={`relative p-2 rounded-lg border min-h-[80px] ${
                    isFriday ? "bg-muted/50" : ""
                  } ${schedule ? "border-primary/30" : "border-border"}`}
                  data-testid={`day-${date}`}
                >
                  <div className="text-xs font-medium mb-1">{dayNum}</div>
                  {schedule ? (
                    <div className="space-y-1">
                      <Badge className={`text-[10px] ${statusColors[schedule.status]}`} variant="secondary">
                        {statusLabels[schedule.status]}
                      </Badge>
                      {schedule.availableHours !== null && schedule.availableHours !== 8 && (
                        <div className="text-[10px] text-muted-foreground">{schedule.availableHours} ساعات</div>
                      )}
                      <button onClick={() => deleteMutation.mutate(schedule.id)} className="absolute top-1 left-1 text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col gap-0.5 mt-1">
                      <button onClick={() => quickAdd(date, "available")} className="text-[9px] text-green-600 hover:underline">متاح</button>
                      <button onClick={() => quickAdd(date, "partial")} className="text-[9px] text-yellow-600 hover:underline">جزئي</button>
                      <button onClick={() => quickAdd(date, "busy")} className="text-[9px] text-red-600 hover:underline">مشغول</button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Plus className="h-5 w-5" />إضافة يوم محدد</CardTitle></CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>التاريخ</Label>
              <Input type="date" value={newDate} onChange={e => setNewDate(e.target.value)} data-testid="input-avail-date" />
            </div>
            <div className="space-y-2">
              <Label>الحالة</Label>
              <Select value={newStatus} onValueChange={setNewStatus}>
                <SelectTrigger data-testid="select-avail-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">متاح</SelectItem>
                  <SelectItem value="partial">متاح جزئياً</SelectItem>
                  <SelectItem value="busy">مشغول</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>ساعات العمل</Label>
              <Input type="number" min="0" max="12" value={newHours} onChange={e => setNewHours(e.target.value)} data-testid="input-avail-hours" />
            </div>
            <div className="space-y-2">
              <Label>ملاحظات</Label>
              <Input value={newNotes} onChange={e => setNewNotes(e.target.value)} placeholder="اختياري" data-testid="input-avail-notes" />
            </div>
          </div>
          <Button
            className="mt-4"
            disabled={!newDate || addMutation.isPending}
            onClick={() => addMutation.mutate({ date: newDate, status: newStatus, availableHours: parseInt(newHours), notes: newNotes || null })}
            data-testid="button-add-avail"
          >
            {addMutation.isPending ? "جاري الحفظ..." : "حفظ"}
          </Button>
        </CardContent>
      </Card>

      {schedules && schedules.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-lg">السجل</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {schedules.map(s => {
                const Icon = statusIcons[s.status];
                return (
                  <div key={s.id} className="flex items-center justify-between p-3 rounded-lg border" data-testid={`avail-record-${s.id}`}>
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4" />
                      <div>
                        <p className="text-sm font-medium">{s.date} - {dayNames[new Date(s.date).getDay()]}</p>
                        {s.notes && <p className="text-xs text-muted-foreground">{s.notes}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={statusColors[s.status]} variant="secondary">{statusLabels[s.status]}</Badge>
                      <span className="text-xs text-muted-foreground">{s.availableHours} ساعات</span>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteMutation.mutate(s.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
