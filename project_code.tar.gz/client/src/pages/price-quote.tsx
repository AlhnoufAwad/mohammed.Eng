import { useState, useMemo } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Sparkles, Brain, Printer } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, getProjectTypeLabel } from "@/lib/utils";
import logoIcon from "@assets/WhatsApp_Image_2026-02-24_at_11.25.33_PM_1771964913996.jpeg";

function escapeHtml(str: string): string {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function fmtAr(n: number, digits = 0) {
  return n.toLocaleString("ar-SA", { maximumFractionDigits: digits });
}

export default function PriceQuote() {
  const [clientName, setClientName] = useState("");
  const [clientCompany, setClientCompany] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [location, setLocation] = useState("");
  const [projectType, setProjectType] = useState("interior");
  const [area, setArea] = useState("");
  const [totalValue, setTotalValue] = useState("");
  const [validDays, setValidDays] = useState("30");
  const [notes, setNotes] = useState("");
  const [terms, setTerms] = useState("• الأسعار شاملة التصميم ولا تشمل التنفيذ ما لم ينص على ذلك\n• يتم البدء بالعمل بعد استلام الدفعة الأولى\n• التعديلات ضمن نطاق العمل المتفق عليه مجاناً");
  const [companyBio, setCompanyBio] = useState("مؤسسة محمد البلوي للتصميم الداخلي والخارجي — مؤسسة متخصصة في تقديم حلول التصميم الداخلي والخارجي المتكاملة، بخبرة واسعة في المشاريع السكنية والتجارية والمكتبية. نحرص على تقديم تصاميم عصرية تجمع بين الجمال والوظيفة، مع الالتزام بأعلى معايير الجودة وتلبية تطلعات عملائنا.");

  const estimateMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/tools/estimate", { areaSqm: parseFloat(area), projectType });
      return res.json();
    },
    onSuccess: (data: any) => {
      if (!totalValue && data.totalValue) setTotalValue(String(data.totalValue));
    },
  });

  const aiPrice = estimateMutation.data;
  const areaNum = parseFloat(area) || 0;
  const totalNum = parseFloat(totalValue) || 0;
  const computedPPSqm = areaNum > 0 && totalNum > 0 ? totalNum / areaNum : 0;
  const vatAmount = totalNum * 0.15;
  const totalWithVat = totalNum + vatAmount;

  const quoteNumber = useMemo(() => `QT-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`, []);
  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const expiryDate = new Date(Date.now() + parseInt(validDays) * 86400000).toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });

  function exportPDF() {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;
    const typeLabel = getProjectTypeLabel(projectType);
    const phases = aiPrice?.phases || [];
    const safeNotes = escapeHtml(notes);
    const safeTerms = escapeHtml(terms);

    printWindow.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<title>عرض سعر - ${escapeHtml(clientName) || "عميل"}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap');
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'IBM Plex Sans Arabic', sans-serif; background: #fff; color: #1a1a1a; padding: 0; }
.page { max-width: 800px; margin: 0 auto; padding: 40px; }
@media print { .page { padding: 20px; } .no-print { display: none !important; } }
.header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 3px solid #000; }
.company-info h1 { font-size: 20px; font-weight: 700; }
.company-info p { font-size: 11px; color: #666; margin-top: 2px; }
.quote-badge { background: #000; color: #fff; padding: 8px 20px; font-size: 18px; font-weight: 700; letter-spacing: 1px; }
.quote-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px; }
.meta-box { border: 1px solid #e0e0e0; padding: 15px; }
.meta-box h3 { font-size: 11px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
.meta-row { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 13px; }
.section { margin-bottom: 25px; }
.section-title { font-size: 14px; font-weight: 700; padding: 8px 12px; background: #f5f5f5; border-right: 4px solid #000; margin-bottom: 12px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th { background: #000; color: #fff; padding: 10px 12px; text-align: right; font-weight: 600; }
td { padding: 10px 12px; border-bottom: 1px solid #eee; }
tr:nth-child(even) { background: #fafafa; }
.total-row { background: #000 !important; color: #fff; font-weight: 700; }
.total-row td { border: none; }
.payments-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
.payment-card { border: 2px solid #000; padding: 15px; text-align: center; }
.payment-card .pct { font-size: 22px; font-weight: 700; }
.payment-card .amt { font-size: 16px; font-weight: 600; margin-top: 4px; }
.payment-card .label { font-size: 11px; color: #666; margin-top: 4px; }
.notes-box { background: #fafafa; border: 1px solid #eee; padding: 12px; font-size: 12px; color: #555; margin-bottom: 15px; line-height: 1.7; }
.bio-box { background: #f9f9f9; border-right: 4px solid #000; padding: 14px 16px; font-size: 12px; color: #333; line-height: 1.9; }
.stamp-area { display: flex; gap: 60px; margin-top: 40px; }
.stamp-box { flex: 1; text-align: center; }
.stamp-box .sig { height: 55px; object-fit: contain; display: block; margin: 0 auto 4px; }
.stamp-box .line { border-top: 1px solid #000; margin-top: 55px; padding-top: 6px; font-size: 12px; font-weight: 500; }
.stamp-box .line-with-sig { border-top: 1px solid #000; padding-top: 6px; font-size: 12px; font-weight: 500; }
.footer { margin-top: 30px; padding-top: 15px; border-top: 2px solid #000; display: flex; justify-content: space-between; font-size: 11px; color: #666; }
.btn-print { background: #000; color: #fff; border: none; padding: 12px 30px; font-size: 14px; cursor: pointer; font-family: inherit; margin: 20px auto; display: block; }
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="company-info">
      <h1>مؤسسة محمد البلوي</h1>
      <p>للتصميم الداخلي والخارجي</p>
      <p>Mohammed Al Balwi Group</p>
    </div>
    <div>
      <div class="quote-badge">عرض سعر</div>
      <p style="text-align:left;font-size:11px;margin-top:4px;color:#888">${quoteNumber}</p>
    </div>
  </div>
  <div class="quote-meta">
    <div class="meta-box">
      <h3>بيانات العميل</h3>
      ${clientName ? `<div class="meta-row"><span>الاسم:</span><span>${escapeHtml(clientName)}</span></div>` : ""}
      ${clientCompany ? `<div class="meta-row"><span>الشركة:</span><span>${escapeHtml(clientCompany)}</span></div>` : ""}
      ${clientPhone ? `<div class="meta-row"><span>الجوال:</span><span>${escapeHtml(clientPhone)}</span></div>` : ""}
      ${location ? `<div class="meta-row"><span>الموقع:</span><span>${escapeHtml(location)}</span></div>` : ""}
    </div>
    <div class="meta-box">
      <h3>بيانات العرض</h3>
      <div class="meta-row"><span>الرقم:</span><span>${quoteNumber}</span></div>
      <div class="meta-row"><span>التاريخ:</span><span>${today}</span></div>
      <div class="meta-row"><span>صلاحية العرض:</span><span>${expiryDate}</span></div>
      <div class="meta-row"><span>نوع العمل:</span><span>${getProjectTypeLabel(projectType)}</span></div>
    </div>
  </div>
  <div class="section">
    <div class="section-title">تفاصيل المشروع</div>
    <table>
      <thead><tr><th>البند</th><th>المساحة (م²)</th><th>سعر المتر</th><th>الإجمالي</th></tr></thead>
      <tbody>
        <tr>
          <td>${getProjectTypeLabel(projectType)}</td>
          <td>${fmtAr(areaNum)} م²</td>
          <td>${fmtAr(computedPPSqm, 0)} ر.س</td>
          <td>${fmtAr(totalNum)} ر.س</td>
        </tr>
        <tr><td colspan="3" style="text-align:left;font-weight:600">ضريبة القيمة المضافة (15%)</td><td style="font-weight:600">${fmtAr(vatAmount, 0)} ر.س</td></tr>
        <tr class="total-row"><td colspan="3" style="text-align:left">الإجمالي شامل الضريبة</td><td style="font-size:16px">${fmtAr(totalWithVat, 0)} ر.س</td></tr>
      </tbody>
    </table>
  </div>
  ${companyBio ? `<div class="section">
    <div class="section-title">نبذة عن الشركة</div>
    <div class="bio-box">${escapeHtml(companyBio).replace(/\n/g, "<br>")}</div>
  </div>` : ""}
  ${phases.length > 0 ? `
  <div class="section">
    <div class="section-title">المراحل والجدول الزمني</div>
    <table><thead><tr><th>المرحلة</th><th>المدة المقدرة</th><th>النسبة</th></tr></thead>
    <tbody>${phases.map((p: any) => `<tr><td>${p.name}</td><td>${p.days} يوم</td><td>${p.percentage}%</td></tr>`).join("")}</tbody></table>
  </div>` : ""}
  ${notes ? `<div class="section"><div class="section-title">ملاحظات</div><div class="notes-box">${safeNotes.replace(/\n/g, "<br>")}</div></div>` : ""}
  ${terms ? `<div class="section"><div class="section-title">الشروط والأحكام</div><div class="notes-box">${safeTerms.replace(/\n/g, "<br>")}</div></div>` : ""}
  <div class="stamp-area">
    <div class="stamp-box">
      <img src="${window.location.origin}/signature.png" class="sig" alt="توقيع" onerror="this.style.display='none'" />
      <div class="line-with-sig">توقيع المؤسسة وختمها</div>
    </div>
    <div class="stamp-box">
      <div class="line">توقيع العميل واعتماده</div>
    </div>
  </div>
  <div class="footer">
    <span>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</span>
    <span>تم إنشاء العرض بتاريخ ${today}</span>
  </div>
  <button class="btn-print no-print" onclick="window.print()">🖨️ طباعة / تصدير PDF</button>
</div>
</body></html>`);
    printWindow.document.close();
  }

  return (
    <div className="h-full flex flex-col overflow-hidden" dir="rtl">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-3 border-b bg-background flex-shrink-0">
        <div className="flex items-center gap-3">
          <FileText className="h-5 w-5 text-primary" />
          <div>
            <h1 className="text-base font-bold">عرض السعر</h1>
            <p className="text-xs text-muted-foreground">محرر تفاعلي مع معاينة مباشرة</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => estimateMutation.mutate()} disabled={!area || estimateMutation.isPending} data-testid="button-ai-estimate">
            <Sparkles className="h-3.5 w-3.5 ml-1" />
            {estimateMutation.isPending ? "جاري..." : "تقدير ذكي"}
          </Button>
          <Button size="sm" onClick={exportPDF} disabled={!totalValue} data-testid="button-export-quote-pdf">
            <Printer className="h-3.5 w-3.5 ml-1" />
            تصدير PDF
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel: Inputs */}
        <div className="w-72 flex-shrink-0 border-l overflow-y-auto p-3 space-y-4 bg-muted/20">
          {/* Client Info */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">بيانات العميل</p>
            <div className="space-y-2">
              <div>
                <Label className="text-xs">اسم العميل</Label>
                <Input value={clientName} onChange={e => setClientName(e.target.value)} placeholder="محمد أحمد" className="h-8 text-sm" data-testid="input-quote-client-name" />
              </div>
              <div>
                <Label className="text-xs">الشركة</Label>
                <Input value={clientCompany} onChange={e => setClientCompany(e.target.value)} placeholder="اسم الشركة" className="h-8 text-sm" data-testid="input-quote-company" />
              </div>
              <div>
                <Label className="text-xs">الجوال</Label>
                <Input value={clientPhone} onChange={e => setClientPhone(e.target.value)} placeholder="05xxxxxxxx" className="h-8 text-sm" dir="ltr" data-testid="input-quote-phone" />
              </div>
              <div>
                <Label className="text-xs">الموقع</Label>
                <Input value={location} onChange={e => setLocation(e.target.value)} placeholder="المدينة، الحي" className="h-8 text-sm" data-testid="input-quote-location" />
              </div>
            </div>
          </div>

          {/* Project Info */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">تفاصيل المشروع</p>
            <div className="space-y-2">
              <div>
                <Label className="text-xs">نوع المشروع</Label>
                <Select value={projectType} onValueChange={setProjectType}>
                  <SelectTrigger className="h-8 text-sm" data-testid="select-quote-type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="interior">تصميم داخلي</SelectItem>
                    <SelectItem value="exterior">تصميم خارجي</SelectItem>
                    <SelectItem value="facades">واجهات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">المساحة (م²)</Label>
                <Input type="number" value={area} onChange={e => setArea(e.target.value)} placeholder="350" className="h-8 text-sm" data-testid="input-quote-area" />
              </div>
              <div>
                <Label className="text-xs">الإجمالي (ر.س)</Label>
                <Input type="number" value={totalValue} onChange={e => setTotalValue(e.target.value)} placeholder="القيمة الإجمالية" className="h-8 text-sm" data-testid="input-quote-total" />
                {computedPPSqm > 0 && <p className="text-[10px] text-muted-foreground mt-0.5">سعر المتر: <span className="font-bold text-primary">{computedPPSqm.toFixed(0)} ر.س</span></p>}
              </div>
              <div>
                <Label className="text-xs">صلاحية العرض</Label>
                <Select value={validDays} onValueChange={setValidDays}>
                  <SelectTrigger className="h-8 text-sm" data-testid="select-quote-validity"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 أيام</SelectItem>
                    <SelectItem value="15">15 يوم</SelectItem>
                    <SelectItem value="30">30 يوم</SelectItem>
                    <SelectItem value="60">60 يوم</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Company Bio */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">نبذة عن الشركة</p>
            <Textarea
              value={companyBio}
              onChange={e => setCompanyBio(e.target.value)}
              rows={5}
              className="text-xs resize-none"
              placeholder="اكتب نبذة عن المؤسسة تظهر في العرض..."
              data-testid="input-quote-company-bio"
            />
          </div>

          {/* Notes & Terms */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">ملاحظات وشروط</p>
            <div className="space-y-2">
              <div>
                <Label className="text-xs">ملاحظات</Label>
                <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="ملاحظات تظهر في العرض..." rows={2} className="text-sm resize-none" data-testid="input-quote-notes" />
              </div>
              <div>
                <Label className="text-xs">الشروط والأحكام</Label>
                <Textarea value={terms} onChange={e => setTerms(e.target.value)} rows={4} className="text-xs resize-none" />
              </div>
            </div>
          </div>

          {aiPrice && (
            <div className="p-2 bg-violet-50 dark:bg-violet-950/30 rounded-md border border-violet-200 dark:border-violet-800">
              <div className="flex items-center gap-1.5 mb-2">
                <Brain className="h-3.5 w-3.5 text-violet-600" />
                <span className="text-xs font-semibold text-violet-700 dark:text-violet-300">تحليل ذكي</span>
              </div>
              <div className="grid grid-cols-2 gap-1 text-[10px]">
                <div><span className="text-muted-foreground">المقترح/م²:</span> <strong>{aiPrice.pricePerSqm} ر.س</strong></div>
                <div><span className="text-muted-foreground">المدة:</span> <strong>{aiPrice.estimatedDays} يوم</strong></div>
                <div><span className="text-muted-foreground">التعقيد:</span> <strong>{aiPrice.complexity}</strong></div>
                <div><span className="text-muted-foreground">الفريق:</span> <strong>{aiPrice.recommendedTeam}</strong></div>
              </div>
            </div>
          )}
        </div>

        {/* Right Panel: PDF-like Preview */}
        <div className="flex-1 overflow-y-auto bg-gray-100 dark:bg-gray-900 p-6">
          <div
            className="bg-white text-black mx-auto shadow-2xl"
            style={{
              maxWidth: "800px",
              minHeight: "1100px",
              padding: "40px",
              fontFamily: "'IBM Plex Sans Arabic', sans-serif",
              direction: "rtl",
            }}
            data-testid="quote-preview"
          >
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "30px", paddingBottom: "20px", borderBottom: "3px solid #000" }}>
              <div>
                <h1 style={{ fontSize: "20px", fontWeight: 700 }}>مؤسسة محمد البلوي</h1>
                <p style={{ fontSize: "11px", color: "#666", marginTop: "2px" }}>للتصميم الداخلي والخارجي</p>
                <p style={{ fontSize: "11px", color: "#666" }}>Mohammed Al Balwi Group</p>
              </div>
              <div>
                <div style={{ background: "#000", color: "#fff", padding: "8px 20px", fontSize: "18px", fontWeight: 700, letterSpacing: "1px" }}>عرض سعر</div>
                <p style={{ textAlign: "left", fontSize: "11px", marginTop: "4px", color: "#888" }}>{quoteNumber}</p>
              </div>
            </div>

            {/* Meta Grid */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", marginBottom: "25px" }}>
              <div style={{ border: "1px solid #e0e0e0", padding: "15px" }}>
                <h3 style={{ fontSize: "11px", color: "#888", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "8px" }}>بيانات العميل</h3>
                {clientName ? <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "13px" }}><span>الاسم:</span><span><strong>{clientName}</strong></span></div> : <span style={{ fontSize: "13px", color: "#ccc" }}>اسم العميل...</span>}
                {clientCompany && <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "13px" }}><span>الشركة:</span><span>{clientCompany}</span></div>}
                {clientPhone && <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "13px" }}><span>الجوال:</span><span dir="ltr">{clientPhone}</span></div>}
                {location && <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "13px" }}><span>الموقع:</span><span>{location}</span></div>}
              </div>
              <div style={{ border: "1px solid #e0e0e0", padding: "15px" }}>
                <h3 style={{ fontSize: "11px", color: "#888", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "8px" }}>بيانات العرض</h3>
                {[
                  ["الرقم", quoteNumber],
                  ["التاريخ", today],
                  ["الصلاحية", expiryDate],
                  ["نوع العمل", getProjectTypeLabel(projectType)],
                ].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "13px" }}>
                    <span>{k}:</span><span>{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Project Details Table */}
            <div style={{ marginBottom: "25px" }}>
              <div style={{ fontSize: "14px", fontWeight: 700, padding: "8px 12px", background: "#f5f5f5", borderRight: "4px solid #000", marginBottom: "12px" }}>تفاصيل المشروع</div>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
                <thead>
                  <tr>
                    {["البند", "المساحة (م²)", "سعر المتر", "الإجمالي"].map(h => (
                      <th key={h} style={{ background: "#000", color: "#fff", padding: "10px 12px", textAlign: "right", fontWeight: 600 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ padding: "10px 12px", borderBottom: "1px solid #eee" }}>{getProjectTypeLabel(projectType)}</td>
                    <td style={{ padding: "10px 12px", borderBottom: "1px solid #eee" }}>{areaNum ? `${fmtAr(areaNum)} م²` : "—"}</td>
                    <td style={{ padding: "10px 12px", borderBottom: "1px solid #eee" }}>{computedPPSqm ? `${fmtAr(computedPPSqm, 0)} ر.س` : "—"}</td>
                    <td style={{ padding: "10px 12px", borderBottom: "1px solid #eee" }}>{totalNum ? `${fmtAr(totalNum)} ر.س` : "—"}</td>
                  </tr>
                  <tr style={{ background: "#fafafa" }}>
                    <td colSpan={3} style={{ padding: "10px 12px", borderBottom: "1px solid #eee", textAlign: "left", fontWeight: 600 }}>ضريبة القيمة المضافة (15%)</td>
                    <td style={{ padding: "10px 12px", borderBottom: "1px solid #eee", fontWeight: 600 }}>{totalNum ? `${fmtAr(vatAmount, 0)} ر.س` : "—"}</td>
                  </tr>
                  <tr style={{ background: "#000", color: "#fff", fontWeight: 700 }}>
                    <td colSpan={3} style={{ padding: "10px 12px", textAlign: "left" }}>الإجمالي شامل الضريبة</td>
                    <td style={{ padding: "10px 12px", fontSize: "16px" }}>{totalNum ? `${fmtAr(totalWithVat, 0)} ر.س` : "—"}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Company Bio */}
            {companyBio && (
              <div style={{ marginBottom: "25px" }}>
                <div style={{ fontSize: "14px", fontWeight: 700, padding: "8px 12px", background: "#f5f5f5", borderRight: "4px solid #000", marginBottom: "12px" }}>نبذة عن الشركة</div>
                <div style={{ background: "#f9f9f9", borderRight: "4px solid #000", padding: "14px 16px", fontSize: "12px", color: "#333", lineHeight: "1.9" }}>
                  {companyBio.split("\n").map((line, i) => <div key={i}>{line || "\u00A0"}</div>)}
                </div>
              </div>
            )}

            {/* AI Phases */}
            {aiPrice?.phases?.length > 0 && (
              <div style={{ marginBottom: "25px" }}>
                <div style={{ fontSize: "14px", fontWeight: 700, padding: "8px 12px", background: "#f5f5f5", borderRight: "4px solid #000", marginBottom: "12px" }}>
                  المراحل والجدول الزمني <Badge className="mr-2 text-[9px]">ذكي</Badge>
                </div>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
                  <thead>
                    <tr>
                      {["المرحلة", "المدة المقدرة", "النسبة"].map(h => (
                        <th key={h} style={{ background: "#000", color: "#fff", padding: "8px 12px", textAlign: "right", fontWeight: 600 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {aiPrice.phases.map((p: any, i: number) => (
                      <tr key={i} style={i % 2 === 1 ? { background: "#fafafa" } : {}}>
                        <td style={{ padding: "8px 12px", borderBottom: "1px solid #eee" }}>{p.name}</td>
                        <td style={{ padding: "8px 12px", borderBottom: "1px solid #eee" }}>{p.days} يوم</td>
                        <td style={{ padding: "8px 12px", borderBottom: "1px solid #eee" }}>{p.percentage}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Notes */}
            {notes && (
              <div style={{ marginBottom: "25px" }}>
                <div style={{ fontSize: "14px", fontWeight: 700, padding: "8px 12px", background: "#f5f5f5", borderRight: "4px solid #000", marginBottom: "12px" }}>ملاحظات</div>
                <div style={{ background: "#fafafa", border: "1px solid #eee", padding: "12px", fontSize: "12px", color: "#555", lineHeight: "1.7" }}>
                  {notes.split("\n").map((line, i) => <div key={i}>{line || "\u00A0"}</div>)}
                </div>
              </div>
            )}

            {/* Terms */}
            {terms && (
              <div style={{ marginBottom: "25px" }}>
                <div style={{ fontSize: "14px", fontWeight: 700, padding: "8px 12px", background: "#f5f5f5", borderRight: "4px solid #000", marginBottom: "12px" }}>الشروط والأحكام</div>
                <div style={{ background: "#fafafa", border: "1px solid #eee", padding: "12px", fontSize: "12px", color: "#555", lineHeight: "1.7" }}>
                  {terms.split("\n").map((line, i) => <div key={i}>{line || "\u00A0"}</div>)}
                </div>
              </div>
            )}

            {/* Stamps */}
            <div style={{ display: "flex", gap: "60px", marginTop: "40px" }}>
              <div style={{ flex: 1, textAlign: "center" }}>
                <img src="/signature.png" style={{ height: "55px", objectFit: "contain", display: "block", margin: "0 auto 4px" }} alt="توقيع" onError={e => (e.currentTarget.style.display = "none")} />
                <div style={{ borderTop: "1px solid #000", paddingTop: "6px", fontSize: "12px", fontWeight: 500 }}>توقيع المؤسسة وختمها</div>
              </div>
              <div style={{ flex: 1, textAlign: "center" }}>
                <div style={{ borderTop: "1px solid #000", marginTop: "60px", paddingTop: "6px", fontSize: "12px", fontWeight: 500 }}>توقيع العميل واعتماده</div>
              </div>
            </div>

            {/* Footer */}
            <div style={{ marginTop: "30px", paddingTop: "15px", borderTop: "2px solid #000", display: "flex", justifyContent: "space-between", fontSize: "11px", color: "#666" }}>
              <span>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</span>
              <span>تم إنشاء العرض بتاريخ {today}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
