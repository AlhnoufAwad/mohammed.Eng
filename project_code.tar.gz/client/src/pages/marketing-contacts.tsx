import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMarketingContactSchema, type MarketingContact, type InsertMarketingContact } from "@shared/schema";
import { Plus, Search, Edit, Trash2, Phone, Mail, MapPin, UserPlus, Calendar } from "lucide-react";

const statusLabels: Record<string, string> = {
  lead: "عميل محتمل",
  contacted: "تم التواصل",
  interested: "مهتم",
  not_interested: "غير مهتم",
};

const statusColors: Record<string, string> = {
  lead: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  contacted: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  interested: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  not_interested: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

export default function MarketingContacts() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editContact, setEditContact] = useState<MarketingContact | null>(null);

  const { data: contacts = [], isLoading } = useQuery<MarketingContact[]>({
    queryKey: ["/api/marketing-contacts"],
  });

  const form = useForm<InsertMarketingContact>({
    resolver: zodResolver(insertMarketingContactSchema),
    defaultValues: { name: "", phone: "", email: "", city: "", source: "", notes: "", lastContactDate: "", status: "lead" },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertMarketingContact) => apiRequest("POST", "/api/marketing-contacts", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketing-contacts"] });
      toast({ title: "تم إضافة جهة الاتصال بنجاح" });
      setDialogOpen(false);
      form.reset();
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertMarketingContact> }) =>
      apiRequest("PUT", `/api/marketing-contacts/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketing-contacts"] });
      toast({ title: "تم تحديث بيانات جهة الاتصال" });
      setDialogOpen(false);
      setEditContact(null);
      form.reset();
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/marketing-contacts/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketing-contacts"] });
      toast({ title: "تم حذف جهة الاتصال" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const filtered = contacts.filter(c => {
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.phone || "").includes(search) ||
      (c.city || "").toLowerCase().includes(search.toLowerCase()) ||
      (c.email || "").toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = {
    all: contacts.length,
    lead: contacts.filter(c => c.status === "lead").length,
    contacted: contacts.filter(c => c.status === "contacted").length,
    interested: contacts.filter(c => c.status === "interested").length,
    not_interested: contacts.filter(c => c.status === "not_interested").length,
  };

  function openAdd() {
    setEditContact(null);
    form.reset({ name: "", phone: "", email: "", city: "", source: "", notes: "", lastContactDate: "", status: "lead" });
    setDialogOpen(true);
  }

  function openEdit(contact: MarketingContact) {
    setEditContact(contact);
    form.reset({
      name: contact.name,
      phone: contact.phone || "",
      email: contact.email || "",
      city: contact.city || "",
      source: contact.source || "",
      notes: contact.notes || "",
      lastContactDate: contact.lastContactDate || "",
      status: contact.status || "lead",
    });
    setDialogOpen(true);
  }

  function onSubmit(data: InsertMarketingContact) {
    if (editContact) {
      updateMutation.mutate({ id: editContact.id, data });
    } else {
      createMutation.mutate(data);
    }
  }

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-page-title">جهات الاتصال التسويقية</h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة العملاء المحتملين والتواصل التسويقي</p>
        </div>
        <Button onClick={openAdd} data-testid="button-add-contact">
          <Plus className="h-4 w-4 ml-2" />
          إضافة جهة اتصال
        </Button>
      </div>

      <div className="flex items-center gap-2 mb-4 flex-wrap">
        {(["all", "lead", "contacted", "interested", "not_interested"] as const).map((s) => (
          <Button
            key={s}
            variant={statusFilter === s ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter(s)}
            data-testid={`button-filter-${s}`}
          >
            {s === "all" ? "الكل" : statusLabels[s]}
            <Badge variant="secondary" className="mr-1.5">{statusCounts[s]}</Badge>
          </Button>
        ))}
      </div>

      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="بحث بالاسم أو الهاتف أو المدينة أو البريد..."
          className="pr-10"
          value={search}
          onChange={e => setSearch(e.target.value)}
          data-testid="input-search-contacts"
        />
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-44" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <UserPlus className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground font-medium">لا توجد جهات اتصال</p>
            <p className="text-muted-foreground text-sm mt-1">ابدأ بإضافة جهات اتصال تسويقية للمتابعة</p>
            <Button onClick={openAdd} className="mt-4" data-testid="button-add-contact-empty">
              <Plus className="h-4 w-4 ml-2" />
              إضافة جهة اتصال
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((contact) => (
            <Card key={contact.id} className="hover-elevate" data-testid={`card-contact-${contact.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-primary">{contact.name.charAt(0)}</span>
                    </div>
                    <div>
                      <CardTitle className="text-base" data-testid={`text-contact-name-${contact.id}`}>{contact.name}</CardTitle>
                      {contact.city && (
                        <div className="flex items-center gap-1 mt-0.5">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{contact.city}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <Badge className={statusColors[contact.status || "lead"]} variant="secondary" data-testid={`badge-status-${contact.id}`}>
                    {statusLabels[contact.status || "lead"]}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="space-y-1.5">
                  {contact.phone && (
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>{contact.phone}</span>
                    </div>
                  )}
                  {contact.email && (
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="truncate">{contact.email}</span>
                    </div>
                  )}
                  {contact.source && (
                    <div className="text-xs text-muted-foreground">
                      المصدر: {contact.source}
                    </div>
                  )}
                  {contact.lastContactDate && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>آخر تواصل: {contact.lastContactDate}</span>
                    </div>
                  )}
                  {contact.notes && (
                    <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{contact.notes}</p>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => openEdit(contact)}
                    data-testid={`button-edit-contact-${contact.id}`}
                  >
                    <Edit className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => deleteMutation.mutate(contact.id)}
                    disabled={deleteMutation.isPending}
                    data-testid={`button-delete-contact-${contact.id}`}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editContact ? "تعديل جهة الاتصال" : "إضافة جهة اتصال جديدة"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel>الاسم *</FormLabel>
                  <FormControl><Input placeholder="اسم جهة الاتصال" {...field} data-testid="input-contact-name" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم الهاتف</FormLabel>
                    <FormControl><Input placeholder="05XXXXXXXX" {...field} value={field.value ?? ""} data-testid="input-contact-phone" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel>البريد الإلكتروني</FormLabel>
                    <FormControl><Input placeholder="email@example.com" {...field} value={field.value ?? ""} data-testid="input-contact-email" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="city" render={({ field }) => (
                  <FormItem>
                    <FormLabel>المدينة</FormLabel>
                    <FormControl><Input placeholder="الرياض" {...field} value={field.value ?? ""} data-testid="input-contact-city" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="source" render={({ field }) => (
                  <FormItem>
                    <FormLabel>المصدر</FormLabel>
                    <FormControl><Input placeholder="إنستغرام، إعلان، إحالة..." {...field} value={field.value ?? ""} data-testid="input-contact-source" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الحالة</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? "lead"}>
                      <FormControl>
                        <SelectTrigger data-testid="select-contact-status">
                          <SelectValue placeholder="اختر الحالة" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="lead">عميل محتمل</SelectItem>
                        <SelectItem value="contacted">تم التواصل</SelectItem>
                        <SelectItem value="interested">مهتم</SelectItem>
                        <SelectItem value="not_interested">غير مهتم</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="lastContactDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>تاريخ آخر تواصل</FormLabel>
                    <FormControl><Input type="date" {...field} value={field.value ?? ""} data-testid="input-contact-last-date" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="notes" render={({ field }) => (
                <FormItem>
                  <FormLabel>ملاحظات</FormLabel>
                  <FormControl><Textarea placeholder="ملاحظات إضافية..." {...field} value={field.value ?? ""} data-testid="input-contact-notes" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter className="gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-contact">
                  {editContact ? "حفظ التغييرات" : "إضافة"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
