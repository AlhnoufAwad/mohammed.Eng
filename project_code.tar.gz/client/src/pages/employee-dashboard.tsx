import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { FolderOpen, CheckSquare, Clock, DollarSign, AlertTriangle, CalendarClock } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Task, Project } from "@shared/schema";
import { Link } from "wouter";

const priorityColors: Record<string, string> = {
  high: "bg-foreground text-background",
  medium: "bg-foreground/15 text-foreground",
  low: "bg-foreground/5 text-foreground border border-foreground/10",
};

const statusLabels: Record<string, string> = {
  pending: "قيد الانتظار",
  in_progress: "جاري التنفيذ",
  completed: "مكتمل",
  overdue: "متأخر",
  active: "نشط",
};

function getRemainingDays(endDate: string | null | undefined): number | null {
  if (!endDate) return null;
  const end = new Date(endDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  end.setHours(0, 0, 0, 0);
  return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export default function EmployeeDashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading: statsLoading } = useQuery<any>({ queryKey: ["/api/my/dashboard"] });
  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({ queryKey: ["/api/my/tasks"] });
  const { data: projects } = useQuery<Project[]>({ queryKey: ["/api/my/projects"] });

  if (statsLoading) {
    return (
      <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-28" />)}
        </div>
      </div>
    );
  }

  const urgentTasks = tasks?.filter(t =>
    (t.status === "pending" || t.status === "in_progress") && t.dueDate
  ).sort((a, b) => (a.dueDate || "").localeCompare(b.dueDate || "")).slice(0, 5) || [];

  const activeProjects = projects?.filter(p => p.status === "active") || [];
  const approachingProjects = activeProjects
    .filter(p => {
      const days = getRemainingDays(p.endDate);
      return days !== null && days <= 20;
    })
    .sort((a, b) => (getRemainingDays(a.endDate) || 0) - (getRemainingDays(b.endDate) || 0));

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-page-title">مرحباً، {user?.name}</h1>
        <p className="text-muted-foreground">لوحة التحكم الخاصة بك</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-foreground/5 dark:bg-foreground/10"><FolderOpen className="h-5 w-5 text-foreground" /></div>
              <div>
                <p className="text-sm text-muted-foreground">مشاريعي</p>
                <p className="text-2xl font-bold" data-testid="text-my-projects-count">{stats?.totalProjects || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-foreground/5 dark:bg-foreground/10"><Clock className="h-5 w-5 text-foreground" /></div>
              <div>
                <p className="text-sm text-muted-foreground">مهام معلقة</p>
                <p className="text-2xl font-bold" data-testid="text-pending-tasks-count">{stats?.pendingTasks || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-foreground/5 dark:bg-foreground/10"><CheckSquare className="h-5 w-5 text-foreground" /></div>
              <div>
                <p className="text-sm text-muted-foreground">مهام مكتملة</p>
                <p className="text-2xl font-bold" data-testid="text-completed-tasks-count">{stats?.completedTasks || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-foreground/5 dark:bg-foreground/10"><DollarSign className="h-5 w-5 text-foreground" /></div>
              <div>
                <p className="text-sm text-muted-foreground">مستحقاتي</p>
                <p className="text-2xl font-bold" data-testid="text-total-assigned">{formatCurrency(stats?.totalAssigned || 0)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {approachingProjects.length > 0 && (
        <Card className="border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2 text-amber-700 dark:text-amber-400">
              <CalendarClock className="h-5 w-5" />
              مشاريع تقترب من التسليم
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {approachingProjects.map(project => {
                const days = getRemainingDays(project.endDate);
                const isOverdue = days !== null && days < 0;
                return (
                  <Link key={project.id} href={`/projects/${project.id}`}>
                    <div className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-colors hover:bg-accent/50 ${
                      isOverdue ? "border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/30" : "border-amber-200 dark:border-amber-800"
                    }`} data-testid={`approaching-project-${project.id}`}>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{project.title}</p>
                        <p className="text-xs text-muted-foreground">
                          تاريخ التسليم: {formatDate(project.endDate)}
                          {project.location && ` • ${project.location}`}
                        </p>
                      </div>
                      <Badge className={`text-xs flex-shrink-0 ${
                        isOverdue ? "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300" :
                        days !== null && days <= 7 ? "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300" :
                        "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300"
                      }`} variant="secondary">
                        {isOverdue ? `متأخر ${Math.abs(days!)} يوم` :
                         days === 0 ? "اليوم" :
                         `باقي ${days} يوم`}
                      </Badge>
                    </div>
                  </Link>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-foreground/70" />
              المهام العاجلة
            </CardTitle>
          </CardHeader>
          <CardContent>
            {tasksLoading ? (
              <div className="space-y-3">{[1, 2, 3].map(i => <Skeleton key={i} className="h-16" />)}</div>
            ) : urgentTasks.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-4">لا توجد مهام عاجلة</p>
            ) : (
              <div className="space-y-3">
                {urgentTasks.map(task => (
                  <div key={task.id} className="flex items-center justify-between p-3 rounded-lg border" data-testid={`task-item-${task.id}`}>
                    <div>
                      <p className="font-medium text-sm">{task.title}</p>
                      <p className="text-xs text-muted-foreground">تاريخ التسليم: {task.dueDate}</p>
                    </div>
                    <Badge className={priorityColors[task.priority || "medium"]} variant="secondary">
                      {task.priority === "high" ? "عالية" : task.priority === "medium" ? "متوسطة" : "منخفضة"}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <FolderOpen className="h-5 w-5 text-foreground/70" />
              مشاريعي الحالية
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!projects || projects.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-4">لا توجد مشاريع مكلف بها حالياً</p>
            ) : (
              <div className="space-y-3">
                {activeProjects.slice(0, 5).map(project => {
                  const days = getRemainingDays(project.endDate);
                  return (
                    <Link key={project.id} href={`/projects/${project.id}`}>
                      <div className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent/50 cursor-pointer transition-colors" data-testid={`project-item-${project.id}`}>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{project.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {project.location}
                            {project.endDate && ` • التسليم: ${formatDate(project.endDate)}`}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          {days !== null && days <= 20 && (
                            <Badge className={`text-[10px] ${
                              days < 0 ? "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300" :
                              days <= 7 ? "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300" :
                              "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300"
                            }`} variant="secondary">
                              {days < 0 ? `متأخر ${Math.abs(days)} يوم` : `${days} يوم`}
                            </Badge>
                          )}
                          <Badge variant="outline">{statusLabels[project.status || "active"]}</Badge>
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
