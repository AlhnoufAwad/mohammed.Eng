import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertEmployeeSchema, type Employee, type InsertEmployee } from "@shared/schema";
import { z } from "zod";
import { Plus, Search, Edit, Trash2, UserCheck, Phone, CreditCard, Percent, Mail, DollarSign } from "lucide-react";
import { getEmployeeTypeLabel } from "@/lib/utils";

const empFormSchema = insertEmployeeSchema.extend({
  designPercentage: z.coerce.number().optional(),
  executivePercentage: z.coerce.number().optional(),
  structuralPercentage: z.coerce.number().optional(),
  pricePerSqm: z.coerce.number().optional(),
  baseSalary: z.coerce.number().optional(),
});

type EmpForm = z.infer<typeof empFormSchema>;

export default function Employees() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editEmployee, setEditEmployee] = useState<Employee | null>(null);
  const [filterType, setFilterType] = useState("all");

  const { data: employees = [], isLoading } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });

  const form = useForm<EmpForm>({
    resolver: zodResolver(empFormSchema),
    defaultValues: {
      name: "", specialty: "", department: "", employeeType: "internal",
      designPercentage: undefined, executivePercentage: undefined,
      structuralPercentage: undefined, pricePerSqm: undefined,
      contractStartDate: "", phone: "", email: "", nationality: "",
      jobTitle: "", baseSalary: undefined, salaryDescription: "", jobRoles: "",
      bankAccount: "", notes: "", isActive: true,
    },
  });

  const empType = form.watch("employeeType");

  const createMutation = useMutation({
    mutationFn: (data: EmpForm) => apiRequest("POST", "/api/employees", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم إضافة الموظف" });
      setDialogOpen(false);
      form.reset();
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<EmpForm> }) =>
      apiRequest("PUT", `/api/employees/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      toast({ title: "تم تحديث بيانات الموظف" });
      setDialogOpen(false);
      setEditEmployee(null);
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/employees/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم حذف الموظف" });
    },
  });

  const filtered = employees.filter(e => {
    const matchSearch = e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.specialty.toLowerCase().includes(search.toLowerCase()) ||
      (e.department || "").toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === "all" || e.employeeType === filterType;
    return matchSearch && matchType;
  });

  function openAdd() {
    setEditEmployee(null);
    form.reset({ name: "", specialty: "", department: "", employeeType: "internal", isActive: true, email: "", nationality: "", jobTitle: "", baseSalary: undefined, salaryDescription: "", jobRoles: "" });
    setDialogOpen(true);
  }

  function openEdit(emp: Employee) {
    setEditEmployee(emp);
    form.reset({
      name: emp.name, specialty: emp.specialty, department: emp.department || "",
      employeeType: emp.employeeType, designPercentage: emp.designPercentage || undefined,
      executivePercentage: emp.executivePercentage || undefined,
      structuralPercentage: emp.structuralPercentage || undefined,
      pricePerSqm: emp.pricePerSqm || undefined,
      contractStartDate: emp.contractStartDate || "",
      phone: emp.phone || "", email: (emp as any).email || "",
      nationality: (emp as any).nationality || "", jobTitle: (emp as any).jobTitle || "",
      baseSalary: (emp as any).baseSalary || undefined,
      salaryDescription: (emp as any).salaryDescription || "",
      jobRoles: (emp as any).jobRoles || "",
      bankAccount: emp.bankAccount || "",
      notes: emp.notes || "", isActive: emp.isActive ?? true,
    });
    setDialogOpen(true);
  }

  function onSubmit(data: EmpForm) {
    if (editEmployee) {
      updateMutation.mutate({ id: editEmployee.id, data });
    } else {
      createMutation.mutate(data);
    }
  }

  const internal = filtered.filter(e => e.employeeType === "internal");
  const freelancers = filtered.filter(e => e.employeeType === "freelancer");

  const EmployeeCard = ({ emp }: { emp: Employee }) => {
    const e = emp as any;
    return (
    <Card className="hover-elevate" data-testid={`card-employee-${emp.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-bold text-primary">{emp.name.charAt(0)}</span>
            </div>
            <div>
              <p className="font-semibold text-sm">{emp.name}</p>
              <p className="text-xs text-muted-foreground">{e.jobTitle || emp.specialty}</p>
              {emp.department && <Badge variant="outline" className="text-[10px] mt-0.5">{emp.department}</Badge>}
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge variant={emp.isActive ? "default" : "secondary"} className="text-xs flex-shrink-0">
              {emp.isActive ? "نشط" : "غير نشط"}
            </Badge>
            {e.nationality && <span className="text-[10px] text-muted-foreground">{e.nationality}</span>}
          </div>
        </div>

        <div className="mt-3 space-y-1.5">
          {emp.phone && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Phone className="h-3 w-3" />
              <span>{emp.phone}</span>
            </div>
          )}
          {e.email && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Mail className="h-3 w-3" />
              <span>{e.email}</span>
            </div>
          )}
          {e.salaryDescription && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <DollarSign className="h-3 w-3" />
              <span className="truncate">{e.salaryDescription}</span>
            </div>
          )}
          {e.jobRoles && (
            <div className="text-xs text-muted-foreground mt-1">
              <p className="text-[10px] font-medium text-foreground/70 mb-0.5">الأدوار:</p>
              <p className="leading-relaxed">{e.jobRoles}</p>
            </div>
          )}
          {emp.bankAccount && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <CreditCard className="h-3 w-3" />
              <span className="truncate">{emp.bankAccount}</span>
            </div>
          )}
        </div>

        <div className="flex gap-2 mt-3">
          <Button size="sm" variant="outline" className="flex-1" onClick={() => openEdit(emp)} data-testid={`button-edit-employee-${emp.id}`}>
            <Edit className="h-3.5 w-3.5 ml-1" />
            تعديل
          </Button>
          <Button size="icon" variant="outline" onClick={() => deleteMutation.mutate(emp.id)} disabled={deleteMutation.isPending} data-testid={`button-delete-employee-${emp.id}`}>
            <Trash2 className="h-3.5 w-3.5 text-destructive" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
  };

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">الموظفون</h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة فريق العمل والموظفين المستقلين</p>
        </div>
        <Button onClick={openAdd} data-testid="button-add-employee">
          <Plus className="h-4 w-4 ml-2" />
          إضافة موظف
        </Button>
      </div>

      <div className="flex gap-3 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالاسم أو التخصص..."
            className="pr-10"
            value={search}
            onChange={e => setSearch(e.target.value)}
            data-testid="input-search-employees"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-48" />)}
        </div>
      ) : (
        <Tabs defaultValue="all" dir="rtl">
          <TabsList className="mb-4">
            <TabsTrigger value="all">الكل ({filtered.length})</TabsTrigger>
            <TabsTrigger value="internal">داخليون ({internal.length})</TabsTrigger>
            <TabsTrigger value="freelancer">مستقلون ({freelancers.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            {filtered.length === 0 ? (
              <Card><CardContent className="flex flex-col items-center py-16">
                <UserCheck className="h-12 w-12 text-muted-foreground/40 mb-3" />
                <p className="text-muted-foreground">لا يوجد موظفون</p>
                <Button onClick={openAdd} className="mt-4"><Plus className="h-4 w-4 ml-2" />إضافة موظف</Button>
              </CardContent></Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filtered.map(emp => <EmployeeCard key={emp.id} emp={emp} />)}
              </div>
            )}
          </TabsContent>

          <TabsContent value="internal">
            {internal.length === 0 ? (
              <Card><CardContent className="py-10 text-center text-muted-foreground text-sm">لا يوجد موظفون داخليون</CardContent></Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {internal.map(emp => <EmployeeCard key={emp.id} emp={emp} />)}
              </div>
            )}
          </TabsContent>

          <TabsContent value="freelancer">
            {freelancers.length === 0 ? (
              <Card><CardContent className="py-10 text-center text-muted-foreground text-sm">لا يوجد موظفون مستقلون</CardContent></Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {freelancers.map(emp => <EmployeeCard key={emp.id} emp={emp} />)}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editEmployee ? "تعديل بيانات الموظف" : "إضافة موظف جديد"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الاسم *</FormLabel>
                    <FormControl><Input placeholder="اسم الموظف" {...field} data-testid="input-emp-name" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="specialty" render={({ field }) => (
                  <FormItem>
                    <FormLabel>التخصص *</FormLabel>
                    <FormControl><Input placeholder="مصمم داخلي، مهندس..." {...field} data-testid="input-emp-specialty" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="department" render={({ field }) => (
                  <FormItem>
                    <FormLabel>القسم</FormLabel>
                    <FormControl><Input placeholder="قسم التصميم" {...field} value={field.value ?? ""} data-testid="input-emp-department" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="employeeType" render={({ field }) => (
                  <FormItem>
                    <FormLabel>نوع العقد *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-emp-type">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="internal">موظف داخلي</SelectItem>
                        <SelectItem value="freelancer">مستقل (فريلانسر)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {empType === "internal" && (
                <div className="grid grid-cols-3 gap-3">
                  <FormField control={form.control} name="designPercentage" render={({ field }) => (
                    <FormItem>
                      <FormLabel>% التصميم</FormLabel>
                      <FormControl><Input type="number" placeholder="10" {...field} value={field.value ?? ""} data-testid="input-emp-design-pct" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="executivePercentage" render={({ field }) => (
                    <FormItem>
                      <FormLabel>% التنفيذي</FormLabel>
                      <FormControl><Input type="number" placeholder="7" {...field} value={field.value ?? ""} data-testid="input-emp-exec-pct" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="structuralPercentage" render={({ field }) => (
                    <FormItem>
                      <FormLabel>% الهيكل</FormLabel>
                      <FormControl><Input type="number" placeholder="5" {...field} value={field.value ?? ""} data-testid="input-emp-struct-pct" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              )}

              {empType === "freelancer" && (
                <FormField control={form.control} name="pricePerSqm" render={({ field }) => (
                  <FormItem>
                    <FormLabel>سعر المتر (ريال)</FormLabel>
                    <FormControl><Input type="number" placeholder="50" {...field} value={field.value ?? ""} data-testid="input-emp-price-sqm" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              )}

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم التواصل</FormLabel>
                    <FormControl><Input placeholder="05XXXXXXXX" {...field} value={field.value ?? ""} data-testid="input-emp-phone" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel>البريد الإلكتروني</FormLabel>
                    <FormControl><Input placeholder="email@example.com" {...field} value={field.value ?? ""} data-testid="input-emp-email" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="nationality" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الجنسية</FormLabel>
                    <FormControl><Input placeholder="سعودي..." {...field} value={field.value ?? ""} data-testid="input-emp-nationality" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="jobTitle" render={({ field }) => (
                  <FormItem>
                    <FormLabel>المسمى الوظيفي</FormLabel>
                    <FormControl><Input placeholder="مصمم داخلي..." {...field} value={field.value ?? ""} data-testid="input-emp-job-title" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="baseSalary" render={({ field }) => (
                  <FormItem>
                    <FormLabel>الراتب الأساسي (ريال)</FormLabel>
                    <FormControl><Input type="number" placeholder="3000" {...field} value={field.value ?? ""} data-testid="input-emp-base-salary" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="contractStartDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>تاريخ بدء العقد</FormLabel>
                    <FormControl><Input type="date" {...field} value={field.value ?? ""} data-testid="input-emp-contract-start" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="salaryDescription" render={({ field }) => (
                <FormItem>
                  <FormLabel>تفاصيل الراتب والعمولات</FormLabel>
                  <FormControl><Textarea placeholder="مثال: 3000 ريال + نسبة 10%..." {...field} value={field.value ?? ""} data-testid="input-emp-salary-desc" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="jobRoles" render={({ field }) => (
                <FormItem>
                  <FormLabel>الأدوار الوظيفية</FormLabel>
                  <FormControl><Textarea placeholder="المهام والمسؤوليات..." {...field} value={field.value ?? ""} data-testid="input-emp-job-roles" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="bankAccount" render={({ field }) => (
                <FormItem>
                  <FormLabel>الحساب البنكي (IBAN)</FormLabel>
                  <FormControl><Input placeholder="SA..." {...field} value={field.value ?? ""} data-testid="input-emp-bank" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="notes" render={({ field }) => (
                <FormItem>
                  <FormLabel>ملاحظات</FormLabel>
                  <FormControl><Textarea placeholder="ملاحظات..." {...field} value={field.value ?? ""} data-testid="input-emp-notes" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <DialogFooter className="gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-employee">
                  {editEmployee ? "حفظ التغييرات" : "إضافة"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
