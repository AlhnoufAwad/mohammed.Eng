import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { FolderOpen, DollarSign, CheckSquare } from "lucide-react";
import logoIcon from "@assets/WhatsApp_Image_2026-02-24_at_11.25.33_PM_1771964913996.jpeg";
import { apiRequest } from "@/lib/queryClient";

export default function AuthPage() {
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [loginData, setLoginData] = useState({ username: "", password: "" });
  const [isLoginLoading, setIsLoginLoading] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setForgotLoading(true);
    try {
      const res: any = await apiRequest("POST", "/api/auth/forgot-password", { email: forgotEmail });
      setForgotSent(true);
      if (res.devMode) {
        toast({ title: "وضع التطوير", description: `رمز الإعادة: ${res.resetToken}` });
      } else {
        toast({ title: "تم الإرسال", description: res.message || "تحقق من بريدك الإلكتروني" });
      }
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setForgotLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoginLoading(true);
    try {
      await login(loginData);
      setLocation("/");
    } catch (err: any) {
      toast({ title: "خطأ", description: err.message || "فشل تسجيل الدخول", variant: "destructive" });
    } finally {
      setIsLoginLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex" dir="rtl">
      <div className="flex-1 flex items-center justify-center p-6 bg-background">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full overflow-hidden mb-5 shadow-xl ring-4 ring-foreground/10">
              <img src={logoIcon} alt="Mohammed Al Balwi Group" className="h-full w-full object-cover" />
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-wide">MOHAMMED AL BALWI GROUP</h1>
            <p className="text-muted-foreground text-sm mt-1">نظام الإدارة والمالية</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-center">تسجيل الدخول</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username">اسم المستخدم</Label>
                  <Input
                    id="login-username"
                    data-testid="input-login-username"
                    value={loginData.username}
                    onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">كلمة المرور</Label>
                  <Input
                    id="login-password"
                    type="password"
                    data-testid="input-login-password"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoginLoading} data-testid="button-login">
                  {isLoginLoading ? "جاري الدخول..." : "دخول"}
                </Button>
              </form>
              <div className="mt-3 text-center">
                <button
                  className="text-xs text-muted-foreground hover:text-primary underline"
                  onClick={() => { setShowForgot(!showForgot); setForgotSent(false); setForgotEmail(""); }}
                  data-testid="button-forgot-password"
                >
                  نسيت كلمة المرور؟
                </button>
              </div>
              {showForgot && (
                <div className="mt-4 p-4 bg-muted/50 rounded-lg border">
                  {forgotSent ? (
                    <div className="text-center space-y-2">
                      <p className="text-sm font-medium text-green-700 dark:text-green-400">تم إرسال رابط إعادة التعيين</p>
                      <p className="text-xs text-muted-foreground">تحقق من بريدك الإلكتروني واتبع التعليمات</p>
                      <button className="text-xs text-primary underline" onClick={() => { setForgotSent(false); setShowForgot(false); }}>عودة لتسجيل الدخول</button>
                    </div>
                  ) : (
                    <form onSubmit={handleForgotPassword} className="space-y-3">
                      <p className="text-xs font-medium">أدخل بريدك الإلكتروني المسجل</p>
                      <Input type="email" placeholder="email@example.com" dir="ltr" value={forgotEmail} onChange={e => setForgotEmail(e.target.value)} required data-testid="input-forgot-email" />
                      <Button type="submit" size="sm" className="w-full" disabled={forgotLoading} data-testid="button-submit-forgot">
                        {forgotLoading ? "جاري الإرسال..." : "إرسال رابط الاستعادة"}
                      </Button>
                    </form>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="hidden lg:flex flex-1 items-center justify-center bg-black p-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "32px 32px" }} />
        <div className="max-w-lg text-center relative z-10">
          <div className="mb-10">
            <div className="w-32 h-32 rounded-full overflow-hidden mx-auto ring-4 ring-white/10 shadow-2xl">
              <img src={logoIcon} alt="Mohammed Al Balwi Group" className="h-full w-full object-cover" />
            </div>
          </div>
          <p className="text-white/60 text-sm font-medium tracking-[0.2em] uppercase mb-2">MOHAMMED AL BALWI GROUP</p>
          <div className="w-16 h-px bg-white/20 mx-auto mb-8" />
          <h2 className="text-2xl font-bold text-white/90 mb-3">نظام إدارة المشاريع</h2>
          <p className="text-white/40 text-base leading-relaxed max-w-sm mx-auto">
            نظام متكامل لإدارة مشاريع التصميم الداخلي والخارجي
          </p>
          <div className="grid grid-cols-3 gap-3 mt-10">
            <div className="p-4 rounded-xl border border-white/10 bg-white/[0.03]">
              <FolderOpen className="w-5 h-5 text-white/50 mx-auto mb-2" />
              <div className="text-xs font-medium text-white/70">إدارة المشاريع</div>
            </div>
            <div className="p-4 rounded-xl border border-white/10 bg-white/[0.03]">
              <DollarSign className="w-5 h-5 text-white/50 mx-auto mb-2" />
              <div className="text-xs font-medium text-white/70">متابعة المالية</div>
            </div>
            <div className="p-4 rounded-xl border border-white/10 bg-white/[0.03]">
              <CheckSquare className="w-5 h-5 text-white/50 mx-auto mb-2" />
              <div className="text-xs font-medium text-white/70">تنظيم المهام</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
