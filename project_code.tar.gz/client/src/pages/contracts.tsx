import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { Contract, Project, Client } from "@shared/schema";
import { Plus, Search, Edit, FileText, CheckCircle2, XCircle, User, Phone, MapPin, Ruler, DollarSign, Calendar, Clock, Download } from "lucide-react";
import { formatDate, getProjectTypeLabel, formatCurrency } from "@/lib/utils";
import { useLocation } from "wouter";
import type { Payment } from "@shared/schema";

function escapeHtml(str: string): string {
  return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

function exportContractPDF(contract: Contract, project: Project | undefined, client: Client | undefined, payments: Payment[], contractTerms: any[] = []) {
  const projectPayments = payments.filter(p => p.projectId === project?.id);
  const firstStepLabel = project?.projectType === "interior" ? "تسليم لوحة الأفكار" : "تسليم الهيكل الإنشائي";
  const vatRate = 0.15;
  const totalValue = project?.totalValue || 0;
  const vatAmount = totalValue * vatRate;
  const totalWithVat = totalValue + vatAmount;

  const termsHtml = contractTerms.length > 0
    ? contractTerms.map((t, i) => `<div class="term-item"><span class="term-num">${i + 1}.</span><span>${escapeHtml(t.termText)}</span></div>`).join("")
    : (contract.terms ? `<div class="terms-box">${escapeHtml(contract.terms)}</div>` : "");

  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>عقد رقم ${escapeHtml(contract.contractNumber)}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap');
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'IBM Plex Sans Arabic', sans-serif; direction: rtl; padding: 40px; color: #111; font-size: 13px; line-height: 1.8; }
  .header { text-align: center; border-bottom: 3px double #111; padding-bottom: 20px; margin-bottom: 30px; }
  .header h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
  .header h2 { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 4px; }
  .header p { font-size: 12px; color: #666; }
  .contract-number { display: inline-block; background: #111; color: #fff; padding: 4px 20px; border-radius: 4px; font-size: 14px; font-weight: 600; margin-top: 10px; }
  .section { margin-bottom: 20px; }
  .section-title { font-size: 14px; font-weight: 700; background: #f5f5f5; padding: 6px 16px; border-right: 4px solid #111; margin-bottom: 10px; }
  .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 24px; padding: 0 16px; }
  .info-row { display: flex; gap: 8px; }
  .info-label { color: #666; min-width: 120px; }
  .info-value { font-weight: 600; }
  .total-value { font-size: 16px; color: #111; }
  .payments-table { width: 100%; border-collapse: collapse; margin: 8px 0; }
  .payments-table th, .payments-table td { border: 1px solid #ddd; padding: 6px 10px; text-align: right; font-size: 12px; }
  .payments-table th { background: #f5f5f5; font-weight: 600; }
  .pricing-table { width: 100%; border-collapse: collapse; margin: 8px 0; }
  .pricing-table th, .pricing-table td { border: 1px solid #ddd; padding: 6px 10px; text-align: right; font-size: 12px; }
  .pricing-table th { background: #f5f5f5; font-weight: 600; }
  .pricing-table .highlight { background: #f0f0f0; font-weight: 700; }
  .terms-section { padding: 0 16px; }
  .term-item { display: flex; gap: 8px; padding: 4px 0; border-bottom: 1px dotted #eee; font-size: 12px; line-height: 1.7; }
  .term-num { font-weight: 700; color: #333; min-width: 22px; }
  .terms-box { padding: 10px 16px; background: #fafafa; border: 1px solid #eee; border-radius: 4px; white-space: pre-wrap; font-size: 12px; }
  .signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-top: 50px; padding: 0 16px; }
  .sig-box { text-align: center; padding-top: 20px; }
  .sig-line { border-top: 1px solid #111; margin-top: 60px; padding-top: 8px; font-weight: 600; }
  .footer { text-align: center; margin-top: 30px; padding-top: 12px; border-top: 1px solid #ddd; font-size: 10px; color: #999; }
  @media print { body { padding: 20px; } @page { margin: 12mm; size: A4; } }
</style>
</head>
<body>
<div class="header">
  <h1>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</h1>
  <h2>عقد تصميم ${project?.projectType === "interior" ? "داخلي" : project?.projectType === "facades" ? "واجهات" : "خارجي"}</h2>
  <p>Mohammed Al-Balawi Interior & Exterior Design Est.</p>
  <div class="contract-number">عقد رقم: ${escapeHtml(contract.contractNumber)}</div>
</div>

<div class="section">
  <div class="section-title">بيانات الطرف الثاني (العميل)</div>
  <div class="info-grid">
    <div class="info-row"><span class="info-label">الاسم:</span><span class="info-value">${escapeHtml(client?.name || "—")}</span></div>
    <div class="info-row"><span class="info-label">رقم الجوال:</span><span class="info-value">${escapeHtml(client?.phone || "—")}</span></div>
    <div class="info-row"><span class="info-label">العنوان:</span><span class="info-value">${escapeHtml(client?.city || project?.location || "—")}</span></div>
    <div class="info-row"><span class="info-label">تاريخ العقد:</span><span class="info-value">${escapeHtml(contract.contractDate)}</span></div>
  </div>
</div>

<div class="section">
  <div class="section-title">تفاصيل المشروع والأسعار</div>
  <table class="pricing-table">
    <thead><tr><th>البند</th><th>التفاصيل</th></tr></thead>
    <tbody>
      <tr><td>نوع التصميم</td><td>${project?.projectType === "interior" ? "تصميم داخلي" : project?.projectType === "facades" ? "واجهات" : "تصميم خارجي"}</td></tr>
      <tr><td>المساحة</td><td>${project?.areaSqm ? project.areaSqm + " م²" : "—"}</td></tr>
      <tr><td>سعر المتر المربع</td><td>${project?.pricePerSqm ? Number(project.pricePerSqm).toLocaleString("ar-SA") + " ر.س" : "—"}</td></tr>
      <tr class="highlight"><td>إجمالي قيمة العقد (بدون ضريبة)</td><td>${totalValue.toLocaleString("ar-SA")} ر.س</td></tr>
      <tr><td>ضريبة القيمة المضافة (${(vatRate * 100)}%)</td><td>${vatAmount.toLocaleString("ar-SA")} ر.س</td></tr>
      <tr class="highlight"><td>الإجمالي شامل الضريبة</td><td>${totalWithVat.toLocaleString("ar-SA")} ر.س</td></tr>
      ${project?.startDate ? `<tr><td>${firstStepLabel}</td><td>${project.startDate}</td></tr>` : ""}
      ${project?.endDate ? `<tr><td>التسليم النهائي</td><td>${project.endDate}</td></tr>` : ""}
      ${project?.executionDays ? `<tr><td>مدة التنفيذ</td><td>${project.executionDays} يوم</td></tr>` : ""}
    </tbody>
  </table>
</div>

${projectPayments.length > 0 ? `
<div class="section">
  <div class="section-title">جدول الدفعات</div>
  <table class="payments-table">
    <thead><tr><th>الدفعة</th><th>النسبة</th><th>المبلغ</th><th>الوصف</th><th>الحالة</th></tr></thead>
    <tbody>
      ${projectPayments.map(p => `<tr>
        <td>الدفعة ${p.paymentNumber}</td>
        <td>${p.percentage}%</td>
        <td>${p.amount.toLocaleString("ar-SA")} ر.س</td>
        <td>${escapeHtml(p.paymentType)}</td>
        <td>${p.status === "paid" ? "مدفوعة ✓" : "معلقة"}</td>
      </tr>`).join("")}
    </tbody>
  </table>
</div>` : ""}

${termsHtml ? `
<div class="section">
  <div class="section-title">بنود العقد</div>
  <div class="terms-section">${termsHtml}</div>
</div>` : ""}

${contract.specialConditions ? `
<div class="section">
  <div class="section-title">الشروط الخاصة</div>
  <div class="terms-box">${escapeHtml(contract.specialConditions)}</div>
</div>` : ""}

${contract.notes ? `
<div class="section">
  <div class="section-title">ملاحظات</div>
  <div class="terms-box">${escapeHtml(contract.notes || "")}</div>
</div>` : ""}

<div class="signatures">
  <div class="sig-box">
    <img src="${window.location.origin}/signature.png" style="height:72px;object-fit:contain;margin-bottom:6px;display:block;margin-left:auto;margin-right:auto;" onerror="this.style.display='none'" />
    <div class="sig-line">الطرف الأول (المؤسسة)</div>
    <p style="margin-top:8px;font-size:12px;color:#666;">مؤسسة محمد البلوي للتصميم</p>
  </div>
  <div class="sig-box">
    <div style="height:78px;"></div>
    <div class="sig-line">الطرف الثاني (العميل)</div>
    <p style="margin-top:8px;font-size:12px;color:#666;">${escapeHtml(client?.name || "")}</p>
  </div>
</div>

<div class="footer">
  <p>مؤسسة محمد البلوي للتصميم الداخلي والخارجي — جميع الحقوق محفوظة</p>
</div>

<script>window.onload = function() { window.print(); }</script>
</body>
</html>`;

  const win = window.open("", "_blank");
  if (win) {
    win.document.write(html);
    win.document.close();
  }
}

export default function Contracts() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editContract, setEditContract] = useState<Contract | null>(null);
  const [viewContract, setViewContract] = useState<Contract | null>(null);

  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [clientAddress, setClientAddress] = useState("");
  const [projectType, setProjectType] = useState<string>("interior");
  const [areaSqm, setAreaSqm] = useState("");
  const [pricePerSqm, setPricePerSqm] = useState("");
  const [totalValue, setTotalValue] = useState("");
  const [paymentSchedule, setPaymentSchedule] = useState("3");
  const [firstStepDate, setFirstStepDate] = useState("");
  const [finalDeliveryDate, setFinalDeliveryDate] = useState("");
  const [executionDays, setExecutionDays] = useState("");
  const [terms, setTerms] = useState("");
  const [specialConditions, setSpecialConditions] = useState("");
  const [notes, setNotes] = useState("");

  const { data: contracts = [], isLoading } = useQuery<Contract[]>({ queryKey: ["/api/contracts"] });
  const { data: projects = [] } = useQuery<Project[]>({ queryKey: ["/api/projects"] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: payments = [] } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });

  const createFullMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/contracts/full", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "تم إنشاء العقد بنجاح", description: "تم إنشاء العميل والمشروع والعقد والدفعات تلقائياً" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) =>
      apiRequest("PUT", `/api/contracts/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      toast({ title: "تم تحديث العقد" });
      setDialogOpen(false);
      setEditContract(null);
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const getProject = (id: string) => projects.find(p => p.id === id);
  const getClient = (clientId: string) => clients.find(c => c.id === clientId);

  async function handleExportPDF(contract: Contract) {
    const project = getProject(contract.projectId);
    const client = project ? getClient(project.clientId) : undefined;
    try {
      const res = await fetch(`/api/contracts/${contract.id}/terms`, { credentials: "include" });
      const terms = res.ok ? await res.json() : [];
      exportContractPDF(contract, project, client, payments, terms);
    } catch {
      exportContractPDF(contract, project, client, payments, []);
    }
  }

  const filtered = contracts.filter(c => {
    const p = getProject(c.projectId);
    const cl = p ? getClient(p.clientId) : null;
    const q = search.toLowerCase();
    return c.contractNumber.toLowerCase().includes(q) ||
      (p?.title || "").toLowerCase().includes(q) ||
      (cl?.name || "").toLowerCase().includes(q);
  });

  function resetForm() {
    setClientName(""); setClientPhone(""); setClientAddress("");
    setProjectType("interior"); setAreaSqm(""); setPricePerSqm("");
    setTotalValue(""); setPaymentSchedule("3"); setFirstStepDate("");
    setFinalDeliveryDate(""); setExecutionDays(""); setTerms(""); setSpecialConditions(""); setNotes("");
  }

  function openAdd() {
    setEditContract(null);
    resetForm();
    setTerms(getDefaultTerms("interior"));
    setDialogOpen(true);
  }

  function openEdit(c: Contract) {
    setEditContract(c);
    setTerms(c.terms || "");
    setSpecialConditions(c.specialConditions || "");
    setNotes(c.notes || "");
    setDialogOpen(true);
  }

  function getDefaultTerms(type: string): string {
    const common = "- يلتزم الطرف الأول بتقديم كافة التصاميم المتفق عليها خلال المدة المحددة\n- يلتزم الطرف الثاني بسداد الدفعات في مواعيدها المحددة\n- لا يحق لأي طرف إلغاء العقد من جانب واحد إلا بموافقة الطرف الآخر\n- في حالة التأخير عن السداد يحق للطرف الأول إيقاف العمل حتى السداد";
    if (type === "interior") {
      return common + "\n- يشمل العقد التصميم الداخلي الكامل بما في ذلك الأثاث والإضاءة والتشطيبات\n- يتم تسليم لوحة الأفكار (Mood Board) في المرحلة الأولى للموافقة\n- التعديلات على التصميم المعتمد تخضع لرسوم إضافية\n- يتم تسليم ملفات التصميم النهائية بصيغة PDF و DWG";
    }
    if (type === "exterior") {
      return common + "\n- يشمل العقد التصميم الخارجي للواجهات والمسطحات الخضراء والإضاءة الخارجية\n- يتم مراعاة أنظمة البناء والاشتراطات البلدية\n- يتم تقديم مناظير ثلاثية الأبعاد للتصميم الخارجي\n- التعديلات بعد الاعتماد النهائي تخضع لرسوم إضافية";
    }
    if (type === "facades") {
      return common + "\n- يشمل العقد تصميم الواجهات المعمارية وفق الطراز المتفق عليه\n- يتم تقديم خيارات متعددة للواجهات للاختيار من بينها\n- يراعى التصميم التوافق مع الاشتراطات البلدية والأنظمة المعمارية\n- يتم تسليم المخططات التنفيذية للواجهات";
    }
    return common;
  }

  function handleProjectTypeChange(type: string) {
    setProjectType(type);
    if (!editContract) {
      setTerms(getDefaultTerms(type));
    }
  }

  function getClientPriceSuggestion(type: string, area: number): { price: number; label: string } | null {
    if (type === "interior") {
      if (area <= 50) return { price: 4000, label: "سعر ثابت (حتى 50م²)" };
      if (area <= 100) return { price: area * 65, label: `65 ر.س/م² × ${area}` };
      if (area <= 200) return { price: area * 65, label: `65 ر.س/م² × ${area}` };
      if (area <= 400) return { price: area * 60, label: `60 ر.س/م² × ${area}` };
      if (area <= 800) return { price: area * 50, label: `50 ر.س/م² × ${area}` };
      if (area <= 1200) return { price: area * 30, label: `30 ر.س/م² × ${area}` };
      return { price: area * 30, label: `30 ر.س/م² × ${area}` };
    }
    if (type === "exterior") {
      if (area <= 50) return { price: 2500, label: "سعر ثابت (حتى 50م²)" };
      if (area <= 100) return { price: 3000, label: "سعر ثابت (50-100م²)" };
      if (area <= 150) return { price: area * 40, label: `40 ر.س/م² × ${area}` };
      if (area <= 300) return { price: area * 35, label: `35 ر.س/م² × ${area}` };
      if (area <= 500) return { price: area * 30, label: `30 ر.س/م² × ${area}` };
      return { price: area * 25, label: `25 ر.س/م² × ${area}` };
    }
    if (type === "facades") {
      if (area <= 100) return { price: 3500, label: "سعر ثابت (حتى 100م²)" };
      if (area <= 200) return { price: area * 45, label: `45 ر.س/م² × ${area}` };
      if (area <= 400) return { price: area * 40, label: `40 ر.س/م² × ${area}` };
      return { price: area * 35, label: `35 ر.س/م² × ${area}` };
    }
    return null;
  }

  const parsedArea = areaSqm ? parseFloat(areaSqm) : 0;
  const priceSuggestion = parsedArea > 0 ? getClientPriceSuggestion(projectType, parsedArea) : null;

  function handleAreaChange(val: string) {
    setAreaSqm(val);
    if (val && totalValue) {
      const area = parseFloat(val);
      if (area > 0) setPricePerSqm((parseFloat(totalValue) / area).toFixed(2));
    }
  }

  function handleTotalChange(val: string) {
    setTotalValue(val);
    if (val && areaSqm) {
      const area = parseFloat(areaSqm);
      if (area > 0) setPricePerSqm((parseFloat(val) / area).toFixed(2));
    }
  }

  function applyPriceSuggestion() {
    if (priceSuggestion) {
      setTotalValue(String(priceSuggestion.price));
      if (areaSqm) {
        const area = parseFloat(areaSqm);
        if (area > 0) setPricePerSqm((priceSuggestion.price / area).toFixed(2));
      }
    }
  }

  function handleExecutionDaysChange(val: string) {
    setExecutionDays(val);
    const days = val ? parseInt(val) : 0;
    if (days > 0) {
      const today = new Date();
      const halfD = new Date(today);
      halfD.setDate(halfD.getDate() + Math.round(days / 2));
      setFirstStepDate(halfD.toISOString().split("T")[0]);
      const endD = new Date(today);
      endD.setDate(endD.getDate() + days);
      setFinalDeliveryDate(endD.toISOString().split("T")[0]);
    } else {
      setFirstStepDate("");
      setFinalDeliveryDate("");
    }
  }

  function onSubmit() {
    if (editContract) {
      updateMutation.mutate({
        id: editContract.id,
        data: { terms, specialConditions, notes },
      });
    } else {
      if (!clientName || !clientPhone || !areaSqm || !totalValue) {
        toast({ title: "تنبيه", description: "يرجى تعبئة جميع الحقول المطلوبة", variant: "destructive" });
        return;
      }
      createFullMutation.mutate({
        clientName, clientPhone, clientAddress, projectType,
        areaSqm, pricePerSqm, totalValue, paymentSchedule,
        firstStepDate, finalDeliveryDate, executionDays,
        terms, specialConditions, notes,
      });
    }
  }

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-contracts-title">العقود</h1>
          <p className="text-muted-foreground text-sm mt-1">إنشاء وإدارة عقود المشاريع</p>
        </div>
        <Button onClick={openAdd} data-testid="button-add-contract">
          <Plus className="h-4 w-4 ml-2" />
          عقد جديد
        </Button>
      </div>

      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="بحث برقم العقد أو اسم العميل..."
          className="pr-10"
          value={search}
          onChange={e => setSearch(e.target.value)}
          data-testid="input-search-contracts"
        />
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-48" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center py-16">
            <FileText className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground">لا توجد عقود</p>
            <p className="text-muted-foreground text-sm mt-1">ابدأ بإنشاء عقد جديد لإضافة عميل ومشروع تلقائياً</p>
            <Button onClick={openAdd} className="mt-4" data-testid="button-add-contract-empty">
              <Plus className="h-4 w-4 ml-2" />عقد جديد
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((contract) => {
            const project = getProject(contract.projectId);
            const client = project ? getClient(project.clientId) : null;
            return (
              <Card key={contract.id} className="hover-elevate" data-testid={`card-contract-${contract.id}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <FileText className="h-4 w-4 text-primary" />
                        <CardTitle className="text-base">عقد رقم: {contract.contractNumber}</CardTitle>
                      </div>
                      {client && (
                        <p className="text-sm font-medium text-foreground" data-testid={`text-client-name-${contract.id}`}>{client.name}</p>
                      )}
                      {project && (
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">{getProjectTypeLabel(project.projectType)}</Badge>
                          {project.areaSqm && <span className="text-xs text-muted-foreground">{project.areaSqm} م²</span>}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5">
                        {contract.clientSigned
                          ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                          : <XCircle className="h-3.5 w-3.5 text-muted-foreground" />}
                        <span className="text-xs text-muted-foreground">العميل</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {contract.companySigned
                          ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                          : <XCircle className="h-3.5 w-3.5 text-muted-foreground" />}
                        <span className="text-xs text-muted-foreground">المؤسسة</span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="text-xs text-muted-foreground">تاريخ العقد</p>
                      <p className="text-sm font-medium">{formatDate(contract.contractDate)}</p>
                    </div>
                    {project && (
                      <div className="text-left">
                        <p className="text-xs text-muted-foreground">قيمة العقد</p>
                        <p className="text-sm font-bold text-primary">{formatCurrency(project.totalValue)}</p>
                      </div>
                    )}
                  </div>
                  {project && (
                    <div className="flex items-center gap-4 mb-3 text-xs text-muted-foreground">
                      {project.startDate && (
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>بداية: {formatDate(project.startDate)}</span>
                        </div>
                      )}
                      {project.endDate && (
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>نهاية: {formatDate(project.endDate)}</span>
                        </div>
                      )}
                    </div>
                  )}
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1" onClick={() => setViewContract(contract)} data-testid={`button-view-contract-${contract.id}`}>
                      عرض التفاصيل
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleExportPDF(contract)} data-testid={`button-pdf-contract-${contract.id}`} title="تصدير PDF">
                      <Download className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => openEdit(contract)} data-testid={`button-edit-contract-${contract.id}`}>
                      <Edit className="h-3.5 w-3.5" />
                    </Button>
                    {project && (
                      <Button size="sm" variant="outline" onClick={() => navigate(`/projects/${project.id}`)} data-testid={`button-goto-project-${contract.id}`}>
                        المشروع
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!viewContract} onOpenChange={() => setViewContract(null)}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              عقد رقم: {viewContract?.contractNumber}
            </DialogTitle>
          </DialogHeader>
          {viewContract && (() => {
            const p = getProject(viewContract.projectId);
            const cl = p ? getClient(p.clientId) : null;
            return (
              <div className="space-y-6">
                <div className="p-4 bg-muted rounded-md">
                  <h3 className="font-semibold text-sm mb-3">بيانات العميل</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div><span className="text-muted-foreground">الاسم: </span><span className="font-medium">{cl?.name || "—"}</span></div>
                    <div><span className="text-muted-foreground">الجوال: </span><span className="font-medium">{cl?.phone || "—"}</span></div>
                    <div><span className="text-muted-foreground">العنوان: </span><span className="font-medium">{cl?.city || p?.location || "—"}</span></div>
                  </div>
                </div>

                <div className="p-4 bg-muted rounded-md">
                  <h3 className="font-semibold text-sm mb-3">تفاصيل المشروع</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div><span className="text-muted-foreground">نوع العقد: </span><span className="font-medium">{p ? getProjectTypeLabel(p.projectType) : "—"}</span></div>
                    <div><span className="text-muted-foreground">المساحة: </span><span className="font-medium">{p?.areaSqm ? `${p.areaSqm} م²` : "—"}</span></div>
                    <div><span className="text-muted-foreground">سعر المتر: </span><span className="font-medium">{p?.pricePerSqm ? formatCurrency(p.pricePerSqm) : "—"}</span></div>
                    <div><span className="text-muted-foreground">الإجمالي: </span><span className="font-bold text-primary">{p ? formatCurrency(p.totalValue) : "—"}</span></div>
                    <div><span className="text-muted-foreground">{p?.projectType === "interior" ? "تسليم لوحة الأفكار: " : "تسليم الهيكل الإنشائي: "}</span><span className="font-medium">{p?.startDate ? formatDate(p.startDate) : "—"}</span></div>
                    <div><span className="text-muted-foreground">التسليم النهائي: </span><span className="font-medium">{p?.endDate ? formatDate(p.endDate) : "—"}</span></div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 p-3 border rounded-md">
                    {viewContract.clientSigned
                      ? <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                      : <XCircle className="h-5 w-5 text-muted-foreground" />}
                    <div>
                      <p className="text-sm font-medium">توقيع العميل</p>
                      <p className="text-xs text-muted-foreground">{viewContract.clientSigned ? "موقع" : "غير موقع"}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 border rounded-md">
                    {viewContract.companySigned
                      ? <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                      : <XCircle className="h-5 w-5 text-muted-foreground" />}
                    <div>
                      <p className="text-sm font-medium">توقيع المؤسسة</p>
                      <p className="text-xs text-muted-foreground">{viewContract.companySigned ? "موقع" : "غير موقع"}</p>
                    </div>
                  </div>
                </div>

                {viewContract.terms && (
                  <div>
                    <h3 className="font-semibold text-sm mb-2">بنود العقد</h3>
                    <div className="p-3 bg-muted rounded-md text-sm whitespace-pre-wrap">{viewContract.terms}</div>
                  </div>
                )}
                {viewContract.specialConditions && (
                  <div>
                    <h3 className="font-semibold text-sm mb-2">الشروط الخاصة</h3>
                    <div className="p-3 bg-muted rounded-md text-sm whitespace-pre-wrap">{viewContract.specialConditions}</div>
                  </div>
                )}
                {viewContract.notes && (
                  <div>
                    <h3 className="font-semibold text-sm mb-2">ملاحظات</h3>
                    <div className="p-3 bg-muted rounded-md text-sm">{viewContract.notes}</div>
                  </div>
                )}
              </div>
            );
          })()}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setViewContract(null)}>إغلاق</Button>
            <Button variant="outline" onClick={() => {
              if (viewContract) {
                const p = getProject(viewContract.projectId);
                const cl = p ? getClient(p.clientId) : undefined;
                exportContractPDF(viewContract, p, cl, payments);
              }
            }} data-testid="button-export-pdf">
              <Download className="h-4 w-4 ml-2" />تصدير PDF
            </Button>
            <Button onClick={() => { setViewContract(null); openEdit(viewContract!); }}>
              <Edit className="h-4 w-4 ml-2" />تعديل
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-lg">{editContract ? "تعديل بنود العقد" : "إنشاء عقد جديد"}</DialogTitle>
            {!editContract && <p className="text-sm text-muted-foreground mt-1">سيتم إنشاء العميل والمشروع والدفعات تلقائياً</p>}
          </DialogHeader>

          <div className="space-y-5">
            {!editContract && (
              <>
                <div className="p-4 border rounded-lg space-y-4">
                  <h3 className="font-semibold text-sm flex items-center gap-2">
                    <User className="h-4 w-4" />
                    بيانات العميل
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>اسم العميل *</Label>
                      <div className="relative">
                        <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pr-10" placeholder="اسم العميل الكامل" value={clientName} onChange={e => setClientName(e.target.value)} data-testid="input-client-name" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>رقم الجوال *</Label>
                      <div className="relative">
                        <Phone className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pr-10" placeholder="05xxxxxxxx" value={clientPhone} onChange={e => setClientPhone(e.target.value)} data-testid="input-client-phone" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>العنوان / المدينة</Label>
                    <div className="relative">
                      <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input className="pr-10" placeholder="المدينة والحي" value={clientAddress} onChange={e => setClientAddress(e.target.value)} data-testid="input-client-address" />
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-4">
                  <h3 className="font-semibold text-sm flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    تفاصيل العقد
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>نوع العقد *</Label>
                      <Select value={projectType} onValueChange={handleProjectTypeChange}>
                        <SelectTrigger data-testid="select-project-type"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="interior">تصميم داخلي</SelectItem>
                          <SelectItem value="exterior">تصميم خارجي</SelectItem>
                          <SelectItem value="facades">واجهات</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>عدد الدفعات</Label>
                      <Select value={paymentSchedule} onValueChange={setPaymentSchedule}>
                        <SelectTrigger data-testid="select-payment-schedule"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">دفعة واحدة (100%)</SelectItem>
                          <SelectItem value="2">دفعتين (50% + 50%)</SelectItem>
                          <SelectItem value="3">3 دفعات (50% + 30% + 20%)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>السعر الإجمالي (ر.س) *</Label>
                      <div className="relative">
                        <DollarSign className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pr-10" type="number" placeholder="0" value={totalValue} onChange={e => handleTotalChange(e.target.value)} data-testid="input-total-value" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>المساحة (م²) *</Label>
                      <div className="relative">
                        <Ruler className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pr-10" type="number" placeholder="0" value={areaSqm} onChange={e => handleAreaChange(e.target.value)} data-testid="input-area" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>سعر المتر (ر.س) — يُحسب تلقائياً</Label>
                      <div className="relative">
                        <DollarSign className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pr-10 bg-muted" type="number" placeholder="—" value={pricePerSqm} readOnly data-testid="input-price-sqm" />
                      </div>
                    </div>
                  </div>
                  {priceSuggestion && (
                    <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg flex items-center justify-between gap-3" data-testid="price-suggestion">
                      <div>
                        <p className="text-xs font-medium text-blue-700 dark:text-blue-400">السعر المقترح للعميل</p>
                        <p className="text-sm font-bold text-blue-800 dark:text-blue-300">{priceSuggestion.price.toLocaleString("ar-SA")} ر.س</p>
                        <p className="text-[10px] text-blue-600 dark:text-blue-400">{priceSuggestion.label}</p>
                      </div>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="border-blue-300 text-blue-700 dark:text-blue-400"
                        onClick={applyPriceSuggestion}
                        data-testid="button-apply-price"
                      >
                        تطبيق
                      </Button>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label>مدة التنفيذ (بالأيام)</Label>
                    <div className="relative">
                      <Clock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input className="pr-10" type="number" placeholder="مثال: 45" value={executionDays} onChange={e => handleExecutionDaysChange(e.target.value)} data-testid="input-execution-days" />
                    </div>
                    <p className="text-xs text-muted-foreground">سيتم حساب تواريخ المراحل تلقائياً بناءً على مدة التنفيذ والقدرة الاستيعابية للموظفين</p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{projectType === "interior" ? "تاريخ تسليم لوحة الأفكار" : "تاريخ تسليم الهيكل الإنشائي"}</Label>
                      <div className="relative">
                        <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pr-10" type="date" value={firstStepDate} onChange={e => setFirstStepDate(e.target.value)} data-testid="input-first-step-date" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>تاريخ التسليم النهائي</Label>
                      <div className="relative">
                        <Clock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pr-10" type="date" value={finalDeliveryDate} onChange={e => setFinalDeliveryDate(e.target.value)} data-testid="input-final-date" />
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            <div className="p-4 border rounded-lg space-y-4">
              <h3 className="font-semibold text-sm">بنود وشروط العقد</h3>
              <div className="space-y-2">
                <Label>بنود العقد</Label>
                <Textarea rows={3} placeholder="بنود العقد والشروط العامة..." value={terms} onChange={e => setTerms(e.target.value)} data-testid="input-contract-terms" />
              </div>
              <div className="space-y-2">
                <Label>الشروط الخاصة</Label>
                <Textarea rows={2} placeholder="شروط خاصة بهذا العقد..." value={specialConditions} onChange={e => setSpecialConditions(e.target.value)} data-testid="input-contract-conditions" />
              </div>
              <div className="space-y-2">
                <Label>ملاحظات</Label>
                <Textarea rows={2} placeholder="ملاحظات إضافية..." value={notes} onChange={e => setNotes(e.target.value)} data-testid="input-contract-notes" />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 mt-4">
            <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={onSubmit} disabled={createFullMutation.isPending || updateMutation.isPending} data-testid="button-save-contract">
              {createFullMutation.isPending ? "جاري الإنشاء..." : editContract ? "حفظ التغييرات" : "إنشاء العقد"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
