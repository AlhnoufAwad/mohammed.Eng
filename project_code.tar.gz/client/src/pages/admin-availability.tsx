import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Calendar, Users, FolderOpen, Clock, AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { formatDate, formatCurrency } from "@/lib/utils";
import type { Employee, Project, EmployeeAssignment } from "@shared/schema";

export default function AdminAvailability() {
  const { data: employees, isLoading: eLoading } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const { data: projects, isLoading: pLoading } = useQuery<Project[]>({ queryKey: ["/api/projects"] });
  const { data: allAssignments, isLoading: aLoading } = useQuery<EmployeeAssignment[]>({ queryKey: ["/api/assignments/all"] });

  if (eLoading || pLoading || aLoading) {
    return (
      <div className="p-6 space-y-4 overflow-auto h-full" dir="rtl">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  const activeEmployees = employees?.filter(e => e.isActive && e.employeeType !== "freelancer") || [];
  const freelancers = employees?.filter(e => e.isActive && e.employeeType === "freelancer") || [];
  const activeProjects = projects?.filter(p => p.status === "active") || [];

  function getEmployeeProjects(empId: string) {
    const empAssignments = (allAssignments || []).filter(a => a.employeeId === empId);
    return empAssignments.map(a => {
      const project = (projects || []).find(p => p.id === a.projectId);
      return { assignment: a, project };
    }).filter(x => x.project && x.project.status === "active");
  }

  function getRemainingDays(endDate: string | null | undefined): number | null {
    if (!endDate) return null;
    const end = new Date(endDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);
    return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  }

  function getUrgencyColor(days: number | null): string {
    if (days === null) return "text-muted-foreground";
    if (days < 0) return "text-red-600 dark:text-red-400";
    if (days <= 7) return "text-amber-600 dark:text-amber-400";
    return "text-emerald-600 dark:text-emerald-400";
  }

  function getUrgencyBadge(days: number | null) {
    if (days === null) return <Badge variant="secondary" className="text-[10px]">بدون موعد</Badge>;
    if (days < 0) return <Badge variant="destructive" className="text-[10px]">متأخر {Math.abs(days)} يوم</Badge>;
    if (days <= 7) return <Badge className="text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300">باقي {days} أيام</Badge>;
    return <Badge className="text-[10px] bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300">باقي {days} يوم</Badge>;
  }

  const totalAssigned = activeEmployees.reduce((s, e) => s + getEmployeeProjects(e.id).length, 0);

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-3" data-testid="text-page-title">
          <Users className="h-6 w-6" />
          تفرغ الموظفين والمشاريع
        </h1>
        <p className="text-muted-foreground">عرض تلقائي لكل موظف ومشاريعه الحالية مع مواعيد التسليم</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-foreground/5"><Users className="h-5 w-5" /></div>
            <div>
              <p className="text-sm text-muted-foreground">الموظفون الداخليون</p>
              <p className="text-xl font-bold" data-testid="text-active-employees">{activeEmployees.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-foreground/5"><FolderOpen className="h-5 w-5" /></div>
            <div>
              <p className="text-sm text-muted-foreground">المشاريع النشطة</p>
              <p className="text-xl font-bold" data-testid="text-active-projects">{activeProjects.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-foreground/5"><Calendar className="h-5 w-5" /></div>
            <div>
              <p className="text-sm text-muted-foreground">إجمالي التعيينات</p>
              <p className="text-xl font-bold" data-testid="text-total-assignments">{totalAssigned}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-lg font-semibold">الموظفون الداخليون</h2>
        {activeEmployees.map(emp => {
          const empProjects = getEmployeeProjects(emp.id);
          const projectCount = empProjects.length;
          const workloadPct = Math.min(100, projectCount * 25);
          return (
            <Card key={emp.id} className="hover-elevate" data-testid={`card-employee-${emp.id}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">{emp.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{emp.name}</p>
                      <p className="text-xs text-muted-foreground">{(emp as any).jobTitle || emp.specialty}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={projectCount === 0 ? "secondary" : "default"} className="text-xs">
                      {projectCount === 0 ? "متاح" : `${projectCount} مشاريع`}
                    </Badge>
                    <div className="w-24">
                      <Progress value={workloadPct} className="h-2" />
                    </div>
                  </div>
                </div>
                {empProjects.length > 0 && (
                  <div className="space-y-2 mr-12">
                    {empProjects.map(({ project, assignment }) => {
                      if (!project) return null;
                      const remaining = getRemainingDays(project.endDate);
                      return (
                        <div key={project.id} className="flex items-center justify-between p-2 bg-muted/40 rounded-lg text-xs" data-testid={`row-project-${project.id}`}>
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <Link href={`/projects/${project.id}`} className="font-medium text-blue-600 hover:underline truncate">
                              {project.title}
                            </Link>
                            {assignment.role && <Badge variant="outline" className="text-[9px]">{assignment.role}</Badge>}
                          </div>
                          <div className="flex items-center gap-3 flex-shrink-0">
                            {project.endDate && (
                              <span className={`text-[10px] ${getUrgencyColor(remaining)}`}>
                                <Clock className="h-3 w-3 inline ml-0.5" />
                                {formatDate(project.endDate)}
                              </span>
                            )}
                            {getUrgencyBadge(remaining)}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {freelancers.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">المستقلون</h2>
          {freelancers.map(emp => {
            const empProjects = getEmployeeProjects(emp.id);
            return (
              <Card key={emp.id} className="hover-elevate border-l-2 border-l-amber-500" data-testid={`card-freelancer-${emp.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center">
                        <span className="text-sm font-bold text-amber-600">{emp.name.charAt(0)}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{emp.name}</p>
                        <p className="text-xs text-muted-foreground">{(emp as any).jobTitle || emp.specialty}</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {empProjects.length === 0 ? "متاح" : `${empProjects.length} مشاريع`}
                    </Badge>
                  </div>
                  {empProjects.length > 0 && (
                    <div className="space-y-1.5 mt-2 mr-12">
                      {empProjects.map(({ project, assignment }) => {
                        if (!project) return null;
                        return (
                          <div key={project.id} className="flex items-center justify-between text-xs p-1.5 bg-muted/30 rounded">
                            <Link href={`/projects/${project.id}`} className="text-blue-600 hover:underline truncate">{project.title}</Link>
                            <span className="text-muted-foreground">{formatCurrency(assignment.assignedAmount || 0)}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
