import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { DollarSign, TrendingUp, Clock, AlertCircle, CheckCircle2, Plus, Trash2, Receipt, Percent, PiggyBank, Landmark } from "lucide-react";
import { formatCurrency, formatDate, getStatusLabel } from "@/lib/utils";
import type { Payment, Project, Client } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { useState } from "react";

const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))"];

export default function Finance() {
  const { toast } = useToast();
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [commitmentDialog, setCommitmentDialog] = useState(false);
  const [commitmentForm, setCommitmentForm] = useState({ title: "", amount: "", type: "expense", month: new Date().toISOString().slice(0, 7), notes: "" });

  const { data: payments = [], isLoading } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });
  const { data: projects = [] } = useQuery<Project[]>({ queryKey: ["/api/projects"] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: summary } = useQuery<any>({ queryKey: ["/api/finance/summary"] });
  const { data: commitments = [] } = useQuery<any[]>({ queryKey: ["/api/finance/commitments"] });

  const updatePayment = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PUT", `/api/payments/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/finance/summary"] });
      toast({ title: "تم تحديث الدفعة" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const createCommitment = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/finance/commitments", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/finance/commitments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/finance/summary"] });
      toast({ title: "تم إضافة الالتزام المالي" });
      setCommitmentDialog(false);
      setCommitmentForm({ title: "", amount: "", type: "expense", month: new Date().toISOString().slice(0, 7), notes: "" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteCommitment = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/finance/commitments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/finance/commitments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/finance/summary"] });
      toast({ title: "تم حذف الالتزام" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const getProject = (id: string) => projects.find(p => p.id === id);
  const getClient = (clientId: string) => clients.find(c => c.id === clientId);

  const totalPaid = payments.filter(p => p.status === "paid").reduce((s, p) => s + p.amount, 0);
  const totalPending = payments.filter(p => p.status === "pending").reduce((s, p) => s + p.amount, 0);
  const totalOverdue = payments.filter(p => p.status === "overdue").reduce((s, p) => s + p.amount, 0);
  const totalAll = payments.reduce((s, p) => s + p.amount, 0);

  const pieData = [
    { name: "مدفوع", value: totalPaid },
    { name: "معلق", value: totalPending },
    { name: "متأخر", value: totalOverdue },
  ].filter(d => d.value > 0);

  const projectRevenue = projects.map(p => {
    const pPays = payments.filter(pay => pay.projectId === p.id);
    const paid = pPays.filter(pay => pay.status === "paid").reduce((s, pay) => s + pay.amount, 0);
    return { name: p.title.substring(0, 15) + (p.title.length > 15 ? "..." : ""), paid, total: p.totalValue };
  }).filter(p => p.total > 0).slice(0, 8);

  const filtered = payments.filter(p => selectedStatus === "all" || p.status === selectedStatus);

  const markAsPaid = (payment: Payment) => {
    updatePayment.mutate({
      id: payment.id,
      data: { status: "paid", paidDate: new Date().toISOString().split("T")[0] },
    });
  };

  return (
    <div className="h-full overflow-y-auto p-6" dir="rtl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">المالية</h1>
        <p className="text-muted-foreground text-sm mt-1">متابعة الدفعات والإيرادات المالية والالتزامات</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-50 dark:bg-emerald-950 rounded-md">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">محصل</p>
                <p className="font-bold text-sm" data-testid="text-total-paid">{formatCurrency(totalPaid)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-50 dark:bg-amber-950 rounded-md">
                <Clock className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">معلق</p>
                <p className="font-bold text-sm" data-testid="text-total-pending">{formatCurrency(totalPending)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-rose-50 dark:bg-rose-950 rounded-md">
                <AlertCircle className="h-5 w-5 text-rose-600 dark:text-rose-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">متأخر</p>
                <p className="font-bold text-sm" data-testid="text-total-overdue">{formatCurrency(totalOverdue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-md">
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">الإجمالي</p>
                <p className="font-bold text-sm" data-testid="text-total-all">{formatCurrency(totalAll)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="payments" className="space-y-4">
        <TabsList>
          <TabsTrigger value="payments" data-testid="tab-payments">الدفعات</TabsTrigger>
          <TabsTrigger value="summary" data-testid="tab-summary">ملخص مالي</TabsTrigger>
          <TabsTrigger value="commitments" data-testid="tab-commitments">الالتزامات</TabsTrigger>
          <TabsTrigger value="charts" data-testid="tab-charts">الرسوم البيانية</TabsTrigger>
        </TabsList>

        <TabsContent value="payments">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <CardTitle className="text-sm">سجل الدفعات</CardTitle>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-36" data-testid="select-payment-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">الكل</SelectItem>
                    <SelectItem value="pending">معلقة</SelectItem>
                    <SelectItem value="paid">مدفوعة</SelectItem>
                    <SelectItem value="overdue">متأخرة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
              ) : filtered.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground text-sm">لا توجد دفعات</div>
              ) : (
                <div className="space-y-2">
                  {filtered.map(payment => {
                    const project = getProject(payment.projectId);
                    const client = project ? getClient(project.clientId) : null;
                    const vatAmount = payment.amount - (payment.amount / 1.15);
                    const netAfterVat = payment.amount / 1.15;
                    return (
                      <div key={payment.id} className="flex items-center justify-between gap-3 p-3 border border-border rounded-md hover-elevate" data-testid={`row-payment-${payment.id}`}>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-medium truncate">{payment.paymentType}</p>
                            <Badge
                              className={`text-xs ${
                                payment.status === "paid"
                                  ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300"
                                  : payment.status === "overdue"
                                  ? "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300"
                                  : "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300"
                              }`}
                            >
                              {getStatusLabel(payment.status || "pending")}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {project?.title || "—"} {client ? `• ${client.name}` : ""}
                          </p>
                          {payment.status === "paid" && (
                            <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                              <span>ضريبة: {formatCurrency(vatAmount)}</span>
                              <span>صافي: {formatCurrency(netAfterVat)}</span>
                              {payment.paidDate && <span>التاريخ: {formatDate(payment.paidDate)}</span>}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-left">
                            <p className="font-bold text-primary text-sm">{formatCurrency(payment.amount)}</p>
                            <p className="text-xs text-muted-foreground">{payment.percentage}%</p>
                          </div>
                          {payment.status !== "paid" && (
                            <Button
                              size="sm"
                              onClick={() => markAsPaid(payment)}
                              disabled={updatePayment.isPending}
                              data-testid={`button-mark-paid-${payment.id}`}
                            >
                              تحصيل
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="summary">
          {summary ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Receipt className="h-4 w-4" />
                    الإيرادات وضريبة القيمة المضافة
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">إجمالي الإيرادات</span>
                    <span className="font-bold" data-testid="text-summary-revenue">{formatCurrency(summary.totalRevenue)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <Percent className="h-3 w-3" /> ضريبة القيمة المضافة (15%)
                    </span>
                    <span className="font-bold text-red-600" data-testid="text-summary-vat">- {formatCurrency(summary.totalVat)}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between items-center">
                    <span className="text-sm font-medium">الإيراد بعد الضريبة</span>
                    <span className="font-bold text-emerald-600" data-testid="text-summary-net-revenue">{formatCurrency(summary.revenueAfterVat)}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Landmark className="h-4 w-4" />
                    المصروفات والأرباح
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">الرواتب الأساسية</span>
                    <span className="font-bold" data-testid="text-summary-salaries">- {formatCurrency(summary.totalBaseSalaries)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">العمولات</span>
                    <span className="font-bold" data-testid="text-summary-commissions">- {formatCurrency(summary.totalCommissions)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">التزامات أخرى</span>
                    <span className="font-bold" data-testid="text-summary-commitments">- {formatCurrency(summary.totalManualCommitments)}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between items-center">
                    <span className="text-sm font-medium">صافي الربح</span>
                    <span className={`font-bold text-lg ${summary.netProfit >= 0 ? "text-emerald-600" : "text-red-600"}`} data-testid="text-summary-profit">
                      {formatCurrency(summary.netProfit)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Skeleton className="h-48" />
              <Skeleton className="h-48" />
            </div>
          )}
        </TabsContent>

        <TabsContent value="commitments">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="text-sm">الالتزامات المالية</CardTitle>
                <Button size="sm" onClick={() => setCommitmentDialog(true)} data-testid="button-add-commitment">
                  <Plus className="h-4 w-4 ml-1" />
                  إضافة التزام
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {commitments.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground text-sm">
                  <PiggyBank className="h-10 w-10 mx-auto mb-2 text-muted-foreground/40" />
                  لا توجد التزامات مالية مسجلة
                </div>
              ) : (
                <div className="space-y-2">
                  {commitments.map((c: any) => (
                    <div key={c.id} className="flex items-center justify-between gap-3 p-3 border border-border rounded-md" data-testid={`row-commitment-${c.id}`}>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-medium">{c.title}</p>
                          <Badge className={`text-xs ${c.type === "expense" ? "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300" : "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300"}`}>
                            {c.type === "expense" ? "مصروف" : "التزام"}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {c.month && `الشهر: ${c.month}`} {c.notes && `— ${c.notes}`}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-sm text-primary">{formatCurrency(c.amount)}</span>
                        <Button
                          size="icon"
                          variant="outline"
                          className="h-8 w-8"
                          onClick={() => deleteCommitment.mutate(c.id)}
                          disabled={deleteCommitment.isPending}
                          data-testid={`button-delete-commitment-${c.id}`}
                        >
                          <Trash2 className="h-3.5 w-3.5 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  <div className="flex justify-between items-center p-3 border-t mt-3">
                    <span className="text-sm font-medium">إجمالي الالتزامات</span>
                    <span className="font-bold text-primary">{formatCurrency(commitments.reduce((s: number, c: any) => s + c.amount, 0))}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="charts">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">إيرادات المشاريع</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? <Skeleton className="h-52" /> : (
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={projectRevenue} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis type="number" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                      <YAxis type="category" dataKey="name" tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} width={80} />
                      <Tooltip formatter={(v: any) => formatCurrency(v)} />
                      <Bar dataKey="paid" name="مدفوع" fill="hsl(var(--chart-2))" radius={[0, 4, 4, 0]} />
                      <Bar dataKey="total" name="الإجمالي" fill="hsl(var(--chart-1))" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">توزيع المدفوعات</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? <Skeleton className="h-52" /> : pieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                        {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                      </Pie>
                      <Tooltip formatter={(v: any) => formatCurrency(v)} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-52 text-muted-foreground text-sm">لا توجد بيانات</div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={commitmentDialog} onOpenChange={setCommitmentDialog}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>إضافة التزام مالي</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>العنوان *</Label>
              <Input
                placeholder="مثال: إيجار المكتب"
                value={commitmentForm.title}
                onChange={e => setCommitmentForm(f => ({ ...f, title: e.target.value }))}
                data-testid="input-commitment-title"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>المبلغ (ر.س) *</Label>
                <Input
                  type="number"
                  placeholder="5000"
                  value={commitmentForm.amount}
                  onChange={e => setCommitmentForm(f => ({ ...f, amount: e.target.value }))}
                  data-testid="input-commitment-amount"
                />
              </div>
              <div className="space-y-2">
                <Label>النوع</Label>
                <Select value={commitmentForm.type} onValueChange={v => setCommitmentForm(f => ({ ...f, type: v }))}>
                  <SelectTrigger data-testid="select-commitment-type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expense">مصروف</SelectItem>
                    <SelectItem value="obligation">التزام</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>الشهر</Label>
              <Input
                type="month"
                value={commitmentForm.month}
                onChange={e => setCommitmentForm(f => ({ ...f, month: e.target.value }))}
                data-testid="input-commitment-month"
              />
            </div>
            <div className="space-y-2">
              <Label>ملاحظات</Label>
              <Textarea
                placeholder="ملاحظات إضافية..."
                value={commitmentForm.notes}
                onChange={e => setCommitmentForm(f => ({ ...f, notes: e.target.value }))}
                data-testid="input-commitment-notes"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCommitmentDialog(false)}>إلغاء</Button>
            <Button
              onClick={() => {
                if (!commitmentForm.title || !commitmentForm.amount) {
                  toast({ title: "يرجى تعبئة الحقول المطلوبة", variant: "destructive" });
                  return;
                }
                createCommitment.mutate({
                  title: commitmentForm.title,
                  amount: parseFloat(commitmentForm.amount),
                  type: commitmentForm.type,
                  month: commitmentForm.month || null,
                  notes: commitmentForm.notes || null,
                  projectId: null,
                });
              }}
              disabled={createCommitment.isPending}
              data-testid="button-save-commitment"
            >
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
