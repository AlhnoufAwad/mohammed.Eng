import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Users, UserCheck, Trash2, Plus, Edit2, Key, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Employee } from "@shared/schema";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";

const roleLabels: Record<string, string> = {
  admin: "مدير (أدمن)",
  employee: "موظف رسمي",
  freelancer: "فري لانسر",
};
const roleColors: Record<string, string> = {
  admin: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  employee: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  freelancer: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
};

type SafeUser = {
  id: string;
  username: string;
  name: string;
  role: string;
  email: string | null;
  employeeId: string | null;
  createdAt: string | null;
};

const EMPTY_NEW_USER = { username: "", password: "", name: "", role: "employee", email: "", employeeId: "" };

export default function UserManagement() {
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const { data: users = [], isLoading } = useQuery<SafeUser[]>({ queryKey: ["/api/users"] });
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });

  const [addDialog, setAddDialog] = useState(false);
  const [editUser, setEditUser] = useState<SafeUser | null>(null);
  const [newUser, setNewUser] = useState(EMPTY_NEW_USER);
  const [editData, setEditData] = useState<Partial<SafeUser & { password: string }>>({});
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/users", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setAddDialog(false);
      setNewUser(EMPTY_NEW_USER);
      toast({ title: "تم إنشاء المستخدم بنجاح" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PUT", `/api/users/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setEditUser(null);
      toast({ title: "تم تحديث البيانات" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/users/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setDeleteConfirm(null);
      toast({ title: "تم حذف المستخدم" });
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const openEdit = (u: SafeUser) => {
    setEditUser(u);
    setEditData({ role: u.role, name: u.name, email: u.email || "", employeeId: u.employeeId || "", password: "" });
  };

  const adminCount = users.filter(u => u.role === "admin").length;

  if (isLoading) return (
    <div className="p-6 space-y-3">
      {[1, 2, 3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
    </div>
  );

  return (
    <div className="p-4 md:p-6 space-y-4 overflow-y-auto h-full" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2"><Users className="h-5 w-5" />إدارة المستخدمين</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{users.length} مستخدم — {adminCount} أدمن</p>
        </div>
        <Button onClick={() => { setAddDialog(true); setNewUser(EMPTY_NEW_USER); }} data-testid="button-add-user">
          <Plus className="h-4 w-4 ml-1" />إضافة مستخدم
        </Button>
      </div>

      <div className="grid gap-3">
        {users.map(u => {
          const emp = employees.find(e => e.id === u.employeeId);
          const isMe = u.id === currentUser?.id;
          return (
            <Card key={u.id} className={`${isMe ? "ring-2 ring-primary" : ""}`} data-testid={`card-user-${u.id}`}>
              <CardContent className="py-3 px-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <UserCheck className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold text-base">{u.name}</p>
                        {isMe && <Badge variant="outline" className="text-[10px]">أنت</Badge>}
                      </div>
                      <p className="text-sm text-muted-foreground">@{u.username}</p>
                      {u.email && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <Mail className="h-3 w-3" />{u.email}
                        </p>
                      )}
                      {emp && (
                        <p className="text-xs text-blue-600 mt-0.5">مرتبط بـ: {emp.name} — {(emp as any).jobTitle || ""}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Badge className={`text-[11px] ${roleColors[u.role] || ""}`}>{roleLabels[u.role] || u.role}</Badge>
                    <Button variant="ghost" size="sm" onClick={() => openEdit(u)} data-testid={`button-edit-user-${u.id}`}>
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    {!isMe && (
                      <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700" onClick={() => setDeleteConfirm(u.id)} data-testid={`button-delete-user-${u.id}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Add Dialog */}
      <Dialog open={addDialog} onOpenChange={setAddDialog}>
        <DialogContent dir="rtl" aria-describedby="add-user-desc">
          <DialogHeader>
            <DialogTitle>إضافة مستخدم جديد</DialogTitle>
          </DialogHeader>
          <p id="add-user-desc" className="sr-only">إضافة مستخدم جديد</p>
          <div className="space-y-3">
            <div>
              <Label>الاسم الكامل</Label>
              <Input value={newUser.name} onChange={e => setNewUser({ ...newUser, name: e.target.value })} placeholder="محمد البلوي" data-testid="input-new-user-name" />
            </div>
            <div>
              <Label>اسم المستخدم</Label>
              <Input value={newUser.username} onChange={e => setNewUser({ ...newUser, username: e.target.value })} placeholder="username" dir="ltr" data-testid="input-new-user-username" />
            </div>
            <div>
              <Label>كلمة المرور</Label>
              <Input type="password" value={newUser.password} onChange={e => setNewUser({ ...newUser, password: e.target.value })} placeholder="••••••••" data-testid="input-new-user-password" />
            </div>
            <div>
              <Label>البريد الإلكتروني (اختياري)</Label>
              <Input type="email" value={newUser.email} onChange={e => setNewUser({ ...newUser, email: e.target.value })} placeholder="email@example.com" dir="ltr" data-testid="input-new-user-email" />
            </div>
            <div>
              <Label>الصلاحية</Label>
              <Select value={newUser.role} onValueChange={v => setNewUser({ ...newUser, role: v })}>
                <SelectTrigger data-testid="select-new-user-role"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">مدير (أدمن)</SelectItem>
                  <SelectItem value="employee">موظف رسمي</SelectItem>
                  <SelectItem value="freelancer">فري لانسر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>ربط بموظف (اختياري)</Label>
              <Select value={newUser.employeeId || "none"} onValueChange={v => setNewUser({ ...newUser, employeeId: v === "none" ? "" : v })}>
                <SelectTrigger data-testid="select-new-user-employee"><SelectValue placeholder="اختر موظفاً..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون ربط</SelectItem>
                  {employees.map(e => (
                    <SelectItem key={e.id} value={e.id}>{e.name} — {(e as any).jobTitle || ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => createMutation.mutate({ ...newUser, employeeId: newUser.employeeId || null })} disabled={createMutation.isPending || !newUser.username || !newUser.password || !newUser.name} data-testid="button-submit-add-user">
              إنشاء المستخدم
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editUser} onOpenChange={() => setEditUser(null)}>
        <DialogContent dir="rtl" aria-describedby="edit-user-desc">
          <DialogHeader>
            <DialogTitle>تعديل: {editUser?.name}</DialogTitle>
          </DialogHeader>
          <p id="edit-user-desc" className="sr-only">تعديل بيانات المستخدم</p>
          <div className="space-y-3">
            <div>
              <Label>الاسم الكامل</Label>
              <Input value={editData.name || ""} onChange={e => setEditData({ ...editData, name: e.target.value })} data-testid="input-edit-user-name" />
            </div>
            <div>
              <Label>البريد الإلكتروني</Label>
              <Input type="email" value={editData.email || ""} onChange={e => setEditData({ ...editData, email: e.target.value })} dir="ltr" data-testid="input-edit-user-email" />
            </div>
            <div>
              <Label>الصلاحية</Label>
              <Select value={editData.role || "employee"} onValueChange={v => setEditData({ ...editData, role: v })}>
                <SelectTrigger data-testid="select-edit-user-role"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">مدير (أدمن)</SelectItem>
                  <SelectItem value="employee">موظف رسمي</SelectItem>
                  <SelectItem value="freelancer">فري لانسر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>ربط بموظف</Label>
              <Select value={editData.employeeId || "none"} onValueChange={v => setEditData({ ...editData, employeeId: v === "none" ? "" : v })}>
                <SelectTrigger data-testid="select-edit-user-employee"><SelectValue placeholder="اختر موظفاً..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون ربط</SelectItem>
                  {employees.map(e => (
                    <SelectItem key={e.id} value={e.id}>{e.name} — {(e as any).jobTitle || ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="flex items-center gap-1"><Key className="h-3.5 w-3.5" />كلمة مرور جديدة (اتركها فارغة للإبقاء)</Label>
              <Input type="password" value={editData.password || ""} onChange={e => setEditData({ ...editData, password: e.target.value })} placeholder="••••••••" data-testid="input-edit-user-password" />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => updateMutation.mutate({ id: editUser!.id, data: editData })} disabled={updateMutation.isPending} data-testid="button-submit-edit-user">
              حفظ التعديلات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent dir="rtl" aria-describedby="delete-user-desc">
          <DialogHeader><DialogTitle>تأكيد الحذف</DialogTitle></DialogHeader>
          <p id="delete-user-desc">هل أنت متأكد من حذف هذا المستخدم؟ لا يمكن التراجع.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirm(null)}>إلغاء</Button>
            <Button variant="destructive" onClick={() => deleteMutation.mutate(deleteConfirm!)} disabled={deleteMutation.isPending} data-testid="button-confirm-delete-user">
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
