import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { DollarSign, Users, TrendingUp, Building2, Percent, Download, FileText, Plus, Trash2, MinusCircle, Star, Edit2, PlusCircle, CheckCircle, Clock, Upload } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";

interface Partner {
  id: string;
  name: string;
  profitPercentage: number;
  isActive: boolean;
  notes?: string | null;
}

interface MonthlyFinancialReport {
  month: string;
  totalRevenue: number;
  vatAmount: number;
  revenueAfterVat: number;
  monthProjects: Array<{
    id: string; title: string; clientName: string; type: string;
    totalValue: number; monthRevenue: number; netAfterVat: number; vatAmount: number;
    payments: Array<{ paymentNumber: number; amount: number; percentage: number; paidDate: string }>;
    employeeCommissions: Array<{ name: string; percentage: number; amount: number }>;
    area: number; pricePerSqm: number;
  }>;
  expenses: {
    baseSalaries: number;
    baseSalariesBreakdown: Array<{ name: string; jobTitle: string; baseSalary: number; bonuses: number; deductions: number; net: number }>;
    commissions: number;
    freelancerCosts: number;
    freelancerCostsBreakdown?: Array<{ name: string; projectTitle: string; role: string; amount: number }>;
    commitments: number;
    commitmentDetails: Array<{ name: string; amount: number; dueDate?: string }>;
    total: number;
  };
  netProfit: number;
  partnersSummary: Array<{ id: string; name: string; percentage: number; shareAmount: number; isMohammed: boolean }>;
}

interface Commission {
  projectId: string;
  projectTitle: string;
  clientName: string;
  designType: string;
  contractArea: number;
  pricePerSqm: number;
  totalExecutedArea: number;
  totalContractValue: number;
  designExpense: number;
  designCommission: number;
  executiveCommission: number;
  structuralCommission: number;
  percentage: number;
  amount: number;
  role: string;
  paymentLabel: string;
  isPaid?: boolean;
  paidDate?: string | null;
  assignedAmount?: number;
}

interface ManualDeduction {
  id: string;
  amount: number;
  reason: string;
}

interface ManualBonus {
  id: string;
  amount: number;
  reason: string;
}

interface EmployeeSalary {
  employeeId: string;
  employeeName: string;
  employeeType: string;
  jobTitle: string;
  baseSalary: number;
  designPercentage: number;
  executivePercentage: number;
  structuralPercentage: number;
  commissions: Commission[];
  totalCommission: number;
  absenceCount: number;
  absenceDeduction: number;
  manualDeductions: ManualDeduction[];
  totalManualDeductions: number;
  manualBonuses: ManualBonus[];
  totalManualBonuses: number;
  totalDeductions: number;
  totalSalary: number;
  bankAccount: string | null;
}

interface SalaryResponse {
  month: string;
  salaries: EmployeeSalary[];
  totalPayroll: number;
}

const monthNames = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];

function getMonthOptions() {
  const options: { value: string; label: string }[] = [];
  const now = new Date();
  for (let i = 0; i < 12; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const label = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
    options.push({ value, label });
  }
  return options;
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function fmtNum(n: number): string {
  return Math.round(n).toLocaleString("ar-SA");
}

function exportEmployeePDF(emp: EmployeeSalary, selectedLabel: string) {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;

  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const isFreelancer = emp.employeeType === "freelancer";

  const commRows = emp.commissions.map((c, idx) => {
    const designCol = emp.designPercentage > 0 ? `<td>${fmtNum(c.designCommission)}</td>` : "";
    const execCol = emp.executivePercentage > 0 ? `<td>${fmtNum(c.executiveCommission)}</td>` : "";
    const structCol = emp.structuralPercentage > 0 ? `<td>${fmtNum(c.structuralCommission)}</td>` : "";
    return `<tr>
      <td>${idx + 1}</td>
      <td>${escapeHtml(c.clientName)}</td>
      <td>${escapeHtml(c.designType)}</td>
      <td>${c.contractArea > 0 ? fmtNum(c.contractArea) : "—"}</td>
      <td>${c.pricePerSqm > 0 ? fmtNum(c.pricePerSqm) : "—"}</td>
      <td>${c.totalExecutedArea > 0 ? fmtNum(c.totalExecutedArea) : "—"}</td>
      <td>${fmtNum(c.totalContractValue)}</td>
      <td>${fmtNum(c.designExpense)}</td>
      ${structCol}${execCol}${designCol}
      <td style="font-weight:600">${fmtNum(c.amount)}</td>
    </tr>`;
  }).join("");

  const designTh = emp.designPercentage > 0 ? `<th>تصميم ${emp.designPercentage}%</th>` : "";
  const execTh = emp.executivePercentage > 0 ? `<th>مخطط ${emp.executivePercentage}%</th>` : "";
  const structTh = emp.structuralPercentage > 0 ? `<th>هيكل ${emp.structuralPercentage}%</th>` : "";
  const colCount = 8 + (emp.designPercentage > 0 ? 1 : 0) + (emp.executivePercentage > 0 ? 1 : 0) + (emp.structuralPercentage > 0 ? 1 : 0) + 1;

  const totalCommission = emp.totalCommission;

  const deductionRows = [];
  if (emp.absenceDeduction > 0) {
    deductionRows.push(`<tr><td>غياب (${emp.absenceCount} يوم)</td><td style="color:red">- ${fmtNum(emp.absenceDeduction)} ر.س</td></tr>`);
  }
  emp.manualDeductions.forEach(d => {
    deductionRows.push(`<tr><td>${escapeHtml(d.reason)}</td><td style="color:red">- ${fmtNum(d.amount)} ر.س</td></tr>`);
  });
  const bonusRows = (emp.manualBonuses || []).map(b =>
    `<tr><td>${escapeHtml(b.reason)}</td><td style="color:#16a34a">+ ${fmtNum(b.amount)} ر.س</td></tr>`
  );

  printWindow.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<title>مستحقات ${escapeHtml(emp.employeeName)} - ${selectedLabel}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap');
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'IBM Plex Sans Arabic', sans-serif; background: #fff; color: #1a1a1a; font-size: 12px; }
.page { max-width: 1100px; margin: 0 auto; padding: 30px; }
@media print { .page { padding: 15px; } .no-print { display: none !important; } @page { size: landscape; margin: 10mm; } }
.header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; padding-bottom: 12px; border-bottom: 3px solid #2563EB; }
.company-info h1 { font-size: 18px; font-weight: 700; color: #2563EB; }
.company-info p { font-size: 10px; color: #666; }
.emp-info { text-align: left; }
.emp-info .name { font-size: 14px; font-weight: 700; }
.emp-info .date { font-size: 11px; color: #666; margin-top: 4px; }
.phone { font-size: 11px; color: #888; }
table { width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 15px; }
th { background: #2563EB; color: #fff; padding: 7px 8px; text-align: right; font-weight: 600; font-size: 10px; white-space: nowrap; }
td { padding: 6px 8px; border-bottom: 1px solid #eee; vertical-align: middle; text-align: right; }
tr:nth-child(even) { background: #f8fafc; }
.total-row { background: #2563EB !important; color: #fff; font-weight: 700; }
.total-row td { border: none; font-size: 12px; }
.summary-table { width: 450px; margin: 0 auto 20px; }
.summary-table td { padding: 8px 12px; font-size: 13px; }
.summary-table .label { font-weight: 600; background: #f1f5f9; }
.summary-table .value { text-align: left; font-weight: 700; }
.summary-table .total-final { background: #2563EB; color: #fff; }
.deductions-table { width: 450px; margin: 0 auto 15px; border: 1px solid #fee; }
.deductions-table td { padding: 6px 12px; font-size: 12px; }
.stamp-area { display: flex; gap: 40px; margin-top: 40px; }
.stamp-box { flex: 1; text-align: center; }
.stamp-box .title { font-size: 11px; color: #666; margin-bottom: 5px; }
.stamp-box .line { border-top: 1px solid #000; margin-top: 50px; padding-top: 5px; font-size: 11px; }
.footer { font-size: 9px; color: #999; text-align: center; margin-top: 20px; padding-top: 10px; border-top: 1px solid #eee; }
.btn-print { background: #2563EB; color: #fff; border: none; padding: 12px 30px; font-size: 14px; cursor: pointer; font-family: inherit; margin: 20px auto; display: block; border-radius: 6px; }
.btn-print:hover { background: #1D4ED8; }
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="company-info">
      <h1>مجموعة محمد البلوي للتصميم</h1>
      <p>لتصميم الديكور الداخلي والخارجي</p>
      <p class="phone">597999870</p>
    </div>
    <div class="emp-info">
      <div class="name">اسم الموظف : ${escapeHtml(emp.employeeName)}</div>
      <div class="date">التاريخ: ${selectedLabel}</div>
    </div>
  </div>

  ${emp.commissions.length > 0 ? `
  <table>
    <thead>
      <tr>
        <th>م</th>
        <th>اسم العميل</th>
        <th>نوع التصميم</th>
        <th>امتار العقد</th>
        <th>سعر المتر</th>
        <th>اجمالي الأمتار المنفذ</th>
        <th>إجمالي قيمة العقد</th>
        <th>مصروفات التصميم</th>
        ${structTh}${execTh}${designTh}
        <th>ملاحظات</th>
      </tr>
    </thead>
    <tbody>
      ${commRows}
      <tr class="total-row">
        <td colspan="${colCount - 1}">إجمالي ${fmtNum(totalCommission)} ريال</td>
        <td></td>
      </tr>
    </tbody>
  </table>
  ` : ""}

  <table class="summary-table">
    <tr>
      <td class="value">${fmtNum(1)}</td>
      <td class="label">اسم الموظف</td>
      <td class="value">${escapeHtml(emp.employeeName)}</td>
    </tr>
    ${!isFreelancer ? `
    <tr>
      <td class="value">${fmtNum(2)}</td>
      <td class="label">الراتب الأساسي</td>
      <td class="value">ر.س. ${fmtNum(emp.baseSalary)}</td>
    </tr>` : ""}
    <tr>
      <td class="value">${isFreelancer ? fmtNum(2) : fmtNum(3)}</td>
      <td class="label">عمولات الشهر</td>
      <td class="value">ر.س. ${fmtNum(totalCommission)}</td>
    </tr>
    ${!isFreelancer ? `
    ${(emp.totalManualBonuses || 0) > 0 ? `<tr>
      <td class="value">${fmtNum(4)}</td>
      <td class="label">الزيادات</td>
      <td class="value" style="color:#16a34a">+ ر.س. ${fmtNum(emp.totalManualBonuses)}</td>
    </tr>` : ""}
    <tr>
      <td class="value">${fmtNum(5)}</td>
      <td class="label">الخصومات</td>
      <td class="value" style="color:red">ر.س. ${fmtNum(emp.totalDeductions)}</td>
    </tr>
    <tr class="total-final" style="background:#2563EB;color:#fff">
      <td class="value">${fmtNum(6)}</td>
      <td class="label" style="background:#2563EB;color:#fff">الإجمالي</td>
      <td class="value">ر.س. ${fmtNum(emp.totalSalary)}</td>
    </tr>` : ""}
  </table>

  ${bonusRows.length > 0 ? `
  <p style="font-size:12px;font-weight:600;margin-bottom:6px;text-align:center">تفاصيل الزيادات</p>
  <table class="deductions-table">
    ${bonusRows.join("")}
  </table>` : ""}
  ${deductionRows.length > 0 ? `
  <p style="font-size:12px;font-weight:600;margin-bottom:6px;text-align:center">تفاصيل الخصومات</p>
  <table class="deductions-table">
    ${deductionRows.join("")}
  </table>` : ""}

  <div class="stamp-area">
    <div class="stamp-box">
      <div class="title">يـعتمــد ,,,,</div>
      <img src="${window.location.origin}/signature.png" style="height:50px;object-fit:contain;margin:6px auto 2px;display:block;" alt="توقيع" onerror="this.style.display='none'" />
      <div class="line">م/ محمد البلوي</div>
    </div>
    <div class="stamp-box">
      <div class="line">المستلم</div>
    </div>
    <div class="stamp-box">
      <div class="line">الحسابات</div>
    </div>
  </div>

  <div class="footer">مجموعة محمد البلوي للتصميم الداخلي والخارجي — تم الطباعة بتاريخ ${today}</div>
  <button class="btn-print no-print" onclick="window.print()">طباعة / تصدير PDF</button>
</div>
</body>
</html>`);
  printWindow.document.close();
}

function exportSalaryPDF(salaries: EmployeeSalary[], selectedLabel: string, totalPayroll: number, totalBaseSalaries: number, totalCommissions: number, totalDeductions: number, totalBonuses: number) {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;

  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });

  const rows = salaries.map((emp, idx) => {
    const commDetail = emp.commissions.filter(c => c.amount > 0).length > 0
      ? emp.commissions.filter(c => c.amount > 0).map(c => `${escapeHtml(c.clientName)} — ${escapeHtml(c.designType)} — ${c.percentage}% = ${fmtNum(c.amount)} ر.س`).join("<br>")
      : "—";
    return `<tr>
      <td>${idx + 1}</td>
      <td><strong>${escapeHtml(emp.employeeName)}</strong><br><span style="font-size:10px;color:#888">${escapeHtml(emp.jobTitle)} • ${emp.employeeType === "internal" ? "موظف" : "فريلانسر"}</span></td>
      <td>${fmtNum(emp.baseSalary)} ر.س</td>
      <td style="font-size:11px">${commDetail}</td>
      <td>${fmtNum(emp.totalCommission)} ر.س</td>
      <td style="color:#16a34a">${fmtNum(emp.totalManualBonuses || 0)} ر.س</td>
      <td style="color:red">${fmtNum(emp.totalDeductions)} ر.س</td>
      <td style="font-weight:700;font-size:14px">${fmtNum(emp.totalSalary)} ر.س</td>
      <td style="font-size:10px;color:#888">${escapeHtml(emp.bankAccount || "—")}</td>
    </tr>`;
  }).join("");

  printWindow.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<title>كشف رواتب - ${selectedLabel}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap');
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'IBM Plex Sans Arabic', sans-serif; background: #fff; color: #1a1a1a; }
.page { max-width: 1100px; margin: 0 auto; padding: 30px; }
@media print { .page { padding: 15px; } .no-print { display: none !important; } @page { size: landscape; margin: 10mm; } }
.header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 3px solid #2563EB; }
.company-info h1 { font-size: 18px; font-weight: 700; color: #2563EB; }
.company-info p { font-size: 10px; color: #666; }
.badge { background: #2563EB; color: #fff; padding: 8px 20px; font-size: 16px; font-weight: 700; border-radius: 6px; }
.summary { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 20px; }
.summary-card { border: 2px solid #2563EB; padding: 12px; text-align: center; border-radius: 8px; }
.summary-card .val { font-size: 18px; font-weight: 700; color: #2563EB; }
.summary-card .lbl { font-size: 10px; color: #666; margin-top: 2px; }
table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 20px; }
th { background: #2563EB; color: #fff; padding: 8px 10px; text-align: right; font-weight: 600; font-size: 11px; }
td { padding: 8px 10px; border-bottom: 1px solid #eee; vertical-align: top; }
tr:nth-child(even) { background: #f8fafc; }
.total-row { background: #2563EB !important; color: #fff; font-weight: 700; }
.total-row td { border: none; font-size: 13px; }
.footer { display: flex; justify-content: space-between; font-size: 10px; color: #666; padding-top: 15px; border-top: 2px solid #2563EB; margin-top: 15px; }
.stamp-area { display: flex; gap: 40px; margin-top: 30px; }
.stamp-box { flex: 1; text-align: center; }
.stamp-box .line { border-top: 1px solid #000; margin-top: 50px; padding-top: 5px; font-size: 11px; }
.vat-note { font-size: 10px; color: #888; margin-bottom: 10px; background: #f9f9f9; padding: 6px 10px; border-right: 3px solid #2563EB; }
.btn-print { background: #2563EB; color: #fff; border: none; padding: 12px 30px; font-size: 14px; cursor: pointer; font-family: inherit; margin: 20px auto; display: block; border-radius: 6px; }
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="company-info">
      <h1>مجموعة محمد البلوي للتصميم</h1>
      <p>لتصميم الديكور الداخلي والخارجي</p>
      <p>597999870</p>
    </div>
    <div>
      <div class="badge">كشف الرواتب</div>
      <p style="text-align:left;font-size:11px;margin-top:4px;color:#888">${selectedLabel}</p>
    </div>
  </div>

  <div class="summary">
    <div class="summary-card">
      <div class="val">${fmtNum(totalPayroll)} ر.س</div>
      <div class="lbl">صافي الرواتب</div>
    </div>
    <div class="summary-card">
      <div class="val">${fmtNum(totalBaseSalaries)} ر.س</div>
      <div class="lbl">الرواتب الأساسية</div>
    </div>
    <div class="summary-card">
      <div class="val">${fmtNum(totalCommissions)} ر.س</div>
      <div class="lbl">العمولات</div>
    </div>
    <div class="summary-card">
      <div class="val" style="color:#16a34a">${fmtNum(totalBonuses)} ر.س</div>
      <div class="lbl">الزيادات</div>
    </div>
    <div class="summary-card">
      <div class="val" style="color:red">${fmtNum(totalDeductions)} ر.س</div>
      <div class="lbl">الخصومات</div>
    </div>
    <div class="summary-card">
      <div class="val">${salaries.length}</div>
      <div class="lbl">عدد الموظفين</div>
    </div>
  </div>

  <div class="vat-note">ملاحظة: العمولات محسوبة بعد خصم ضريبة القيمة المضافة 15% من كل دفعة (صافي بعد الضريبة × نسبة الموظف)</div>

  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>الموظف</th>
        <th>الراتب الأساسي</th>
        <th>تفاصيل العمولات</th>
        <th>إجمالي العمولات</th>
        <th>الزيادات</th>
        <th>الخصومات</th>
        <th>الإجمالي</th>
        <th>الحساب البنكي</th>
      </tr>
    </thead>
    <tbody>
      ${rows}
      <tr class="total-row">
        <td colspan="2">الإجمالي</td>
        <td>${fmtNum(totalBaseSalaries)} ر.س</td>
        <td></td>
        <td>${fmtNum(totalCommissions)} ر.س</td>
        <td>${fmtNum(totalBonuses)} ر.س</td>
        <td>${fmtNum(totalDeductions)} ر.س</td>
        <td>${fmtNum(totalPayroll)} ر.س</td>
        <td></td>
      </tr>
    </tbody>
  </table>

  <div class="stamp-area">
    <div class="stamp-box">
      <div class="line">المدير العام</div>
      <img src="${window.location.origin}/signature.png" style="height:45px;object-fit:contain;margin:4px auto 2px;display:block;" alt="توقيع" onerror="this.style.display='none'" />
      <div style="font-size:10px;color:#555;text-align:center;">م/ محمد البلوي</div>
    </div>
    <div class="stamp-box"><div class="line">المدير المالي</div></div>
    <div class="stamp-box"><div class="line">المحاسب</div></div>
  </div>

  <div class="footer">
    <span>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</span>
    <span>تم الطباعة بتاريخ ${today}</span>
  </div>

  <button class="btn-print no-print" onclick="window.print()">طباعة / تصدير PDF</button>
</div>
</body>
</html>`);
  printWindow.document.close();
}

function exportFreelancersBulkPDF(salaries: EmployeeSalary[], selectedLabel: string) {
  const freelancers = salaries.filter(e => e.employeeType === "freelancer" && (e.totalCommission > 0 || e.commissions.length > 0));
  if (!freelancers.length) return;
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;
  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const rows = freelancers.map((emp, idx) => {
    const commDetail = emp.commissions.map(c => `${escapeHtml(c.clientName)} — ${c.percentage}% = ${fmtNum(c.amount)} ر.س`).join("<br>");
    return `<tr>
      <td>${idx + 1}</td>
      <td><strong>${escapeHtml(emp.employeeName)}</strong><br><span style="font-size:10px;color:#888">${escapeHtml(emp.jobTitle)}</span></td>
      <td style="font-size:11px">${commDetail || "—"}</td>
      <td style="font-weight:700;font-size:14px;color:#16a34a">${fmtNum(emp.totalCommission)} ر.س</td>
    </tr>`;
  }).join("");
  const totalComm = freelancers.reduce((s, e) => s + e.totalCommission, 0);
  printWindow.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">
<title>كشف رواتب الفريلانسرز - ${selectedLabel}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'IBM Plex Sans Arabic',sans-serif;background:#fff;color:#111;padding:32px;direction:rtl;}
.header{text-align:center;margin-bottom:24px;border-bottom:3px solid #2563EB;padding-bottom:16px;}
.header h1{font-size:22px;font-weight:700;color:#1e3a8a;}
.header h2{font-size:16px;color:#2563EB;margin-top:4px;}
table{width:100%;border-collapse:collapse;font-size:12px;margin-top:16px;}
th{background:#2563EB;color:#fff;padding:8px 10px;font-weight:600;}
td{padding:7px 10px;border-bottom:1px solid #e5e7eb;}
tr:nth-child(even){background:#f8faff;}
.total-row{background:#dbeafe !important;font-weight:700;font-size:14px;}
.footer{text-align:center;margin-top:24px;font-size:11px;color:#6b7280;border-top:1px solid #e5e7eb;padding-top:12px;}
.btn-print{display:block;margin:16px auto;padding:10px 28px;background:#2563EB;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;}
@media print{.btn-print{display:none;}}
</style></head><body>
<div class="header">
  <h1>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</h1>
  <h2>كشف رواتب الفريلانسرز — ${selectedLabel}</h2>
</div>
<table><thead><tr><th>#</th><th>الاسم</th><th>تفاصيل العمولات</th><th>الإجمالي</th></tr></thead>
<tbody>${rows}
<tr class="total-row"><td colspan="3">إجمالي الفريلانسرز (${freelancers.length} موظف)</td><td>${fmtNum(totalComm)} ر.س</td></tr>
</tbody></table>
<div style="display:flex;justify-content:flex-end;margin-top:20px;gap:20px;align-items:flex-end;">
  <div style="text-align:center;">
    <img src="${window.location.origin}/signature.png" style="height:50px;object-fit:contain;display:block;margin:0 auto;" alt="توقيع" onerror="this.style.display='none'" />
    <div style="font-size:11px;border-top:1px solid #333;padding-top:4px;margin-top:2px;">م/ محمد البلوي</div>
  </div>
</div>
<div class="footer">تم الطباعة بتاريخ ${today}</div>
<button class="btn-print" onclick="window.print()">طباعة / تصدير PDF</button>
</body></html>`);
  printWindow.document.close();
}

function exportMonthlyPartnersPDF(data: MonthlyFinancialReport, label: string) {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;
  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });

  const projectRows = data.monthProjects.map((p, idx) => `<tr>
    <td>${idx + 1}</td>
    <td>${escapeHtml(p.clientName || p.title)}</td>
    <td>${p.type === "interior" ? "داخلي" : p.type === "exterior" ? "خارجي" : "واجهات"}</td>
    <td>${fmtNum(p.monthRevenue)}</td>
    <td>${fmtNum(p.vatAmount)}</td>
    <td>${fmtNum(p.netAfterVat)}</td>
    <td style="font-size:10px">${p.employeeCommissions.map(e => `${escapeHtml(e.name)} ${e.percentage}%`).join("<br>")}</td>
    <td>${fmtNum(p.employeeCommissions.reduce((s, e) => s + e.amount, 0))}</td>
  </tr>`).join("");

  const salaryRows = data.expenses.baseSalariesBreakdown.map((e, idx) => `<tr>
    <td>${idx + 1}</td>
    <td>${escapeHtml(e.name)}</td>
    <td>${escapeHtml(e.jobTitle)}</td>
    <td>${fmtNum(e.baseSalary)}</td>
    <td style="color:#16a34a">${e.bonuses > 0 ? fmtNum(e.bonuses) : "—"}</td>
    <td style="color:red">${e.deductions > 0 ? fmtNum(e.deductions) : "—"}</td>
    <td style="font-weight:700">${fmtNum(e.net)}</td>
  </tr>`).join("");

  const partnerRows = data.partnersSummary.map((p, idx) => `<tr>
    <td>${idx + 1}</td>
    <td><strong>${escapeHtml(p.name)}</strong>${p.isMohammed ? ' <span style="color:#2563EB">(الباقي)</span>' : ""}</td>
    <td>${p.percentage.toFixed(1)}%</td>
    <td style="font-weight:700;color:#16a34a">${fmtNum(p.shareAmount)} ر.س</td>
  </tr>`).join("");

  const freelancerRows = (data.expenses.freelancerCostsBreakdown || []).map((f, idx) => `<tr>
    <td>${idx + 1}</td>
    <td>${escapeHtml(f.name)}</td>
    <td>${escapeHtml(f.projectTitle)}</td>
    <td>${escapeHtml(f.role)}</td>
    <td style="color:red;font-weight:700">${fmtNum(f.amount)} ر.س</td>
  </tr>`).join("");

  const commitmentRows = (data.expenses.commitmentDetails || []).map((c: any, idx: number) => `<tr>
    <td>${idx + 1}</td>
    <td>${escapeHtml((c as any).name || "—")}</td>
    <td style="color:red">${fmtNum(c.amount)} ر.س</td>
  </tr>`).join("");

  printWindow.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">
<title>تقرير صافي الربح - ${label}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'IBM Plex Sans Arabic',sans-serif;background:#fff;color:#111;padding:24px;direction:rtl;}
.header{text-align:center;margin-bottom:20px;border-bottom:3px solid #2563EB;padding-bottom:12px;}
.header h1{font-size:20px;font-weight:700;color:#1e3a8a;}
.header h2{font-size:14px;color:#2563EB;margin-top:4px;}
.section-title{font-size:14px;font-weight:700;background:#2563EB;color:#fff;padding:6px 12px;margin:16px 0 8px;border-radius:4px;}
.summary-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:12px 0;}
.summary-box{border:1px solid #ddd;padding:10px;text-align:center;border-radius:6px;}
.summary-box .val{font-size:16px;font-weight:700;}
.summary-box .lbl{font-size:10px;color:#666;}
table{width:100%;border-collapse:collapse;font-size:11px;margin-bottom:12px;}
th{background:#1e3a8a;color:#fff;padding:6px 8px;text-align:right;font-weight:600;}
td{padding:5px 8px;border-bottom:1px solid #eee;vertical-align:middle;}
tr:nth-child(even){background:#f8fafc;}
.total-row{background:#dbeafe!important;font-weight:700;}
.footer{text-align:center;margin-top:16px;font-size:10px;color:#6b7280;border-top:1px solid #ddd;padding-top:10px;}
.btn-print{display:block;margin:12px auto;padding:10px 28px;background:#2563EB;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;}
@media print{.btn-print{display:none;}}
</style></head><body>
<div class="header">
  <h1>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</h1>
  <h2>تقرير صافي الربح الشهري — ${label}</h2>
</div>
<div class="summary-grid">
  <div class="summary-box"><div class="val">${fmtNum(data.totalRevenue)} ر.س</div><div class="lbl">إجمالي الإيرادات</div></div>
  <div class="summary-box"><div class="val">${fmtNum(data.vatAmount)} ر.س</div><div class="lbl">ضريبة القيمة المضافة</div></div>
  <div class="summary-box"><div class="val" style="color:red">${fmtNum(data.expenses.total)} ر.س</div><div class="lbl">إجمالي المصروفات</div></div>
  <div class="summary-box"><div class="val" style="color:#16a34a">${fmtNum(data.netProfit)} ر.س</div><div class="lbl">صافي الربح</div></div>
</div>
${data.monthProjects.length > 0 ? `
<div class="section-title">المشاريع والإيرادات</div>
<table><thead><tr><th>#</th><th>العميل</th><th>النوع</th><th>الإيراد</th><th>الضريبة</th><th>صافي</th><th>نسب الموظفين</th><th>عمولات الموظفين</th></tr></thead>
<tbody>${projectRows}
<tr class="total-row"><td colspan="3">الإجمالي</td><td>${fmtNum(data.totalRevenue)}</td><td>${fmtNum(data.vatAmount)}</td><td>${fmtNum(data.revenueAfterVat)}</td><td></td><td>${fmtNum(data.expenses.commissions)}</td></tr>
</tbody></table>` : ""}
<div class="section-title">كشف الرواتب الأساسية</div>
<table><thead><tr><th>#</th><th>الموظف</th><th>المسمى الوظيفي</th><th>الراتب الأساسي</th><th>زيادة</th><th>خصم</th><th>صافي</th></tr></thead>
<tbody>${salaryRows}
<tr class="total-row"><td colspan="3">الإجمالي</td><td>${fmtNum(data.expenses.baseSalariesBreakdown.reduce((s, e) => s + e.baseSalary, 0))}</td><td></td><td></td><td>${fmtNum(data.expenses.baseSalaries)}</td></tr>
</tbody></table>
${data.expenses.freelancerCostsBreakdown && data.expenses.freelancerCostsBreakdown.length > 0 ? `
<div class="section-title">مستحقات الفريلانسر</div>
<table><thead><tr><th>#</th><th>الاسم</th><th>المشروع</th><th>الدور</th><th>المبلغ</th></tr></thead>
<tbody>${freelancerRows}
<tr class="total-row"><td colspan="4">الإجمالي</td><td style="color:red">${fmtNum(data.expenses.freelancerCosts)} ر.س</td></tr>
</tbody></table>` : ""}
${data.expenses.commitmentDetails && data.expenses.commitmentDetails.length > 0 ? `
<div class="section-title">الالتزامات المالية</div>
<table><thead><tr><th>#</th><th>الالتزام</th><th>المبلغ</th></tr></thead>
<tbody>${commitmentRows}
<tr class="total-row"><td colspan="2">الإجمالي</td><td style="color:red">${fmtNum(data.expenses.commitments)} ر.س</td></tr>
</tbody></table>` : ""}
<div class="section-title">توزيع صافي الربح على الشركاء</div>
<table><thead><tr><th>#</th><th>الشريك</th><th>النسبة</th><th>الحصة</th></tr></thead>
<tbody>${partnerRows}</tbody></table>
<div style="display:flex;justify-content:flex-end;margin-top:20px;gap:20px;align-items:flex-end;">
  <div style="text-align:center;">
    <img src="${window.location.origin}/signature.png" style="height:50px;object-fit:contain;display:block;margin:0 auto;" alt="توقيع" onerror="this.style.display='none'" />
    <div style="font-size:11px;border-top:1px solid #333;padding-top:4px;margin-top:2px;">م/ محمد البلوي</div>
  </div>
</div>
<div class="footer">تم الطباعة بتاريخ ${today}</div>
<button class="btn-print" onclick="window.print()">طباعة / تصدير PDF</button>
</body></html>`);
  printWindow.document.close();
}

function exportMonthlyPartnersExcel(data: MonthlyFinancialReport, label: string) {
  const rows: string[] = [];
  rows.push(`تقرير صافي الربح الشهري - ${label}`);
  rows.push("");
  rows.push("المشاريع والإيرادات");
  rows.push(["العميل", "النوع", "الإيراد", "الضريبة", "صافي بعد الضريبة", "عمولات الموظفين"].join("\t"));
  data.monthProjects.forEach(p => {
    rows.push([
      p.clientName || p.title,
      p.type === "interior" ? "داخلي" : p.type === "exterior" ? "خارجي" : "واجهات",
      p.monthRevenue.toFixed(2),
      p.vatAmount.toFixed(2),
      p.netAfterVat.toFixed(2),
      p.employeeCommissions.map(e => `${e.name} ${e.percentage}% = ${e.amount.toFixed(2)}`).join(" | "),
    ].join("\t"));
  });
  rows.push(["الإجمالي", "", data.totalRevenue.toFixed(2), data.vatAmount.toFixed(2), data.revenueAfterVat.toFixed(2), data.expenses.commissions.toFixed(2)].join("\t"));
  rows.push("");
  rows.push("كشف الرواتب الأساسية");
  rows.push(["الموظف", "المسمى الوظيفي", "الراتب الأساسي", "زيادة", "خصم", "صافي"].join("\t"));
  data.expenses.baseSalariesBreakdown.forEach(e => {
    rows.push([e.name, e.jobTitle, e.baseSalary.toFixed(2), e.bonuses.toFixed(2), e.deductions.toFixed(2), e.net.toFixed(2)].join("\t"));
  });
  if (data.expenses.freelancerCostsBreakdown && data.expenses.freelancerCostsBreakdown.length > 0) {
    rows.push("");
    rows.push("مستحقات الفريلانسر");
    rows.push(["الاسم", "المشروع", "الدور", "المبلغ"].join("\t"));
    data.expenses.freelancerCostsBreakdown.forEach(f => {
      rows.push([f.name, f.projectTitle, f.role, f.amount.toFixed(2)].join("\t"));
    });
    rows.push(["الإجمالي", "", "", data.expenses.freelancerCosts.toFixed(2)].join("\t"));
  }
  rows.push("");
  rows.push("الالتزامات المالية");
  rows.push(["الالتزام", "المبلغ"].join("\t"));
  (data.expenses.commitmentDetails || []).forEach((c: any) => {
    rows.push([c.name || "—", c.amount.toFixed(2)].join("\t"));
  });
  rows.push(["الإجمالي", data.expenses.commitments.toFixed(2)].join("\t"));
  rows.push("");
  rows.push("توزيع صافي الربح على الشركاء");
  rows.push(["الشريك", "النسبة", "الحصة"].join("\t"));
  data.partnersSummary.forEach(p => {
    rows.push([p.name + (p.isMohammed ? " (الباقي)" : ""), `${p.percentage.toFixed(1)}%`, p.shareAmount.toFixed(2)].join("\t"));
  });
  rows.push("");
  rows.push(["صافي الربح الإجمالي", "", data.netProfit.toFixed(2)].join("\t"));

  const blob = new Blob(["\uFEFF" + rows.join("\n")], { type: "text/tab-separated-values;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `تقرير-صافي-الربح-${label}.xls`;
  a.click();
  URL.revokeObjectURL(url);
}

function exportPartnersPDF(partners: Array<Partner & { shareAmount: number; netProfit: number }>, netProfit: number) {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return;
  const today = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const rows = partners.map((p, idx) => `<tr>
    <td>${idx + 1}</td>
    <td><strong>${escapeHtml(p.name)}</strong></td>
    <td>${p.profitPercentage}%</td>
    <td style="font-weight:700;color:#16a34a">${fmtNum(p.shareAmount)} ر.س</td>
  </tr>`).join("");
  const totalShare = partners.reduce((s, p) => s + p.shareAmount, 0);
  printWindow.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">
<title>كشف الشركاء</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'IBM Plex Sans Arabic',sans-serif;background:#fff;color:#111;padding:32px;direction:rtl;}
.header{text-align:center;margin-bottom:24px;border-bottom:3px solid #2563EB;padding-bottom:16px;}
.header h1{font-size:22px;font-weight:700;color:#1e3a8a;}
.header h2{font-size:16px;color:#2563EB;margin-top:4px;}
.net-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 20px;margin:16px 0;display:flex;align-items:center;justify-content:space-between;}
table{width:100%;border-collapse:collapse;font-size:13px;margin-top:16px;}
th{background:#2563EB;color:#fff;padding:8px 10px;font-weight:600;}
td{padding:8px 10px;border-bottom:1px solid #e5e7eb;}
.total-row{background:#dbeafe !important;font-weight:700;font-size:14px;}
.footer{text-align:center;margin-top:24px;font-size:11px;color:#6b7280;border-top:1px solid #e5e7eb;padding-top:12px;}
.btn-print{display:block;margin:16px auto;padding:10px 28px;background:#2563EB;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;}
@media print{.btn-print{display:none;}}
</style></head><body>
<div class="header">
  <h1>مؤسسة محمد البلوي للتصميم الداخلي والخارجي</h1>
  <h2>كشف أرباح الشركاء</h2>
</div>
<div class="net-box">
  <span style="font-size:14px;font-weight:600">صافي الربح الإجمالي</span>
  <span style="font-size:20px;font-weight:700;color:#16a34a">${fmtNum(netProfit)} ر.س</span>
</div>
<table><thead><tr><th>#</th><th>اسم الشريك</th><th>نسبة الربح</th><th>حصة الربح</th></tr></thead>
<tbody>${rows}
<tr class="total-row"><td colspan="3">إجمالي الحصص</td><td>${fmtNum(totalShare)} ر.س</td></tr>
</tbody></table>
<div class="footer">تم الطباعة بتاريخ ${today}</div>
<button class="btn-print" onclick="window.print()">طباعة / تصدير PDF</button>
</body></html>`);
  printWindow.document.close();
}

export default function Salaries() {
  const { user } = useAuth();
  const { toast } = useToast();
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(
    `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`
  );
  const monthOptions = getMonthOptions();
  const [deductionDialog, setDeductionDialog] = useState<string | null>(null);
  const [deductionAmount, setDeductionAmount] = useState("");
  const [deductionReason, setDeductionReason] = useState("");
  const [bonusDialog, setBonusDialog] = useState<string | null>(null);
  const [bonusAmount, setBonusAmount] = useState("");
  const [bonusReason, setBonusReason] = useState("");
  const [partnerDialog, setPartnerDialog] = useState<"add" | "edit" | null>(null);
  const [editingPartner, setEditingPartner] = useState<Partner | null>(null);
  const [partnerName, setPartnerName] = useState("");
  const [partnerPct, setPartnerPct] = useState("");

  const { data, isLoading } = useQuery<SalaryResponse>({
    queryKey: [`/api/salaries/monthly?month=${selectedMonth}`],
  });

  const { data: monthlyData } = useQuery<MonthlyFinancialReport>({
    queryKey: [`/api/reports/financial/monthly?month=${selectedMonth}`],
    enabled: user?.role === "admin",
  });

  const addDeduction = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/salary-deductions", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/salaries/monthly?month=${selectedMonth}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/reports/financial/monthly?month=${selectedMonth}`] });
      toast({ title: "تم إضافة الخصم" });
      setDeductionDialog(null);
      setDeductionAmount("");
      setDeductionReason("");
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteDeduction = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/salary-deductions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/salaries/monthly?month=${selectedMonth}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/reports/financial/monthly?month=${selectedMonth}`] });
      toast({ title: "تم حذف الخصم" });
    },
  });

  const addBonus = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/salary-bonuses", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/salaries/monthly?month=${selectedMonth}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/reports/financial/monthly?month=${selectedMonth}`] });
      toast({ title: "تم إضافة الزيادة" });
      setBonusDialog(null);
      setBonusAmount("");
      setBonusReason("");
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deleteBonus = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/salary-bonuses/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/salaries/monthly?month=${selectedMonth}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/reports/financial/monthly?month=${selectedMonth}`] });
      toast({ title: "تم حذف الزيادة" });
    },
  });

  const invalidatePartners = () => {
    queryClient.invalidateQueries({ queryKey: [`/api/reports/financial/monthly?month=${selectedMonth}`] });
  };

  const createPartner = useMutation({
    mutationFn: (body: any) => apiRequest("POST", "/api/partners", body),
    onSuccess: () => {
      invalidatePartners();
      toast({ title: "تم إضافة الشريك" });
      setPartnerDialog(null);
      setPartnerName(""); setPartnerPct("");
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const updatePartner = useMutation({
    mutationFn: ({ id, ...body }: any) => apiRequest("PUT", `/api/partners/${id}`, body),
    onSuccess: () => {
      invalidatePartners();
      toast({ title: "تم تحديث بيانات الشريك" });
      setPartnerDialog(null);
      setEditingPartner(null); setPartnerName(""); setPartnerPct("");
    },
    onError: (e: any) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
  });

  const deletePartner = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/partners/${id}`),
    onSuccess: () => {
      invalidatePartners();
      toast({ title: "تم حذف الشريك" });
    },
  });

  const [uploadingProjectId, setUploadingProjectId] = useState<string | null>(null);

  async function handleFileUpload(projectId: string, file: File) {
    setUploadingProjectId(projectId);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      if (!res.ok) throw new Error("فشل رفع الملف");
      const { url, fileName, fileType } = await res.json();
      await apiRequest("POST", "/api/files", {
        projectId,
        fileName,
        fileUrl: url,
        fileType,
        uploadedBy: user?.id,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/files`] });
      toast({ title: "تم رفع الملف بنجاح", description: fileName });
    } catch (e: any) {
      toast({ title: "خطأ في رفع الملف", description: e.message, variant: "destructive" });
    } finally {
      setUploadingProjectId(null);
    }
  }

  if (isLoading) {
    return (
      <div className="p-6 space-y-4 overflow-auto h-full" dir="rtl">
        <Skeleton className="h-10 w-48" />
        <div className="grid md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-28" />)}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  const salaries = data?.salaries || [];
  const totalPayroll = data?.totalPayroll || 0;
  const employeesWithCommission = salaries.filter(s => s.totalCommission > 0).length;
  const totalBaseSalaries = salaries.reduce((s, e) => s + e.baseSalary, 0);
  const totalCommissions = salaries.reduce((s, e) => s + e.totalCommission, 0);
  const totalDeductions = salaries.reduce((s, e) => s + (e.totalDeductions || 0), 0);
  const totalBonuses = salaries.reduce((s, e) => s + (e.totalManualBonuses || 0), 0);

  const selectedLabel = monthOptions.find(o => o.value === selectedMonth)?.label || selectedMonth;

  return (
    <div className="p-6 space-y-6 overflow-auto h-full" dir="rtl">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">الرواتب الشهرية</h1>
          <p className="text-muted-foreground">كشف رواتب الموظفين - {selectedLabel}</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[200px]" data-testid="select-month">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {monthOptions.map(opt => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {user?.role === "admin" && salaries.length > 0 && (
            <>
              <Button
                variant="outline"
                onClick={() => exportFreelancersBulkPDF(salaries, selectedLabel)}
                data-testid="button-export-freelancers-pdf"
              >
                <FileText className="h-4 w-4 ml-2" />
                PDF فريلانسرز
              </Button>
              <Button
                variant="outline"
                onClick={() => exportSalaryPDF(salaries, selectedLabel, totalPayroll, totalBaseSalaries, totalCommissions, totalDeductions, totalBonuses)}
                data-testid="button-export-salary-pdf"
              >
                <Download className="h-4 w-4 ml-2" />
                تصدير PDF
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">صافي الرواتب</p>
                <p className="text-xl font-bold" data-testid="text-total-payroll">{formatCurrency(totalPayroll)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">الرواتب الأساسية</p>
                <p className="text-xl font-bold">{formatCurrency(totalBaseSalaries)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">العمولات</p>
                <p className="text-xl font-bold">{formatCurrency(totalCommissions)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <PlusCircle className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">الزيادات</p>
                <p className="text-xl font-bold text-green-600">{formatCurrency(totalBonuses)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                <MinusCircle className="h-5 w-5 text-red-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">الخصومات</p>
                <p className="text-xl font-bold text-red-600">{formatCurrency(totalDeductions)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <Building2 className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">موظفون بعمولات</p>
                <p className="text-xl font-bold">{employeesWithCommission} / {salaries.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {user?.role === "admin" && monthlyData && (
        <Card data-testid="card-partners-section">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-amber-500" />
                الشركاء — صافي الربح الشهري ({selectedLabel})
              </CardTitle>
              <div className="flex items-center gap-2">
                {monthlyData.partnersSummary.length > 0 && (
                  <>
                    <Button variant="outline" size="sm" onClick={() => exportMonthlyPartnersPDF(monthlyData, selectedLabel)} data-testid="button-export-partners-pdf">
                      <Download className="h-4 w-4 ml-1" />PDF
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => exportMonthlyPartnersExcel(monthlyData, selectedLabel)} data-testid="button-export-partners-excel">
                      <FileText className="h-4 w-4 ml-1" />Excel
                    </Button>
                  </>
                )}
                <Button size="sm" onClick={() => { setPartnerDialog("add"); setPartnerName(""); setPartnerPct(""); }} data-testid="button-add-partner">
                  <Plus className="h-4 w-4 ml-1" />إضافة شريك
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">إيرادات الشهر</p>
                <p className="text-lg font-bold text-blue-700 dark:text-blue-400">{formatCurrency(monthlyData.totalRevenue)}</p>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">بعد الضريبة</p>
                <p className="text-lg font-bold">{formatCurrency(monthlyData.revenueAfterVat)}</p>
              </div>
              <div className="p-3 bg-red-50 dark:bg-red-950/30 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">المصروفات</p>
                <p className="text-lg font-bold text-red-700 dark:text-red-400">{formatCurrency(monthlyData.expenses.total)}</p>
              </div>
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">صافي الربح</p>
                <p className="text-lg font-bold text-emerald-700 dark:text-emerald-400" data-testid="text-net-profit">{formatCurrency(monthlyData.netProfit)}</p>
              </div>
            </div>
            {monthlyData.monthProjects.length > 0 && (
              <div className="mb-4">
                <p className="text-sm font-semibold mb-2 text-muted-foreground">المشاريع المُدرَّة للإيرادات هذا الشهر</p>
                <div className="space-y-2">
                  {monthlyData.monthProjects.map(p => (
                    <div key={p.id} className="border rounded-lg p-3 text-sm">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold">{p.clientName || p.title}</span>
                        <span className="font-bold text-blue-600">{formatCurrency(p.monthRevenue)}</span>
                      </div>
                      <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                        <Badge variant="outline" className="text-[10px]">{p.type === "interior" ? "داخلي" : p.type === "exterior" ? "خارجي" : "واجهات"}</Badge>
                        <span>بعد ضريبة: {formatCurrency(p.netAfterVat)}</span>
                        {p.area > 0 && <span>{p.area} م²</span>}
                        {p.employeeCommissions.map((ec, i) => (
                          <span key={i} className="text-amber-600">{ec.name} {ec.percentage}% = {formatCurrency(ec.amount)}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="mb-4 p-3 bg-muted/30 rounded-lg">
              <p className="text-sm font-semibold mb-2">تفاصيل المصروفات الشهرية</p>
              <div className="grid md:grid-cols-2 gap-2 text-sm">
                <div className="flex justify-between"><span>رواتب أساسية (صافي)</span><span>{formatCurrency(monthlyData.expenses.baseSalaries)}</span></div>
                <div className="flex justify-between"><span>عمولات الموظفين</span><span>{formatCurrency(monthlyData.expenses.commissions)}</span></div>
                <div className="flex justify-between"><span>مستحقات فريلانسر</span><span>{formatCurrency(monthlyData.expenses.freelancerCosts)}</span></div>
                <div className="flex justify-between text-red-600 font-semibold"><span>الالتزامات المالية</span><span>{formatCurrency(monthlyData.expenses.commitments)}</span></div>
              </div>
              {monthlyData.expenses.baseSalariesBreakdown.length > 0 && (
                <details className="mt-2">
                  <summary className="text-xs text-muted-foreground cursor-pointer">تفاصيل الرواتب الأساسية ▼</summary>
                  <div className="mt-1 space-y-1">
                    {monthlyData.expenses.baseSalariesBreakdown.map((e, i) => (
                      <div key={i} className="flex justify-between text-xs">
                        <span>{e.name}</span>
                        <span className="flex gap-2">
                          <span>{formatCurrency(e.baseSalary)}</span>
                          {e.bonuses > 0 && <span className="text-green-600">+{formatCurrency(e.bonuses)}</span>}
                          {e.deductions > 0 && <span className="text-red-600">-{formatCurrency(e.deductions)}</span>}
                          <span className="font-semibold">={formatCurrency(e.net)}</span>
                        </span>
                      </div>
                    ))}
                  </div>
                </details>
              )}
            </div>
            <div className="space-y-3">
              <p className="text-sm font-semibold">توزيع صافي الربح على الشركاء</p>
              {monthlyData.partnersSummary.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">لا يوجد شركاء بعد.</p>
              ) : (
                monthlyData.partnersSummary.map(partner => (
                  <div key={partner.id} className={`flex items-center justify-between p-4 border rounded-lg ${partner.isMohammed ? "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800" : "bg-background"}`} data-testid={`card-partner-${partner.id}`}>
                    <div className="flex items-center gap-3">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center ${partner.isMohammed ? "bg-blue-100 dark:bg-blue-900/30" : "bg-amber-100 dark:bg-amber-900/30"}`}>
                        <Star className={`h-5 w-5 ${partner.isMohammed ? "text-blue-600" : "text-amber-600"}`} />
                      </div>
                      <div>
                        <p className="font-semibold text-base">{partner.name}</p>
                        <Badge variant="outline" className="text-[10px] mt-0.5">
                          {partner.isMohammed ? `الباقي (${partner.percentage.toFixed(1)}%)` : `نسبة الربح: ${partner.percentage}%`}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-left">
                        <p className="font-bold text-xl text-emerald-600" data-testid={`text-partner-share-${partner.id}`}>{formatCurrency(partner.shareAmount)}</p>
                        <p className="text-xs text-muted-foreground">حصة من صافي الربح</p>
                      </div>
                      {!partner.isMohammed && (
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm" onClick={() => {
                            setEditingPartner({ id: partner.id, name: partner.name, profitPercentage: partner.percentage, isActive: true });
                            setPartnerName(partner.name);
                            setPartnerPct(String(partner.percentage));
                            setPartnerDialog("edit");
                          }} data-testid={`button-edit-partner-${partner.id}`}><Edit2 className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => deletePartner.mutate(partner.id)} data-testid={`button-delete-partner-${partner.id}`}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {salaries.map(emp => (
          <Card key={emp.employeeId} data-testid={`card-salary-${emp.employeeId}`}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <CardTitle className="text-lg">{emp.employeeName}</CardTitle>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-sm text-muted-foreground">{emp.jobTitle}</p>
                    <Badge variant="outline" className="text-[10px]">
                      {emp.employeeType === "internal" ? "موظف داخلي" : "فريلانسر"}
                    </Badge>
                    {emp.designPercentage > 0 && <Badge className="text-[9px] bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">تصميم {emp.designPercentage}%</Badge>}
                    {emp.executivePercentage > 0 && <Badge className="text-[9px] bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300">مخطط {emp.executivePercentage}%</Badge>}
                    {emp.structuralPercentage > 0 && <Badge className="text-[9px] bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300">هيكل {emp.structuralPercentage}%</Badge>}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-left">
                    <p className="text-2xl font-bold text-primary" data-testid={`text-total-salary-${emp.employeeId}`}>
                      {formatCurrency(emp.totalSalary)}
                    </p>
                    <p className="text-xs text-muted-foreground">صافي الاستحقاق</p>
                  </div>
                  {user?.role === "admin" && (
                    <div className="flex items-center gap-1 flex-wrap">
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-green-600 border-green-200 hover:bg-green-50"
                        onClick={() => setBonusDialog(emp.employeeId)}
                        data-testid={`button-add-bonus-${emp.employeeId}`}
                      >
                        <PlusCircle className="h-4 w-4 ml-1" />
                        زيادة
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeductionDialog(emp.employeeId)}
                        data-testid={`button-add-deduction-${emp.employeeId}`}
                      >
                        <MinusCircle className="h-4 w-4 ml-1" />
                        خصم
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => exportEmployeePDF(emp, selectedLabel)}
                        data-testid={`button-export-employee-pdf-${emp.employeeId}`}
                      >
                        <FileText className="h-4 w-4 ml-1" />
                        كشف
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm">الراتب الأساسي</span>
                    <span className="font-semibold">{formatCurrency(emp.baseSalary)}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm">إجمالي العمولات</span>
                    <span className="font-semibold text-emerald-600">{formatCurrency(emp.totalCommission)}</span>
                  </div>
                  {(emp.totalManualBonuses || 0) > 0 && (
                    <div className="p-3 bg-green-50 dark:bg-green-950/30 rounded-lg space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-green-700 dark:text-green-400 font-medium">الزيادات</span>
                        <span className="font-semibold text-green-600">+ {formatCurrency(emp.totalManualBonuses)}</span>
                      </div>
                      {emp.manualBonuses?.map(b => (
                        <div key={b.id} className="flex items-center justify-between text-xs text-green-600 dark:text-green-400">
                          <span className="flex items-center gap-1">
                            {b.reason}
                            {user?.role === "admin" && (
                              <button className="text-green-400 hover:text-green-600" onClick={() => deleteBonus.mutate(b.id)} data-testid={`button-delete-bonus-${b.id}`}>
                                <Trash2 className="h-3 w-3" />
                              </button>
                            )}
                          </span>
                          <span>+ {formatCurrency(b.amount)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {(emp.totalDeductions > 0) && (
                    <div className="p-3 bg-red-50 dark:bg-red-950/30 rounded-lg space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-red-700 dark:text-red-400 font-medium">الخصومات</span>
                        <span className="font-semibold text-red-600">- {formatCurrency(emp.totalDeductions)}</span>
                      </div>
                      {emp.absenceDeduction > 0 && (
                        <div className="flex items-center justify-between text-xs text-red-600 dark:text-red-400">
                          <span>غياب ({emp.absenceCount} يوم)</span>
                          <span>- {formatCurrency(emp.absenceDeduction)}</span>
                        </div>
                      )}
                      {emp.manualDeductions?.map(d => (
                        <div key={d.id} className="flex items-center justify-between text-xs text-red-600 dark:text-red-400">
                          <span className="flex items-center gap-1">
                            {d.reason}
                            {user?.role === "admin" && (
                              <button
                                className="text-red-400 hover:text-red-600"
                                onClick={() => deleteDeduction.mutate(d.id)}
                                data-testid={`button-delete-deduction-${d.id}`}
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            )}
                          </span>
                          <span>- {formatCurrency(d.amount)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {emp.bankAccount && (
                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <span className="text-sm">الحساب البنكي</span>
                      <span className="text-xs font-mono text-muted-foreground">{emp.bankAccount}</span>
                    </div>
                  )}
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg text-xs text-amber-700 dark:text-amber-400 flex items-center gap-2">
                    <Percent className="h-3.5 w-3.5" />
                    <span>العمولات محسوبة بعد خصم ضريبة القيمة المضافة 15%</span>
                  </div>
                </div>
                <div>
                  {emp.commissions.length > 0 ? (
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground mb-2">
                        {emp.employeeType === "freelancer" ? "المشاريع المسندة:" : "تفاصيل العمولات:"}
                      </p>
                      {emp.commissions.map((c, i) => (
                        <div key={i} className={`flex items-center justify-between p-2.5 border rounded-lg text-sm ${emp.employeeType === "freelancer" && !c.isPaid ? "opacity-60 border-dashed" : ""}`}>
                          <div className="flex-1">
                            <p className="font-medium">{c.clientName || c.projectTitle}</p>
                            <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                              <Badge variant="outline" className="text-[10px]">{c.designType}</Badge>
                              {c.contractArea > 0 && <span className="text-xs text-muted-foreground">{c.contractArea} م²</span>}
                              <Badge className="text-[10px] bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                                {c.paymentLabel}
                              </Badge>
                              {emp.employeeType === "freelancer" && (
                                <Badge className={`text-[10px] ${c.isPaid ? "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300" : "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300"}`}>
                                  {c.isPaid ? <><CheckCircle className="h-2.5 w-2.5 ml-0.5 inline" />تم الدفع</> : <><Clock className="h-2.5 w-2.5 ml-0.5 inline" />لم يُدفع</>}
                                </Badge>
                              )}
                              {emp.employeeType === "freelancer" && c.percentage > 0 && (
                                <span className="text-xs text-amber-600 font-semibold">{c.percentage}% من العقد</span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                              {c.designCommission > 0 && <span>تصميم: {formatCurrency(c.designCommission)}</span>}
                              {c.executiveCommission > 0 && <span>مخطط: {formatCurrency(c.executiveCommission)}</span>}
                              {c.structuralCommission > 0 && <span>هيكل: {formatCurrency(c.structuralCommission)}</span>}
                              {emp.employeeType === "freelancer" && c.assignedAmount && (
                                <span>المبلغ المحدد: {formatCurrency(c.assignedAmount)}</span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2 mr-2">
                            <span className={`font-semibold ${c.amount > 0 ? "text-emerald-600" : "text-muted-foreground"}`}>
                              {c.amount > 0 ? formatCurrency(c.amount) : emp.employeeType === "freelancer" ? formatCurrency(c.assignedAmount || 0) : "—"}
                            </span>
                            {emp.employeeType === "freelancer" && (
                              <label
                                className="cursor-pointer p-1 rounded hover:bg-blue-50 dark:hover:bg-blue-950/30 text-blue-600 transition-colors"
                                title="رفع ملف للمشروع"
                                data-testid={`button-upload-file-${c.projectId}`}
                              >
                                {uploadingProjectId === c.projectId ? (
                                  <span className="text-[10px] text-muted-foreground">جاري...</span>
                                ) : (
                                  <Upload className="h-3.5 w-3.5" />
                                )}
                                <input
                                  type="file"
                                  className="hidden"
                                  disabled={uploadingProjectId === c.projectId}
                                  onChange={e => {
                                    const file = e.target.files?.[0];
                                    if (file) handleFileUpload(c.projectId, file);
                                    e.target.value = "";
                                  }}
                                />
                              </label>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
                      لا توجد {emp.employeeType === "freelancer" ? "مشاريع مسندة" : "عمولات لهذا الشهر"}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!bonusDialog} onOpenChange={() => setBonusDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إضافة زيادة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">المبلغ (ر.س)</label>
              <Input
                type="number"
                value={bonusAmount}
                onChange={e => setBonusAmount(e.target.value)}
                placeholder="0"
                data-testid="input-bonus-amount"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">السبب</label>
              <Input
                value={bonusReason}
                onChange={e => setBonusReason(e.target.value)}
                placeholder="سبب الزيادة..."
                data-testid="input-bonus-reason"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={() => {
                if (!bonusAmount || !bonusReason || !bonusDialog) return;
                addBonus.mutate({
                  employeeId: bonusDialog,
                  month: selectedMonth,
                  amount: parseFloat(bonusAmount),
                  reason: bonusReason,
                });
              }}
              disabled={addBonus.isPending}
              data-testid="button-submit-bonus"
            >
              إضافة الزيادة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deductionDialog} onOpenChange={() => setDeductionDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إضافة خصم</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">المبلغ (ر.س)</label>
              <Input
                type="number"
                value={deductionAmount}
                onChange={e => setDeductionAmount(e.target.value)}
                placeholder="0"
                data-testid="input-deduction-amount"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">السبب</label>
              <Input
                value={deductionReason}
                onChange={e => setDeductionReason(e.target.value)}
                placeholder="سبب الخصم..."
                data-testid="input-deduction-reason"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              onClick={() => {
                if (!deductionAmount || !deductionReason || !deductionDialog) return;
                addDeduction.mutate({
                  employeeId: deductionDialog,
                  month: selectedMonth,
                  amount: parseFloat(deductionAmount),
                  reason: deductionReason,
                });
              }}
              disabled={addDeduction.isPending}
              data-testid="button-submit-deduction"
            >
              إضافة الخصم
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!partnerDialog} onOpenChange={(open) => { if (!open) { setPartnerDialog(null); setEditingPartner(null); setPartnerName(""); setPartnerPct(""); } }}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>{partnerDialog === "add" ? "إضافة شريك جديد" : "تعديل بيانات الشريك"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">الاسم</label>
              <Input
                value={partnerName}
                onChange={e => setPartnerName(e.target.value)}
                placeholder="اسم الشريك"
                data-testid="input-partner-name"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">نسبة الربح (%)</label>
              <Input
                type="number"
                min="0"
                max="100"
                value={partnerPct}
                onChange={e => setPartnerPct(e.target.value)}
                placeholder="مثال: 25"
                data-testid="input-partner-pct"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              onClick={() => {
                if (!partnerName || !partnerPct) return;
                const pct = parseFloat(partnerPct);
                if (isNaN(pct) || pct <= 0 || pct > 100) return;
                if (partnerDialog === "add") {
                  createPartner.mutate({ name: partnerName, profitPercentage: pct, isActive: true });
                } else if (editingPartner) {
                  updatePartner.mutate({ id: editingPartner.id, name: partnerName, profitPercentage: pct });
                }
              }}
              disabled={createPartner.isPending || updatePartner.isPending}
              data-testid="button-submit-partner"
            >
              {partnerDialog === "add" ? "إضافة" : "حفظ التعديلات"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
