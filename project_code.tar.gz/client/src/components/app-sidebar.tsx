import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Users,
  FolderOpen,
  UserCheck,
  CheckSquare,
  FileText,
  DollarSign,
  BarChart2,
  LogOut,
  Calendar,
  Shield,
  Calculator,
  Clock,
  Megaphone,
  Wallet,
  FileText as FileTextIcon,
} from "lucide-react";
import type { Employee } from "@shared/schema";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import logoIcon from "@assets/WhatsApp_Image_2026-02-24_at_11.25.33_PM_1771964913996.jpeg";
import logoFull from "@assets/WhatsApp_Image_2026-02-24_at_11.21.06_PM_1771964504429.jpeg";

type MenuItem = {
  title: string;
  url: string;
  icon: any;
};

const adminMenuItems: MenuItem[] = [
  { title: "لوحة التحكم", url: "/", icon: LayoutDashboard },
  { title: "العملاء", url: "/clients", icon: Users },
  { title: "المشاريع", url: "/projects", icon: FolderOpen },
  { title: "الموظفون", url: "/employees", icon: UserCheck },
  { title: "المهام", url: "/tasks", icon: CheckSquare },
  { title: "العقود", url: "/contracts", icon: FileText },
  { title: "المالية", url: "/finance", icon: DollarSign },
  { title: "الرواتب", url: "/salaries", icon: Wallet },
  { title: "التقارير", url: "/reports", icon: BarChart2 },
  { title: "تفرغ الموظفين", url: "/availability", icon: Clock },
  { title: "أداة القياس الذكية", url: "/calculator", icon: Calculator },
  { title: "عرض السعر", url: "/price-quote", icon: FileTextIcon },
  { title: "جهات الاتصال التسويقية", url: "/marketing-contacts", icon: Megaphone },
  { title: "إدارة المستخدمين", url: "/user-management", icon: Shield },
];

const employeeMenuItems: MenuItem[] = [
  { title: "لوحة التحكم", url: "/", icon: LayoutDashboard },
  { title: "مشاريعي", url: "/my-projects", icon: FolderOpen },
  { title: "مهامي", url: "/my-tasks", icon: CheckSquare },
  { title: "سجل الحضور", url: "/my-attendance", icon: Calendar },
  { title: "جدول التفرغ", url: "/my-availability", icon: Clock },
  { title: "أداة القياس", url: "/calculator", icon: Calculator },
  { title: "عرض السعر", url: "/price-quote", icon: FileTextIcon },
];

const freelancerMenuItems: MenuItem[] = [
  { title: "لوحة التحكم", url: "/", icon: LayoutDashboard },
  { title: "مشاريعي", url: "/my-projects", icon: FolderOpen },
  { title: "مهامي", url: "/my-tasks", icon: CheckSquare },
  { title: "جدول التفرغ", url: "/my-availability", icon: Clock },
  { title: "أداة القياس", url: "/calculator", icon: Calculator },
];

const roleLabels: Record<string, string> = {
  admin: "مدير",
  employee: "موظف رسمي",
  freelancer: "فري لانسر",
};

const roleBadgeColors: Record<string, string> = {
  admin: "bg-white/20 text-white border-white/10",
  employee: "bg-white/15 text-white/90 border-white/10",
  freelancer: "bg-white/15 text-white/90 border-white/10",
};

function isInteriorEmployee(employee: Employee | undefined): boolean {
  if (!employee) return false;
  const spec = ((employee as any).jobTitle || employee.specialty || "").toLowerCase();
  if (spec.includes("خارجي")) return false;
  return true;
}

function isInteriorManagerEmployee(employee: Employee | undefined): boolean {
  if (!employee) return false;
  const spec = ((employee as any).jobTitle || employee.specialty || "");
  return spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي");
}

export function AppSidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const myEmployee = user?.employeeId ? employees.find(e => e.id === user.employeeId) : undefined;
  const isInteriorMgr = isInteriorManagerEmployee(myEmployee);
  const isInterior = isInteriorEmployee(myEmployee);

  const getMenuItems = () => {
    if (user?.role === "admin") return adminMenuItems;
    if (user?.role === "employee") {
      const extra: MenuItem[] = [];
      if (isInterior) extra.push({ title: "العقود", url: "/contracts", icon: FileText });
      if (isInteriorMgr) extra.push({ title: "الموظفون", url: "/employees", icon: UserCheck });
      if (extra.length > 0) return [...employeeMenuItems, ...extra];
      return employeeMenuItems;
    }
    return freelancerMenuItems;
  };

  const menuItems = getMenuItems();

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full overflow-hidden ring-2 ring-white/15 flex-shrink-0">
            <img src={logoIcon} alt="M" className="h-full w-full object-cover" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-sm font-bold text-white truncate leading-tight">MOHAMMED AL BALWI</span>
            <span className="text-[10px] text-white/40 tracking-wider">GROUP</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-white/40 text-[10px] uppercase tracking-wider">القائمة الرئيسية</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => {
                const isActive = location === item.url || (item.url !== "/" && location.startsWith(item.url));
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      data-active={isActive}
                      className="data-[active=true]:bg-[#2563EB] data-[active=true]:text-white data-[active=true]:font-medium hover:bg-[#1F2937]"
                    >
                      <Link href={item.url}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border px-4 py-3">
        {user && (
          <div className="flex items-center justify-between mb-2">
            <div className="flex flex-col gap-1">
              <span className="text-sm font-medium text-sidebar-foreground">{user.name}</span>
              <Badge className={`text-[10px] w-fit ${roleBadgeColors[user.role] || ""}`} variant="secondary">
                {roleLabels[user.role] || user.role}
              </Badge>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={logout}
              data-testid="button-logout"
              className="h-8 w-8 text-white/40 hover:text-white hover:bg-white/10"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        )}
        <div className="text-[10px] text-white/30 text-center">
          النظام الإداري والمالي 2026
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
