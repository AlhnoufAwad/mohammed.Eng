import { Switch, Route } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { QueryClientProvider, useQuery, useMutation } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import Dashboard from "@/pages/dashboard";
import Clients from "@/pages/clients";
import Projects from "@/pages/projects";
import ProjectDetail from "@/pages/project-detail";
import Employees from "@/pages/employees";
import Tasks from "@/pages/tasks";
import Contracts from "@/pages/contracts";
import Finance from "@/pages/finance";
import Reports from "@/pages/reports";
import ClientProjects from "@/pages/client-projects";
import AuthPage from "@/pages/auth-page";
import EmployeeDashboard from "@/pages/employee-dashboard";
import MyTasks from "@/pages/my-tasks";
import MyProjects from "@/pages/my-projects";
import MyAttendance from "@/pages/my-attendance";
import UserManagement from "@/pages/user-management";
import AvailabilitySchedule from "@/pages/availability-schedule";
import AdminAvailability from "@/pages/admin-availability";
import ProjectCalculator from "@/pages/project-calculator";
import MarketingContacts from "@/pages/marketing-contacts";
import Salaries from "@/pages/salaries";
import PriceQuote from "@/pages/price-quote";
import ResetPassword from "@/pages/reset-password";

import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { Loader2, Bell, X, CheckCheck } from "lucide-react";
import logoIcon from "@assets/WhatsApp_Image_2026-02-24_at_11.25.33_PM_1771964913996.jpeg";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import type { Notification, Employee } from "@shared/schema";
import { formatCurrency } from "@/lib/utils";

function AdminRouter() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/clients" component={Clients} />
      <Route path="/clients/:id/projects" component={ClientProjects} />
      <Route path="/projects" component={Projects} />
      <Route path="/projects/:id" component={ProjectDetail} />
      <Route path="/employees" component={Employees} />
      <Route path="/tasks" component={Tasks} />
      <Route path="/contracts" component={Contracts} />
      <Route path="/finance" component={Finance} />
      <Route path="/salaries" component={Salaries} />
      <Route path="/reports" component={Reports} />
      <Route path="/user-management" component={UserManagement} />
      <Route path="/availability" component={AdminAvailability} />
      <Route path="/calculator" component={ProjectCalculator} />
      <Route path="/price-quote" component={PriceQuote} />
      <Route path="/marketing-contacts" component={MarketingContacts} />
      <Route component={NotFound} />
    </Switch>
  );
}

function EmployeeRouter() {
  const { user } = useAuth();
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const myEmp = user?.employeeId ? employees.find(e => e.id === user.employeeId) : undefined;
  const spec = ((myEmp as any)?.jobTitle || myEmp?.specialty || "");
  const isInteriorMgr = spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي");
  const isInterior = !spec.includes("خارجي") && spec.length > 0;

  return (
    <Switch>
      <Route path="/" component={EmployeeDashboard} />
      <Route path="/my-projects" component={MyProjects} />
      <Route path="/my-tasks" component={MyTasks} />
      <Route path="/my-attendance" component={MyAttendance} />
      <Route path="/my-availability" component={AvailabilitySchedule} />
      <Route path="/calculator" component={ProjectCalculator} />
      <Route path="/price-quote" component={PriceQuote} />
      <Route path="/projects/:id" component={ProjectDetail} />
      {isInterior && <Route path="/contracts" component={Contracts} />}
      {isInteriorMgr && <Route path="/employees" component={Employees} />}
      <Route component={NotFound} />
    </Switch>
  );
}

function FreelancerRouter() {
  return (
    <Switch>
      <Route path="/" component={EmployeeDashboard} />
      <Route path="/my-projects" component={MyProjects} />
      <Route path="/my-tasks" component={MyTasks} />
      <Route path="/my-availability" component={AvailabilitySchedule} />
      <Route path="/calculator" component={ProjectCalculator} />
      <Route path="/projects/:id" component={ProjectDetail} />
      <Route component={NotFound} />
    </Switch>
  );
}

function NotificationBell() {
  const [open, setOpen] = useState(false);
  const { data: unreadNotifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications/unread"],
    refetchInterval: 30000,
  });
  const { data: allNotifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: open,
  });

  const markRead = useMutation({
    mutationFn: (id: string) => apiRequest("PUT", `/api/notifications/${id}/read`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
    },
  });

  const markAllRead = useMutation({
    mutationFn: () => apiRequest("PUT", "/api/notifications/read-all"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
    },
  });

  const unreadCount = (unreadNotifications || []).length;
  const displayNotifications = open ? (allNotifications || []) : [];

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        className="relative"
        onClick={() => setOpen(!open)}
        data-testid="button-notifications"
      >
        <Bell className="h-4.5 w-4.5" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 h-4.5 min-w-[18px] rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center px-1" data-testid="text-notification-count">
            {unreadCount}
          </span>
        )}
      </Button>

      {open && (
        <div className="absolute left-0 top-full mt-2 w-[380px] max-h-[480px] bg-background border border-border rounded-xl shadow-xl z-50 overflow-hidden" dir="rtl">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <h3 className="font-semibold text-sm">التنبيهات</h3>
            <div className="flex items-center gap-1">
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => markAllRead.mutate()} data-testid="button-mark-all-read">
                  <CheckCheck className="h-3.5 w-3.5 ml-1" />قراءة الكل
                </Button>
              )}
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setOpen(false)}>
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
          <div className="overflow-y-auto max-h-[400px]">
            {displayNotifications.length === 0 ? (
              <div className="p-6 text-center text-sm text-muted-foreground">لا توجد تنبيهات</div>
            ) : (
              displayNotifications.map(n => (
                <div
                  key={n.id}
                  className={`px-4 py-3 border-b border-border last:border-0 cursor-pointer transition-colors hover:bg-muted/50 ${!n.isRead ? "bg-primary/5" : ""}`}
                  onClick={() => { if (!n.isRead) markRead.mutate(n.id); }}
                  data-testid={`notification-${n.id}`}
                >
                  <div className="flex items-start gap-2">
                    {!n.isRead && <div className="h-2 w-2 rounded-full bg-blue-500 mt-1.5 flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{n.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{n.message}</p>
                      {n.amount != null && n.amount > 0 && (
                        <p className="text-sm font-bold text-emerald-600 mt-1">{formatCurrency(n.amount)}</p>
                      )}
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {n.createdAt ? new Date(n.createdAt).toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" }) : ""}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function MainContent({ Router }: { Router: React.ComponentType }) {
  const { open, setOpen, isMobile, openMobile, setOpenMobile } = useSidebar();

  const handleMainClick = () => {
    if (isMobile && openMobile) {
      setOpenMobile(false);
    } else if (!isMobile && open) {
      setOpen(false);
    }
  };

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <header className="flex items-center gap-3 px-4 py-2.5 border-b border-border bg-background flex-shrink-0" style={{ height: "52px" }}>
        <div className="flex items-center gap-2.5 hidden sm:flex">
          <div className="h-8 w-8 rounded-full overflow-hidden ring-2 ring-foreground/10 flex-shrink-0">
            <img src={logoIcon} alt="Logo" className="h-full w-full object-cover" />
          </div>
          <span className="text-[11px] text-muted-foreground font-semibold tracking-wide">MOHAMMED AL BALWI GROUP</span>
        </div>
        <div className="flex-1" />
        <NotificationBell />
        <SidebarTrigger data-testid="button-sidebar-toggle" />
      </header>
      <main className="flex-1 overflow-hidden" onClick={handleMainClick}>
        <Router />
      </main>
    </div>
  );
}

function AuthenticatedApp() {
  const { user, isLoading } = useAuth();

  // Allow reset-password page without authentication
  if (window.location.pathname === "/reset-password") {
    return <ResetPassword />;
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen" dir="rtl">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="text-muted-foreground">جاري التحميل...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  const style = {
    "--sidebar-width": "17rem",
    "--sidebar-width-icon": "3.5rem",
  };

  const Router = user.role === "admin"
    ? AdminRouter
    : user.role === "employee"
    ? EmployeeRouter
    : FreelancerRouter;

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full overflow-hidden" dir="rtl">
        <AppSidebar />
        <MainContent Router={Router} />
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <AuthenticatedApp />
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
