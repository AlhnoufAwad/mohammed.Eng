import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoleEnum = pgEnum("user_role", ["admin", "employee", "freelancer"]);
export const projectTypeEnum = pgEnum("project_type", ["interior", "exterior", "facades"]);
export const projectStatusEnum = pgEnum("project_status", ["active", "completed", "paused", "cancelled"]);
export const phaseStatusEnum = pgEnum("phase_status", ["pending", "in_progress", "completed"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "paid", "overdue"]);
export const employeeTypeEnum = pgEnum("employee_type", ["internal", "freelancer"]);
export const taskStatusEnum = pgEnum("task_status", ["pending", "in_progress", "completed", "overdue"]);
export const taskPriorityEnum = pgEnum("task_priority", ["low", "medium", "high"]);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: userRoleEnum("role").notNull().default("employee"),
  employeeId: varchar("employee_id"),
  email: text("email"),
  resetToken: text("reset_token"),
  resetTokenExpiry: timestamp("reset_token_expiry"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  city: text("city"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id),
  projectType: projectTypeEnum("project_type").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  areaSqm: real("area_sqm"),
  pricePerSqm: real("price_per_sqm"),
  totalValue: real("total_value").notNull(),
  status: projectStatusEnum("status").default("active"),
  currentPhase: integer("current_phase").default(1),
  startDate: text("start_date"),
  endDate: text("end_date"),
  location: text("location"),
  googleMapsUrl: text("google_maps_url"),
  paymentSchedule: integer("payment_schedule").default(3),
  executionDays: integer("execution_days"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const projectPhases = pgTable("project_phases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  phaseName: text("phase_name").notNull(),
  phaseOrder: integer("phase_order").notNull(),
  status: phaseStatusEnum("status").default("pending"),
  dueDate: text("due_date"),
  completionDate: text("completion_date"),
  timePercentage: real("time_percentage"),
  notes: text("notes"),
  isApproved: boolean("is_approved").default(false),
  responsibleEmployeeId: varchar("responsible_employee_id"),
  responsibleRole: text("responsible_role"),
  phaseType: text("phase_type").default("work"),
  paymentPercentage: integer("payment_percentage"),
});

export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  paymentNumber: integer("payment_number").notNull(),
  amount: real("amount").notNull(),
  percentage: real("percentage").notNull(),
  paymentType: text("payment_type").notNull(),
  status: paymentStatusEnum("status").default("pending"),
  dueDate: text("due_date"),
  paidDate: text("paid_date"),
  notes: text("notes"),
});

export const employees = pgTable("employees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  department: text("department"),
  employeeType: employeeTypeEnum("employee_type").notNull(),
  designPercentage: real("design_percentage"),
  executivePercentage: real("executive_percentage"),
  structuralPercentage: real("structural_percentage"),
  pricePerSqm: real("price_per_sqm"),
  contractStartDate: text("contract_start_date"),
  phone: text("phone"),
  email: text("email"),
  nationality: text("nationality"),
  jobTitle: text("job_title"),
  baseSalary: real("base_salary"),
  salaryDescription: text("salary_description"),
  jobRoles: text("job_roles"),
  bankAccount: text("bank_account"),
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  employeeId: varchar("employee_id").references(() => employees.id),
  title: text("title").notNull(),
  description: text("description"),
  priority: taskPriorityEnum("priority").default("medium"),
  status: taskStatusEnum("status").default("pending"),
  dueDate: text("due_date"),
  completionDate: text("completion_date"),
  reminderDays: integer("reminder_days").default(3),
  isRecurring: boolean("is_recurring").default(false),
  notes: text("notes"),
  fee: real("fee"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const contracts = pgTable("contracts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  contractNumber: text("contract_number").notNull().unique(),
  contractDate: text("contract_date").notNull(),
  clientSigned: boolean("client_signed").default(false),
  companySigned: boolean("company_signed").default(false),
  terms: text("terms"),
  specialConditions: text("special_conditions"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const employeeAssignments = pgTable("employee_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  role: text("role"),
  workType: text("work_type"),
  assignedAmount: real("assigned_amount"),
  isPaid: boolean("is_paid").default(false),
  paidDate: text("paid_date"),
  notes: text("notes"),
});

export const attendance = pgTable("attendance", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  date: text("date").notNull(),
  status: text("status").notNull(),
  notes: text("notes"),
});

export const availabilityStatusEnum = pgEnum("availability_status", ["available", "busy", "partial"]);

export const availabilitySchedule = pgTable("availability_schedule", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  date: text("date").notNull(),
  status: availabilityStatusEnum("status").notNull().default("available"),
  availableHours: integer("available_hours").default(8),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const visitStatusEnum = pgEnum("visit_status", ["planned", "completed", "cancelled"]);
export const contactStatusEnum = pgEnum("contact_status", ["lead", "contacted", "interested", "not_interested"]);

export const fieldVisits = pgTable("field_visits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  employeeId: varchar("employee_id").references(() => employees.id),
  visitDate: text("visit_date").notNull(),
  location: text("location"),
  googleMapsUrl: text("google_maps_url"),
  purpose: text("purpose"),
  findings: text("findings"),
  status: visitStatusEnum("status").default("planned"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const projectFiles = pgTable("project_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  phaseId: varchar("phase_id"),
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  fileType: text("file_type"),
  description: text("description"),
  uploadedBy: varchar("uploaded_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const marketingContacts = pgTable("marketing_contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  city: text("city"),
  source: text("source"),
  notes: text("notes"),
  lastContactDate: text("last_contact_date"),
  status: contactStatusEnum("status").default("lead"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  projectId: varchar("project_id"),
  employeeId: varchar("employee_id"),
  amount: real("amount"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const capacitySettings = pgTable("capacity_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  maxLargeProjects: integer("max_large_projects").default(2),
  largeProjectThreshold: real("large_project_threshold").default(300),
  daysPerSqmInterior: real("days_per_sqm_interior").default(0.15),
  daysPerSqmExterior: real("days_per_sqm_exterior").default(0.1),
  basePriceInterior: real("base_price_interior").default(250),
  basePriceExterior: real("base_price_exterior").default(180),
});

export const financialCommitments = pgTable("financial_commitments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  amount: real("amount").notNull(),
  type: text("type").notNull(),
  projectId: varchar("project_id"),
  month: text("month"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const freelancerRates = pgTable("freelancer_rates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  workType: text("work_type").notNull(),
  minArea: real("min_area").notNull(),
  maxArea: real("max_area").notNull(),
  pricePerSqm: real("price_per_sqm").notNull(),
  fixedPrice: real("fixed_price"),
});

export const salaryDeductions = pgTable("salary_deductions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  month: text("month").notNull(),
  amount: real("amount").notNull(),
  reason: text("reason").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const salaryBonuses = pgTable("salary_bonuses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  month: text("month").notNull(),
  amount: real("amount").notNull(),
  reason: text("reason").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const partners = pgTable("partners", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  profitPercentage: real("profit_percentage").notNull(),
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPartnerSchema = createInsertSchema(partners).omit({ id: true, createdAt: true });
export const insertFreelancerRateSchema = createInsertSchema(freelancerRates).omit({ id: true });
export const insertSalaryDeductionSchema = createInsertSchema(salaryDeductions).omit({ id: true, createdAt: true });
export const insertSalaryBonusSchema = createInsertSchema(salaryBonuses).omit({ id: true, createdAt: true });
export const insertFinancialCommitmentSchema = createInsertSchema(financialCommitments).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export const insertAvailabilitySchema = createInsertSchema(availabilitySchedule).omit({ id: true, createdAt: true });
export const insertCapacitySettingsSchema = createInsertSchema(capacitySettings).omit({ id: true });
export const insertFieldVisitSchema = createInsertSchema(fieldVisits).omit({ id: true, createdAt: true });
export const insertProjectFileSchema = createInsertSchema(projectFiles).omit({ id: true, createdAt: true });
export const insertMarketingContactSchema = createInsertSchema(marketingContacts).omit({ id: true, createdAt: true });

export const insertClientSchema = createInsertSchema(clients).omit({ id: true, createdAt: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
export const insertPhaseSchema = createInsertSchema(projectPhases).omit({ id: true });
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true });
export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true, createdAt: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true });
export const contractTerms = pgTable("contract_terms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contractId: varchar("contract_id").notNull().references(() => contracts.id),
  termOrder: integer("term_order").notNull(),
  termText: text("term_text").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertContractSchema = createInsertSchema(contracts).omit({ id: true, createdAt: true });
export const insertContractTermSchema = createInsertSchema(contractTerms).omit({ id: true, createdAt: true });
export const insertAssignmentSchema = createInsertSchema(employeeAssignments).omit({ id: true });
export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true });

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type ProjectPhase = typeof projectPhases.$inferSelect;
export type InsertPhase = z.infer<typeof insertPhaseSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Contract = typeof contracts.$inferSelect;
export type InsertContract = z.infer<typeof insertContractSchema>;
export type EmployeeAssignment = typeof employeeAssignments.$inferSelect;
export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type AvailabilityScheduleType = typeof availabilitySchedule.$inferSelect;
export type InsertAvailability = z.infer<typeof insertAvailabilitySchema>;
export type CapacitySettingsType = typeof capacitySettings.$inferSelect;
export type InsertCapacitySettings = z.infer<typeof insertCapacitySettingsSchema>;
export type FieldVisit = typeof fieldVisits.$inferSelect;
export type InsertFieldVisit = z.infer<typeof insertFieldVisitSchema>;
export type ProjectFile = typeof projectFiles.$inferSelect;
export type InsertProjectFile = z.infer<typeof insertProjectFileSchema>;
export type MarketingContact = typeof marketingContacts.$inferSelect;
export type InsertMarketingContact = z.infer<typeof insertMarketingContactSchema>;
export type ContractTerm = typeof contractTerms.$inferSelect;
export type InsertContractTerm = z.infer<typeof insertContractTermSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type FinancialCommitment = typeof financialCommitments.$inferSelect;
export type InsertFinancialCommitment = z.infer<typeof insertFinancialCommitmentSchema>;
export type FreelancerRate = typeof freelancerRates.$inferSelect;
export type InsertFreelancerRate = z.infer<typeof insertFreelancerRateSchema>;
export type SalaryDeduction = typeof salaryDeductions.$inferSelect;
export type InsertSalaryDeduction = z.infer<typeof insertSalaryDeductionSchema>;
export type SalaryBonus = typeof salaryBonuses.$inferSelect;
export type InsertSalaryBonus = z.infer<typeof insertSalaryBonusSchema>;
export type Partner = typeof partners.$inferSelect;
export type InsertPartner = z.infer<typeof insertPartnerSchema>;
