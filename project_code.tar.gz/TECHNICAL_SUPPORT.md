# دليل الدعم الفني - نظام إدارة مؤسسة محمد البلوي للتصميم الداخلي والخارجي

## نظرة عامة على المشروع

نظام إدارة متكامل لمؤسسة **محمد البلوي للتصميم الداخلي والخارجي** يشمل إدارة المشاريع، الموظفين، العملاء، العقود، المدفوعات، والمهام.

- **التقنيات:** React + TypeScript (Frontend) / Express + Node.js (Backend) / PostgreSQL (Database)
- **التصميم:** أسود وأبيض (Black & White Theme)
- **اللغة:** عربي (RTL) - خط IBM Plex Sans Arabic
- **المصادقة:** Passport.js مع جلسات (Sessions)

---

## هيكل المشروع

```
├── client/                      ← الواجهة الأمامية (Frontend)
│   └── src/
│       ├── App.tsx              ← الملف الرئيسي - التوجيه (Routing) حسب الصلاحيات
│       ├── main.tsx             ← نقطة الدخول
│       ├── index.css            ← الأنماط العامة والثيم
│       ├── components/
│       │   ├── app-sidebar.tsx  ← القائمة الجانبية (حسب الدور)
│       │   └── ui/             ← مكونات shadcn/ui الجاهزة
│       ├── hooks/
│       │   ├── use-auth.tsx     ← إدارة تسجيل الدخول والمصادقة
│       │   ├── use-mobile.tsx   ← كشف الشاشات الصغيرة
│       │   └── use-toast.ts    ← الإشعارات المنبثقة
│       ├── lib/
│       │   ├── queryClient.ts  ← إعداد TanStack Query + apiRequest
│       │   └── utils.ts        ← أدوات مساعدة (cn)
│       └── pages/              ← صفحات التطبيق
│
├── server/                      ← الخادم (Backend)
│   ├── index.ts                ← تشغيل الخادم
│   ├── routes.ts               ← جميع نقاط API
│   ├── storage.ts              ← طبقة قاعدة البيانات (CRUD)
│   ├── auth.ts                 ← المصادقة والجلسات
│   ├── seed.ts                 ← بيانات أولية
│   ├── vite.ts                 ← إعداد Vite (لا تعدل)
│   └── static.ts              ← تقديم الملفات الثابتة
│
├── shared/
│   └── schema.ts               ← نموذج البيانات (Drizzle ORM) + أنواع TypeScript
│
├── package.json                ← التبعيات والأوامر
├── drizzle.config.ts           ← إعداد Drizzle (لا تعدل)
├── tailwind.config.ts          ← إعداد Tailwind CSS
└── vite.config.ts              ← إعداد Vite (لا تعدل)
```

---

## الصفحات وتصنيفها

### صفحات المشرف (Admin)
| الصفحة | الملف | الوصف |
|--------|-------|-------|
| لوحة التحكم | `dashboard.tsx` | إحصائيات عامة - عدد المشاريع والعملاء والمدفوعات |
| العملاء | `clients.tsx` | إدارة بيانات العملاء (إضافة/تعديل/حذف) |
| مشاريع العميل | `client-projects.tsx` | عرض مشاريع عميل محدد |
| المشاريع | `projects.tsx` | قائمة جميع المشاريع |
| تفاصيل المشروع | `project-detail.tsx` | تفاصيل مشروع واحد (المراحل/المدفوعات/الفريق) |
| الموظفين | `employees.tsx` | إدارة بيانات الموظفين |
| المهام | `tasks.tsx` | إدارة المهام وتوزيعها |
| العقود | `contracts.tsx` | إنشاء وإدارة العقود |
| المالية | `finance.tsx` | متابعة المدفوعات والإيرادات |
| التقارير | `reports.tsx` | تقارير شاملة |
| إدارة المستخدمين | `user-management.tsx` | ربط المستخدمين بالموظفين وتعيين الأدوار |
| جدول التوفر (إدارة) | `admin-availability.tsx` | عرض مصفوفة توفر جميع الموظفين |
| حاسبة المشاريع | `project-calculator.tsx` | تقدير تكلفة ومدة المشروع |

### صفحات الموظف/المتعاقد (Employee/Freelancer)
| الصفحة | الملف | الوصف |
|--------|-------|-------|
| لوحة التحكم | `employee-dashboard.tsx` | إحصائيات خاصة بالموظف |
| مشاريعي | `my-projects.tsx` | المشاريع المسندة للموظف |
| مهامي | `my-tasks.tsx` | مهام الموظف |
| حضوري | `my-attendance.tsx` | سجل الحضور |
| جدول التوفر | `availability-schedule.tsx` | إدارة أوقات التوفر الشخصية |
| حاسبة المشاريع | `project-calculator.tsx` | تقدير تكلفة ومدة المشروع |

### صفحات عامة
| الصفحة | الملف | الوصف |
|--------|-------|-------|
| تسجيل الدخول | `auth-page.tsx` | تسجيل دخول وإنشاء حساب |
| صفحة غير موجودة | `not-found.tsx` | صفحة 404 |

---

## نموذج البيانات (Database Schema)

### الجداول
| الجدول | الوصف | الحقول الرئيسية |
|--------|-------|-----------------|
| `users` | المستخدمين | id, username, password, name, role, employeeId |
| `clients` | العملاء | id, name, phone, email, city, notes |
| `projects` | المشاريع | id, clientId, projectType, title, areaSqm, totalValue, status |
| `project_phases` | مراحل المشروع | id, projectId, phaseName, phaseOrder, status |
| `payments` | المدفوعات | id, projectId, paymentNumber, amount, percentage, status |
| `employees` | الموظفين | id, name, specialty, employeeType, pricePerSqm |
| `tasks` | المهام | id, projectId, employeeId, title, priority, status |
| `contracts` | العقود | id, projectId, contractNumber, contractDate |
| `employee_assignments` | تعيينات المشاريع | id, projectId, employeeId, role, assignedAmount |
| `attendance` | الحضور | id, employeeId, date, status |
| `availability_schedule` | جدول التوفر | id, employeeId, date, status, availableHours |
| `capacity_settings` | إعدادات السعة | maxLargeProjects, largeProjectThreshold, أسعار المتر |

### أنواع القيم المعددة (Enums)
| الاسم | القيم |
|-------|-------|
| `user_role` | admin, employee, freelancer |
| `project_type` | interior, exterior |
| `project_status` | active, completed, paused, cancelled |
| `phase_status` | pending, in_progress, completed |
| `payment_status` | pending, paid, overdue |
| `employee_type` | internal, freelancer |
| `task_status` | pending, in_progress, completed, overdue |
| `task_priority` | low, medium, high |
| `availability_status` | available, busy, partial |

---

## نقاط API

### لوحة التحكم
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/dashboard` | إحصائيات لوحة التحكم الرئيسية |

### العملاء
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/clients` | جلب جميع العملاء |
| GET | `/api/clients/:id` | جلب عميل محدد |
| POST | `/api/clients` | إضافة عميل جديد |
| PUT | `/api/clients/:id` | تعديل بيانات عميل |
| DELETE | `/api/clients/:id` | حذف عميل |

### المشاريع
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/projects` | جلب جميع المشاريع |
| GET | `/api/projects/:id` | جلب مشروع محدد |
| GET | `/api/clients/:clientId/projects` | مشاريع عميل محدد |
| POST | `/api/projects` | إنشاء مشروع (ينشئ تلقائياً المراحل والمدفوعات) |
| PUT | `/api/projects/:id` | تعديل مشروع |
| DELETE | `/api/projects/:id` | حذف مشروع |

### مراحل المشروع
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/projects/:projectId/phases` | مراحل مشروع محدد |
| POST | `/api/phases` | إضافة مرحلة |
| PUT | `/api/phases/:id` | تعديل مرحلة |

### المدفوعات
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/payments` | جميع المدفوعات |
| GET | `/api/projects/:projectId/payments` | مدفوعات مشروع محدد |
| PUT | `/api/payments/:id` | تعديل حالة دفعة |

### الموظفين
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/employees` | جميع الموظفين |
| GET | `/api/employees/:id` | موظف محدد |
| POST | `/api/employees` | إضافة موظف |
| PUT | `/api/employees/:id` | تعديل موظف |
| DELETE | `/api/employees/:id` | حذف موظف |

### المهام
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/tasks` | جميع المهام |
| GET | `/api/projects/:projectId/tasks` | مهام مشروع محدد |
| POST | `/api/tasks` | إضافة مهمة |
| PUT | `/api/tasks/:id` | تعديل مهمة |
| DELETE | `/api/tasks/:id` | حذف مهمة |

### العقود
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/contracts` | جميع العقود |
| GET | `/api/projects/:projectId/contract` | عقد مشروع محدد |
| POST | `/api/contracts` | إنشاء عقد |
| PUT | `/api/contracts/:id` | تعديل عقد |

### تعيينات الموظفين
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/projects/:projectId/assignments` | تعيينات مشروع |
| POST | `/api/assignments` | إضافة تعيين |
| PUT | `/api/assignments/:id` | تعديل تعيين |
| DELETE | `/api/assignments/:id` | حذف تعيين |

### الحضور
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/attendance` | جميع سجلات الحضور |
| GET | `/api/employees/:employeeId/attendance` | حضور موظف محدد |
| POST | `/api/attendance` | تسجيل حضور |

### إدارة المستخدمين (مشرف فقط)
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/users` | جلب المستخدمين |
| PUT | `/api/users/:id` | تعديل دور المستخدم وربطه بموظف |

### نقاط الموظف الشخصية
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/my/dashboard` | إحصائيات الموظف |
| GET | `/api/my/projects` | مشاريع الموظف |
| POST | `/api/my/projects` | إنشاء مشروع من حساب الموظف |
| GET | `/api/my/tasks` | مهام الموظف |
| GET | `/api/my/assignments` | تعيينات الموظف |
| GET | `/api/my/attendance` | حضور الموظف |
| GET | `/api/my/availability` | جدول توفر الموظف |
| POST | `/api/my/availability` | تحديث توفر الموظف |
| DELETE | `/api/my/availability/:id` | حذف سجل توفر |
| GET | `/api/my/capacity` | معلومات سعة الموظف |

### إعدادات السعة والأدوات
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | `/api/availability` | جميع سجلات التوفر (إدارة) |
| GET | `/api/capacity-settings` | إعدادات السعة |
| PUT | `/api/capacity-settings/:id` | تعديل إعدادات السعة (مشرف فقط) |
| POST | `/api/tools/estimate` | تقدير تكلفة ومدة مشروع |

### المصادقة
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| POST | `/api/auth/login` | تسجيل الدخول |
| POST | `/api/auth/register` | إنشاء حساب جديد |
| POST | `/api/auth/logout` | تسجيل الخروج |
| GET | `/api/auth/user` | جلب بيانات المستخدم الحالي |

---

## نظام الصلاحيات (الأدوار)

| الدور | الصلاحيات |
|-------|-----------|
| **admin** (مشرف) | جميع الصفحات + إدارة المستخدمين + إعدادات السعة |
| **employee** (موظف) | لوحة التحكم الشخصية + مشاريعي + مهامي + حضوري + جدول التوفر + حاسبة المشاريع |
| **freelancer** (متعاقد) | نفس صلاحيات الموظف |

---

## قواعد العمل (Business Rules)

### جدول المدفوعات
عند إنشاء أي مشروع يتم إنشاء 3 دفعات تلقائياً:
- **الدفعة الأولى:** 50% عند توقيع العقد
- **الدفعة الثانية:** 30% عند اعتماد الهيكل الإنشائي
- **الدفعة الثالثة:** 20% عند اعتماد التصميم

### مراحل المشروع
**تصميم داخلي (Interior) - 5 مراحل:**
1. المخطط (ثابت الوضع المحلي)
2. المناقشة لأخذ الطلبات
3. لوحة الأفكار
4. التصميم الأولي والنهائي
5. المخطط التنفيذي

**تصميم خارجي (Exterior) - 4 مراحل:**
1. الهيكل الإنشائي (الوضع الحالي)
2. المناقشة لأخذ الطلبات
3. التصميم
4. المخططات التنفيذية

### إعدادات السعة والتقدير الافتراضية
- الحد الأقصى للمشاريع الكبيرة: 2
- عتبة المشروع الكبير: 300 متر مربع
- أيام/متر مربع (داخلي): 0.15
- أيام/متر مربع (خارجي): 0.1
- سعر المتر (داخلي): 250 ريال
- سعر المتر (خارجي): 180 ريال

---

## الملفات الحساسة (لا تعدل)

| الملف | السبب |
|-------|-------|
| `vite.config.ts` | إعداد Vite - يؤثر على تشغيل التطبيق |
| `server/vite.ts` | إعداد Vite للخادم |
| `drizzle.config.ts` | إعداد قاعدة البيانات |
| `package.json` | التبعيات - أي تعديل يتطلب إعادة تثبيت |

---

## أوامر التشغيل

| الأمر | الوصف |
|-------|-------|
| `npm run dev` | تشغيل بيئة التطوير |
| `npm run build` | بناء التطبيق للإنتاج |
| `npm start` | تشغيل نسخة الإنتاج |
| `npm run db:push` | مزامنة مخطط قاعدة البيانات |
| `npm run check` | فحص TypeScript |

---

## التبعيات الرئيسية

| التبعية | الاستخدام |
|---------|-----------|
| React 18 | واجهة المستخدم |
| Express 5 | خادم API |
| Drizzle ORM | التعامل مع قاعدة البيانات |
| TanStack Query v5 | إدارة حالة البيانات في الواجهة |
| Tailwind CSS | التنسيق والأنماط |
| shadcn/ui | مكونات واجهة المستخدم الجاهزة |
| Passport.js | المصادقة |
| Zod | التحقق من صحة البيانات |
| wouter | التوجيه في الواجهة |
| Recharts | الرسوم البيانية |
| lucide-react | الأيقونات |

---

## استكشاف الأخطاء الشائعة

| المشكلة | الحل |
|---------|------|
| التطبيق لا يعمل | تأكد من وجود `DATABASE_URL` و `SESSION_SECRET` في المتغيرات البيئية |
| خطأ في قاعدة البيانات | شغّل `npm run db:push` لمزامنة الجداول |
| المستخدم لا يرى مشاريعه | تأكد من ربط المستخدم بموظف عبر صفحة "إدارة المستخدمين" (حقل `employeeId`) |
| الصفحات لا تظهر | تحقق من دور المستخدم (admin/employee/freelancer) |
| خطأ 401 Unauthorized | المستخدم غير مسجل دخول - أعد تسجيل الدخول |
| خطأ 403 Forbidden | المستخدم ليس لديه صلاحية - تحقق من الدور |
