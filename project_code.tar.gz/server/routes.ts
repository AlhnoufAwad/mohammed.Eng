import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertClientSchema, insertProjectSchema, insertPhaseSchema, insertPaymentSchema, insertEmployeeSchema, insertTaskSchema, insertContractSchema, insertContractTermSchema, insertAssignmentSchema, insertAttendanceSchema, insertAvailabilitySchema, insertFieldVisitSchema, insertProjectFileSchema, insertMarketingContactSchema, insertFinancialCommitmentSchema, insertFreelancerRateSchema, insertSalaryDeductionSchema, insertSalaryBonusSchema } from "@shared/schema";
import { z } from "zod";
import { requireAuth } from "./auth";
import { sendPasswordResetEmail, isEmailConfigured } from "./email";
import crypto from "crypto";
import multer from "multer";
import path from "path";
import fs from "fs";

const uploadsDir = path.join(process.cwd(), "client/public/uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const multerStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.\-_\u0600-\u06FF]/g, "_");
    cb(null, `${Date.now()}-${safeName}`);
  },
});
const upload = multer({ storage: multerStorage, limits: { fileSize: 20 * 1024 * 1024 } });

function getPhasesByType(projectType: string) {
  if (projectType === "interior") {
    return [
      { name: "الدفعة الأولى 50%", order: 1, timePct: 0, role: "خدمة عملاء", phaseType: "financial", paymentPct: 50 },
      { name: "الخطط", order: 2, timePct: 10, role: "مساح", phaseType: "work" },
      { name: "المناقشة", order: 3, timePct: 20, role: "خدمة عملاء", phaseType: "work" },
      { name: "لوحة الافكار", order: 4, timePct: 40, role: "مصمم", phaseType: "work" },
      { name: "الدفعة الثانية 30%", order: 5, timePct: 45, role: "خدمة عملاء", phaseType: "financial", paymentPct: 30 },
      { name: "التصميم", order: 6, timePct: 70, role: "مصمم", phaseType: "work" },
      { name: "الدفعة الثالثة 20%", order: 7, timePct: 75, role: "خدمة عملاء", phaseType: "financial", paymentPct: 20 },
      { name: "المخطط التنفيذي", order: 8, timePct: 100, role: "مساح", phaseType: "work" },
    ];
  } else if (projectType === "facades") {
    return [
      { name: "الدفعة الأولى 50%", order: 1, timePct: 0, role: "خدمة عملاء", phaseType: "financial", paymentPct: 50 },
      { name: "التصميم الأولي للواجهات", order: 2, timePct: 20, role: "مصمم", phaseType: "work" },
      { name: "الدفعة الثانية 30%", order: 3, timePct: 25, role: "خدمة عملاء", phaseType: "financial", paymentPct: 30 },
      { name: "المناقشة والتعديلات", order: 4, timePct: 45, role: "خدمة عملاء", phaseType: "work" },
      { name: "التصميم النهائي", order: 5, timePct: 70, role: "مصمم", phaseType: "work" },
      { name: "الدفعة الثالثة 20%", order: 6, timePct: 75, role: "خدمة عملاء", phaseType: "financial", paymentPct: 20 },
      { name: "المخططات التنفيذية", order: 7, timePct: 100, role: "مساح", phaseType: "work" },
    ];
  } else {
    return [
      { name: "الدفعة الأولى 50%", order: 1, timePct: 0, role: "خدمة عملاء", phaseType: "financial", paymentPct: 50 },
      { name: "الهيكل الانشائي", order: 2, timePct: 15, role: "مساح", phaseType: "work" },
      { name: "الدفعة الثانية 30%", order: 3, timePct: 20, role: "خدمة عملاء", phaseType: "financial", paymentPct: 30 },
      { name: "المناقشة", order: 4, timePct: 35, role: "خدمة عملاء", phaseType: "work" },
      { name: "التصميم", order: 5, timePct: 65, role: "مصمم", phaseType: "work" },
      { name: "الدفعة الثالثة 20%", order: 6, timePct: 70, role: "خدمة عملاء", phaseType: "financial", paymentPct: 20 },
      { name: "المخططات التنفيذية", order: 7, timePct: 100, role: "مساح", phaseType: "work" },
    ];
  }
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  app.use("/api", (req, res, next) => {
    if (req.path.startsWith("/auth/")) return next();
    requireAuth(req, res, next);
  });

  async function canManageFreelancerTasks(req: any): Promise<boolean> {
    if (req.user?.role === "admin") return true;
    if (!req.user?.employeeId) return false;
    const emp = await storage.getEmployee(req.user.employeeId);
    if (!emp || emp.employeeType !== "internal") return false;
    const spec = ((emp as any).jobTitle || emp.specialty || "");
    if (spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي")) return true;
    if (spec.includes("خدمة عملاء") || spec.includes("تسويق")) return true;
    return false;
  }

  async function checkExpiredFirstPayments() {
    try {
      const allPayments = await storage.getAllPayments();
      const firstPayments = allPayments.filter(p => p.paymentNumber === 1 && p.status === "pending" && p.dueDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      for (const payment of firstPayments) {
        const dueDate = new Date(payment.dueDate!);
        dueDate.setHours(0, 0, 0, 0);
        if (today > dueDate) {
          const project = await storage.getProject(payment.projectId);
          if (project && project.status === "active") {
            await storage.updateProject(payment.projectId, { status: "paused" } as any);
            await storage.createNotification({
              type: "project_deactivated",
              title: `تعطيل مشروع: ${project.title}`,
              message: `تم تعطيل المشروع "${project.title}" تلقائياً لعدم استلام الدفعة الأولى خلال 15 يوم من تاريخ العقد`,
              projectId: payment.projectId,
              employeeId: null,
              amount: payment.amount,
              isRead: false,
            });
          }
        }
      }
    } catch (e) {
      console.error("[auto-deactivation] Error:", e);
    }
  }

  checkExpiredFirstPayments();
  setInterval(checkExpiredFirstPayments, 6 * 60 * 60 * 1000);

  // Dashboard
  app.get("/api/dashboard", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Clients
  app.get("/api/clients", async (req, res) => {
    try {
      const data = await storage.getClients();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/clients/:id", async (req, res) => {
    try {
      const data = await storage.getClient(req.params.id);
      if (!data) return res.status(404).json({ error: "Not found" });
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/clients", async (req, res) => {
    try {
      const parsed = insertClientSchema.parse(req.body);
      const data = await storage.createClient(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/clients/:id", async (req, res) => {
    try {
      const parsed = insertClientSchema.partial().parse(req.body);
      const data = await storage.updateClient(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/clients/:id", async (req, res) => {
    try {
      await storage.deleteClient(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const data = await storage.getProjects();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const data = await storage.getProject(req.params.id);
      if (!data) return res.status(404).json({ error: "Not found" });
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/clients/:clientId/projects", async (req, res) => {
    try {
      const data = await storage.getProjectsByClient(req.params.clientId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const parsed = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(parsed);
      const phasesList = getPhasesByType(parsed.projectType);

      for (const ph of phasesList) {
        await storage.createPhase({
          projectId: project.id, phaseName: ph.name, phaseOrder: ph.order,
          status: ph.order === 1 ? "in_progress" : "pending", timePercentage: ph.timePct,
          dueDate: null, completionDate: null, notes: null, isApproved: false,
          responsibleEmployeeId: null, responsibleRole: ph.role,
        });
      }

      const total = parsed.totalValue;
      const paymentCount = parsed.paymentSchedule || 3;
      let paymentDefs: { num: number; pct: number; type: string; amount: number }[] = [];
      if (paymentCount === 1) {
        paymentDefs = [{ num: 1, pct: 100, type: "دفعة كاملة عند توقيع العقد", amount: total }];
      } else if (paymentCount === 2) {
        paymentDefs = [
          { num: 1, pct: 50, type: "عند توقيع العقد", amount: total * 0.50 },
          { num: 2, pct: 50, type: "عند اعتماد التصميم", amount: total * 0.50 },
        ];
      } else {
        paymentDefs = [
          { num: 1, pct: 50, type: "عند توقيع العقد", amount: total * 0.50 },
          { num: 2, pct: 30, type: "عند اعتماد الهيكل الإنشائي وقبل المناقشة والبدء بالتصميم", amount: total * 0.30 },
          { num: 3, pct: 20, type: "بعد اعتماد التصميم وقبل البدء بالمخططات التنفيذية", amount: total * 0.20 },
        ];
      }

      for (const pd of paymentDefs) {
        await storage.createPayment({
          projectId: project.id, paymentNumber: pd.num, amount: pd.amount,
          percentage: pd.pct, paymentType: pd.type, status: "pending",
          dueDate: null, paidDate: null, notes: null,
        });
      }

      res.status(201).json(project);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin" && req.user?.role !== "interior_manager") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertProjectSchema.partial().parse(req.body);
      const data = await storage.updateProject(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteProject(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Project Phases
  app.get("/api/projects/:projectId/phases", async (req, res) => {
    try {
      const data = await storage.getProjectPhases(req.params.projectId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/phases", async (req, res) => {
    try {
      const parsed = insertPhaseSchema.parse(req.body);
      const data = await storage.createPhase(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/phases/:id", async (req, res) => {
    try {
      const parsed = insertPhaseSchema.partial().parse(req.body);

      const phaseBeforeUpdate = await storage.getPhaseById(req.params.id);
      if (!phaseBeforeUpdate) return res.status(404).json({ error: "المرحلة غير موجودة" });

      if (parsed.status === "completed" && (phaseBeforeUpdate as any).phaseType === "financial") {
        const phaseFiles = (await storage.getProjectFiles(phaseBeforeUpdate.projectId)).filter(f => (f as any).phaseId === phaseBeforeUpdate.id);
        if (phaseFiles.length === 0) {
          return res.status(400).json({ error: "يجب رفع إيصال الدفعة قبل إتمام هذه المرحلة" });
        }
      }

      const data = await storage.updatePhase(req.params.id, parsed);

      if (parsed.status === "completed" && data.projectId) {
        const project = await storage.getProject(data.projectId);

        await storage.createNotification({
          type: "phase_completed",
          title: `اكتمال مرحلة: ${data.phaseName}`,
          message: `تم إنجاز مرحلة "${data.phaseName}" في مشروع "${project?.title || ""}"`,
          projectId: data.projectId,
          employeeId: null,
          amount: null,
          isRead: false,
        });

        const allPhases = await storage.getProjectPhases(data.projectId);
        const sortedPhases = allPhases.sort((a, b) => a.phaseOrder - b.phaseOrder);
        const nextPhase = sortedPhases.find(p => p.phaseOrder > data.phaseOrder && p.status === "pending");
        if (nextPhase) {
          await storage.updatePhase(nextPhase.id, { status: "in_progress" });

          const responsibleId = (nextPhase as any).responsibleEmployeeId;
          if (responsibleId) {
            await storage.createNotification({
              type: "phase_started",
              title: `مرحلة جديدة: ${nextPhase.phaseName}`,
              message: `بدأت مرحلة "${nextPhase.phaseName}" في مشروع "${project?.title || ""}" — يرجى البدء بالعمل عليها`,
              projectId: data.projectId,
              employeeId: responsibleId,
              amount: null,
              isRead: false,
            });
          } else {
            const projectAssignments = await storage.getAssignments(data.projectId);
            const allEmployees = await storage.getEmployees();
            for (const assign of projectAssignments) {
              const emp = allEmployees.find(e => e.id === assign.employeeId);
              if (emp && emp.employeeType !== "freelancer") {
                await storage.createNotification({
                  type: "phase_started",
                  title: `مرحلة جديدة: ${nextPhase.phaseName}`,
                  message: `بدأت مرحلة "${nextPhase.phaseName}" في مشروع "${project?.title || ""}" — يرجى البدء بالعمل عليها`,
                  projectId: data.projectId,
                  employeeId: emp.id,
                  amount: null,
                  isRead: false,
                });
              }
            }
          }
        }

        if ((data as any).phaseType === "financial" && (data as any).paymentPercentage) {
          const projectPayments = await storage.getPayments(data.projectId);
          const matchingPayment = projectPayments.find(p => p.percentage === (data as any).paymentPercentage && p.status !== "paid");
          if (matchingPayment) {
            await storage.updatePayment(matchingPayment.id, { status: "paid", paidDate: new Date().toISOString().split("T")[0] });
            await storage.createNotification({
              type: "payment_received",
              title: `تسليم دفعة: ${matchingPayment.percentage}%`,
              message: `تم تسليم الدفعة ${matchingPayment.paymentNumber} (${matchingPayment.percentage}%) بمبلغ ${matchingPayment.amount.toLocaleString("ar-SA")} ر.س - مشروع "${project?.title || ""}"`,
              projectId: data.projectId,
              employeeId: null,
              amount: matchingPayment.amount,
              isRead: false,
            });

            if (matchingPayment.paymentNumber === 1) {
              await autoAssignOnFirstPayment(data.projectId);
            }
          }
        }

        const allCompleted = sortedPhases.length > 0 && sortedPhases.every(p => p.id === data.id ? true : p.status === "completed");

        if (allCompleted) {
          const existing = await storage.getNotifications();
          const alreadyNotified = existing.some(n => n.projectId === data.projectId && n.type === "project_completed");

          if (!alreadyNotified) {
            const project = await storage.getProject(data.projectId);
            const assignments = await storage.getAssignments(data.projectId);
            const allEmployees = await storage.getEmployees();

            for (const assignment of assignments) {
              const emp = allEmployees.find(e => e.id === assignment.employeeId);
              if (!emp) continue;

              const designPct = (emp as any).designPercentage || 0;
              const execPct = (emp as any).executivePercentage || 0;
              const structPct = (emp as any).structuralPercentage || 0;
              const totalPct = designPct + execPct + structPct;
              if (totalPct === 0) continue;
              const amount = project ? (project.totalValue * totalPct) / 100 : 0;

              await storage.createNotification({
                type: "project_completed",
                title: `تم إنجاز مشروع: ${project?.title || ""}`,
                message: `${emp.name} أنجز المشروع "${project?.title || ""}" - يستحق مبلغ ${amount.toLocaleString("ar-SA")} ر.س (${totalPct}% من قيمة المشروع)`,
                projectId: data.projectId,
                employeeId: emp.id,
                amount,
                isRead: false,
              });
            }
          }
        }
      }

      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Payments
  app.get("/api/payments", async (req, res) => {
    try {
      const data = await storage.getAllPayments();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/projects/:projectId/payments", async (req, res) => {
    try {
      const data = await storage.getPayments(req.params.projectId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  async function autoAssignOnFirstPayment(projectId: string) {
    const existingAssignments = await storage.getAssignments(projectId);
    const allEmployees = await storage.getEmployees();
    const internalAssignments = existingAssignments.filter(a => {
      const emp = allEmployees.find(e => e.id === a.employeeId);
      return emp && emp.employeeType !== "freelancer";
    });
    if (internalAssignments.length > 0) return;

    const project = await storage.getProject(projectId);
    if (!project) return;
    const pType = project.projectType || "";
    const assignedIds = new Set<string>();

    for (const emp of allEmployees) {
      if (emp.employeeType === "freelancer" || !emp.isActive) continue;
      const spec = ((emp as any).jobTitle || emp.specialty || "");
      let shouldAssign = false;
      let role = "";

      if (spec.includes("المدير العام") || spec.includes("خدمة عملاء") || spec.includes("تسويق")) {
        shouldAssign = true;
        role = spec.includes("المدير العام") ? "المدير العام" : "خدمة عملاء";
      } else if (pType === "interior" && (spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي"))) {
        shouldAssign = true;
        role = "مصمم داخلي";
      } else if ((pType === "exterior" || pType === "facades") && (spec.includes("خارجي") || spec.includes("مخطط") || spec.includes("رسم") || spec.includes("هيكل"))) {
        shouldAssign = true;
        role = spec.includes("مخطط") || spec.includes("رسم") || spec.includes("هيكل") ? "مساح" : "مصمم خارجي";
      }

      if (shouldAssign && !assignedIds.has(emp.id)) {
        assignedIds.add(emp.id);
        await storage.createAssignment({
          projectId,
          employeeId: emp.id,
          role,
          assignedAmount: null,
          isPaid: false,
          paidDate: null,
          notes: null,
        });
        await storage.createNotification({
          type: "project_assigned",
          title: `مشروع جديد: ${project.title}`,
          message: `تم تعيينك على المشروع "${project.title}" بعد استلام الدفعة الأولى — دورك: ${role}`,
          projectId,
          employeeId: emp.id,
          amount: null,
          isRead: false,
        });
      }
    }
  }

  app.put("/api/payments/:id", async (req, res) => {
    try {
      const parsed = insertPaymentSchema.partial().parse(req.body);
      const existingPayment = await storage.getPaymentById?.(req.params.id);
      const data = await storage.updatePayment(req.params.id, parsed);

      if (parsed.status === "paid" && data.paymentNumber === 1 && existingPayment?.status !== "paid") {
        await autoAssignOnFirstPayment(data.projectId);
      }

      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Employees
  app.get("/api/employees", async (req, res) => {
    try {
      const data = await storage.getEmployees();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/employees/:id", async (req, res) => {
    try {
      const data = await storage.getEmployee(req.params.id);
      if (!data) return res.status(404).json({ error: "Not found" });
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/employees", async (req, res) => {
    try {
      const parsed = insertEmployeeSchema.parse(req.body);
      const data = await storage.createEmployee(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/employees/:id", async (req, res) => {
    try {
      const parsed = insertEmployeeSchema.partial().parse(req.body);
      const data = await storage.updateEmployee(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/employees/:id", async (req, res) => {
    try {
      await storage.deleteEmployee(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Tasks
  app.get("/api/tasks", async (req, res) => {
    try {
      const data = await storage.getTasks();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/projects/:projectId/tasks", async (req, res) => {
    try {
      const data = await storage.getTasksByProject(req.params.projectId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const parsed = insertTaskSchema.parse(req.body);
      const data = await storage.createTask(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/tasks/:id", async (req, res) => {
    try {
      const parsed = insertTaskSchema.partial().parse(req.body);
      const data = await storage.updateTask(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      await storage.deleteTask(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Contracts
  app.get("/api/contracts", async (req, res) => {
    try {
      const data = await storage.getContracts();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/projects/:projectId/contract", async (req, res) => {
    try {
      const data = await storage.getContract(req.params.projectId);
      res.json(data || null);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/contracts", async (req, res) => {
    try {
      const parsed = insertContractSchema.parse(req.body);
      const data = await storage.createContract(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.post("/api/contracts/full", async (req, res) => {
    try {
      const { clientName, clientPhone, clientAddress, projectType, areaSqm, pricePerSqm, totalValue, paymentSchedule, firstStepDate, finalDeliveryDate, terms, specialConditions, notes, executionDays: execDaysStr } = req.body;
      if (!clientName || !clientPhone || !projectType || !areaSqm || !totalValue) {
        return res.status(400).json({ error: "جميع الحقول المطلوبة يجب تعبئتها" });
      }

      const client = await storage.createClient({
        name: clientName, phone: clientPhone, city: clientAddress || null, email: null, notes: null,
      });

      const typeLabel = projectType === "interior" ? "تصميم داخلي" : projectType === "facades" ? "واجهات" : "تصميم خارجي";
      const title = `${typeLabel} - ${clientName}`;
      const execDays = execDaysStr ? parseInt(execDaysStr) : null;
      const today = new Date();

      let computedFirstStepDate = firstStepDate || null;
      let computedFinalDeliveryDate = finalDeliveryDate || null;
      if (execDays && !computedFirstStepDate) {
        const halfD = new Date(today);
        halfD.setDate(halfD.getDate() + Math.round(execDays / 2));
        computedFirstStepDate = halfD.toISOString().split("T")[0];
      }
      if (execDays && !computedFinalDeliveryDate) {
        const endD = new Date(today);
        endD.setDate(endD.getDate() + execDays);
        computedFinalDeliveryDate = endD.toISOString().split("T")[0];
      }

      const project = await storage.createProject({
        clientId: client.id, projectType, title, description: null,
        areaSqm: parseFloat(areaSqm), pricePerSqm: pricePerSqm ? parseFloat(pricePerSqm) : null,
        totalValue: parseFloat(totalValue), status: "active", currentPhase: 1,
        startDate: computedFirstStepDate, endDate: computedFinalDeliveryDate,
        location: clientAddress || null, paymentSchedule: parseInt(paymentSchedule) || 3,
      });

      const phases = getPhasesByType(projectType);
      if (execDays) {
        await storage.updateProject(project.id, { executionDays: execDays } as any);
      }

      const allEmps = await storage.getEmployees();
      let capacityDelayDays = 0;
      if (execDays) {
        const responsibleRoles = [...new Set(phases.filter(p => p.phaseType === "work").map(p => p.role))];
        for (const role of responsibleRoles) {
          for (const emp of allEmps) {
            const spec = ((emp as any).jobTitle || emp.specialty || "");
            let matches = false;
            if (spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي")) {
              matches = projectType === "interior";
            } else if (role === "خدمة عملاء" && (spec.includes("خدمة عملاء") || spec.includes("تسويق"))) matches = true;
            else if (role === "مساح" && (spec.includes("مخطط") || spec.includes("مساح") || spec.includes("رسم"))) matches = true;
            else if (role === "مصمم" && spec.includes("مصمم") && !spec.includes("داخلي")) matches = true;

            if (matches) {
              const capInfo = await storage.getEmployeeCapacityInfo(emp.id);
              const empDelay = (capInfo.activeProjects || 0) * 7;
              if (empDelay > capacityDelayDays) capacityDelayDays = empDelay;
            }
          }
        }
      }

      for (const ph of phases) {
        let dueDate: string | null = null;
        if (execDays && ph.phaseType === "work") {
          const phaseDays = Math.round((ph.timePct / 100) * execDays) + capacityDelayDays;
          const d = new Date(today);
          d.setDate(d.getDate() + phaseDays);
          dueDate = d.toISOString().split("T")[0];
        }

        await storage.createPhase({
          projectId: project.id, phaseName: ph.name, phaseOrder: ph.order,
          status: ph.order === 1 ? "in_progress" : "pending", timePercentage: ph.timePct,
          dueDate,
          completionDate: null,
          notes: null, isApproved: false,
          responsibleEmployeeId: null, responsibleRole: ph.role,
          phaseType: ph.phaseType || "work",
          paymentPercentage: (ph as any).paymentPct || null,
        });
      }

      if (execDays && capacityDelayDays > 0) {
        const endD = new Date(today);
        endD.setDate(endD.getDate() + execDays + capacityDelayDays);
        await storage.updateProject(project.id, { endDate: endD.toISOString().split("T")[0] } as any);
      }

      const total = parseFloat(totalValue);
      const pCount = parseInt(paymentSchedule) || 3;
      let paymentDefs: { num: number; pct: number; type: string; amount: number }[] = [];
      if (pCount === 1) {
        paymentDefs = [{ num: 1, pct: 100, type: "دفعة كاملة عند توقيع العقد", amount: total }];
      } else if (pCount === 2) {
        paymentDefs = [
          { num: 1, pct: 50, type: "عند توقيع العقد", amount: total * 0.50 },
          { num: 2, pct: 50, type: "عند اعتماد التصميم", amount: total * 0.50 },
        ];
      } else {
        paymentDefs = [
          { num: 1, pct: 50, type: "عند توقيع العقد", amount: total * 0.50 },
          { num: 2, pct: 30, type: "عند اعتماد الهيكل الإنشائي وقبل المناقشة والبدء بالتصميم", amount: total * 0.30 },
          { num: 3, pct: 20, type: "بعد اعتماد التصميم وقبل البدء بالمخططات التنفيذية", amount: total * 0.20 },
        ];
      }

      const firstPaymentDeadline = new Date(today);
      firstPaymentDeadline.setDate(firstPaymentDeadline.getDate() + 15);
      const firstPaymentDueDate = firstPaymentDeadline.toISOString().split("T")[0];

      for (const pd of paymentDefs) {
        await storage.createPayment({
          projectId: project.id, paymentNumber: pd.num, amount: pd.amount,
          percentage: pd.pct, paymentType: pd.type, status: "pending",
          dueDate: pd.num === 1 ? firstPaymentDueDate : null, paidDate: null, notes: null,
        });
      }

      const contract = await storage.createContract({
        projectId: project.id,
        contractNumber: `C-${Date.now()}`,
        contractDate: new Date().toISOString().split("T")[0],
        clientSigned: false, companySigned: false,
        terms: terms || null, specialConditions: specialConditions || null, notes: notes || null,
      });

      const creatorName = req.user?.name || "غير معروف";
      await storage.createNotification({
        type: "contract_created",
        title: `عقد جديد: ${contract.contractNumber}`,
        message: `تم كتابة عقد جديد "${title}" للعميل ${clientName} بقيمة ${parseFloat(totalValue).toLocaleString("ar-SA")} ر.س — بواسطة: ${creatorName}`,
        projectId: project.id,
        employeeId: null,
        amount: parseFloat(totalValue),
        isRead: false,
      });

      res.status(201).json({ client, project, contract });
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/contracts/:id", async (req, res) => {
    try {
      const parsed = insertContractSchema.partial().parse(req.body);
      const data = await storage.updateContract(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.get("/api/contracts/:contractId/terms", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const terms = await storage.getContractTerms(req.params.contractId);
      res.json(terms);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/contracts/:contractId/terms", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertContractTermSchema.parse({ ...req.body, contractId: req.params.contractId });
      const data = await storage.createContractTerm(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/contract-terms/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertContractTermSchema.partial().parse(req.body);
      const data = await storage.updateContractTerm(req.params.id, parsed);
      if (!data) return res.status(404).json({ error: "البند غير موجود" });
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/contract-terms/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteContractTerm(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/contracts/:contractId/default-terms", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const existing = await storage.getContractTerms(req.params.contractId);
      if (existing.length > 0) return res.status(400).json({ error: "البنود الافتراضية محملة مسبقاً" });
      const defaultTerms = [
        "يُعتبر العقد معتمداً ونافذاً بمجرد قيام الطرف الثاني بتحويل الدفعة الأولى المتفق عليها.",
        "في حالة تحويل الدفعة الاولى، لا يحق للطرف الثاني طلب أي مخططات كهرباء أو سباكة أو أي توزيعات إضافية إلا بعد اعتماد التصميم النهائي.",
        "يلتزم الطرف الأول بتقديم خدمات التصميم الثلاثي الأبعاد (3D) بما يلبي كامل احتياجات الطرف الثاني، وذلك من خلال التواصل عبر الواتساب أو الاجتماعات الأون لاين وفق ما يتم الاتفاق عليه بين الطرفين.",
        "في حالة تحديد نمط التصميم واعتماده في لوحة (مودرن أو كلاسيك ...)، لا يحق للطرف الثاني تغيير النمط اثناء البدء في التصميم إلا باتفاق جديد وبرسوم إضافية يتم تحديدها من قبل الطرف الأول.",
        "يسمح بإجراء تعديلات على لوح الأفكار قبل البدء في التصميم.",
        "يسمح بإجراء تعديلات على التصميم المبدئي بحد أقصى ثلاث مرات فقط. تكون مدة تسليم التصميم الأول خلال خمسة أيام، وفي حال طلب تعديل ثاني تكون مدة تسليمه عشرة أيام، أما التعديل الثالث فمدة تسليمه خمسة عشر يوماً وأي تعديل إضافي بعد ذلك يكون برسوم مالية متفق عليها قدرها 300 ريال.",
        "في حالة اعتماد التصميم يعتبر الطرف الثاني موافق على التصميم، ولا يحق له التعديل بعد استلام المخطط التنفيذي، محادثات الواتس يعتبر إقرار من الطرف الثاني.",
        "في حال إرسال التصميم المبدئي للطرف الثاني وعدم رده خلال مدة محددة (ثلاثة أيام)، فإن أي تأخير في الرد يُحسب على مسؤولية الطرف الثاني.",
        "في حال تأخر الطرف الثاني في تزويد المكتب بالمتطلبات اللازمة (مثل المقاسات أو الصور أو أي معلومات ضرورية)، فإن مدة العقد يتم تمديدها بمقدار فترة التأخير نفسها.",
        "في حال قام الطرف الثاني بتقديم المقاسات من خلال مسّاح خاص به، فإن المكتب غير مسؤول عن أي أخطاء ناتجة عن عدم دقة هذه المقاسات.",
        "يقر الطرف الثاني بأن دور المكتب يقتصر على تسليم التصاميم المتفق عليها فقط، ولا يتحمل المكتب أي مسؤولية عن تنفيذ هذه التصاميم أو اختيار أي جهة للتنفيذ.",
        "يلتزم الطرف الاول بإرشاد الطرف الثاني وتوجيهه فيما يتعلق بالخامات والمواد المستخدمة، وتقديم المشورة حول الخيارات المناسبة وفقاً للتصميم المتفق عليه.",
        "في حال تأخر الطرف الثاني في سداد أي دفعة مستحقة في المواعيد المتفق عليها، يحق للطرف الاول إيقاف العمل مؤقتاً إلى حين استلام الدفعة.",
        "(شرط جزائي) للطرف الثاني لا يمكن الغاء العقد أو استرجاع المبلغ المحول إذا مضى على التحويل 48 ساعة.",
        "في حال تأخر الطرف الأول في تسليم التصميم في الموعد المتفق عليه دون سبب قاهر، يتم خصم 20% من قيمة العقد لصالح الطرف الثاني، وذلك تعويضاً عن التأخير.",
        "في حال حدوث أعطال تقنية خارجة عن إرادة الطرف الأول أدت إلى تأخير في التسليم، يتم إشعار الطرف الثاني بالمدة الجديدة للتسليم عن طريق الواتساب. وإذا لم يرغب الطرف الثاني في الانتظار، يحق له استرجاع المبلغ المدفوع بالكامل دون أي خصومات.",
      ];
      const results = [];
      for (let i = 0; i < defaultTerms.length; i++) {
        const term = await storage.createContractTerm({
          contractId: req.params.contractId,
          termOrder: i + 1,
          termText: defaultTerms[i],
        });
        results.push(term);
      }
      res.status(201).json(results);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Freelancer Task - send task to freelancer with project details
  app.post("/api/freelancer-tasks", async (req, res) => {
    try {
      if (!(await canManageFreelancerTasks(req))) return res.status(403).json({ error: "غير مصرح" });
      const { projectId, employeeId, workType, areaSqm, pricePerSqm, description, dueDate } = req.body;
      if (!projectId || !employeeId) return res.status(400).json({ error: "معرف المشروع والموظف مطلوبان" });

      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ error: "المشروع غير موجود" });
      const employee = (await storage.getEmployees()).find(e => e.id === employeeId);
      if (!employee) return res.status(404).json({ error: "الموظف غير موجود" });

      const workLabel = workType === "blueprints" ? "مخططات" : workType === "structural" ? "هيكل إنشائي" : "تصميم";
      const totalCost = areaSqm && pricePerSqm ? parseFloat(areaSqm) * parseFloat(pricePerSqm) : null;

      const taskTitle = `${workLabel} - ${project.title}`;
      const taskDesc = `نوع العمل: ${workLabel}\nالمشروع: ${project.title}\nالمساحة: ${areaSqm || project.areaSqm || "—"} م²\nسعر المتر: ${pricePerSqm || "—"} ر.س${totalCost ? `\nالتكلفة الإجمالية: ${totalCost.toLocaleString("ar-SA")} ر.س` : ""}${description ? `\nملاحظات: ${description}` : ""}`;

      const task = await storage.createTask({
        projectId,
        employeeId,
        title: taskTitle,
        description: taskDesc,
        priority: "high",
        status: "pending",
        dueDate: dueDate || null,
        reminderDays: 3,
        isRecurring: false,
        notes: JSON.stringify({ workType, areaSqm, pricePerSqm, totalCost, isFreelancerTask: true }),
      });

      const assignments = await storage.getAssignments(projectId);
      const existingAssign = assignments.find(a => a.employeeId === employeeId);
      if (existingAssign && totalCost) {
        await storage.updateAssignment(existingAssign.id, { assignedAmount: totalCost });
      } else if (!existingAssign) {
        await storage.createAssignment({
          projectId,
          employeeId,
          role: workLabel,
          workType: workType || null,
          assignedAmount: totalCost,
          isPaid: false,
          paidDate: null,
          notes: null,
        });
      }

      await storage.createNotification({
        type: "freelancer_task",
        title: `مهمة جديدة: ${workLabel}`,
        message: `تم تكليفك بمهمة ${workLabel} في مشروع "${project.title}" — المساحة: ${areaSqm || project.areaSqm || "—"} م²${totalCost ? ` — التكلفة: ${totalCost.toLocaleString("ar-SA")} ر.س` : ""}`,
        projectId,
        employeeId,
        amount: totalCost,
        isRead: false,
      });

      res.status(201).json(task);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Freelancer Task Approval - Hind approves, notify admin, deduct from project
  app.post("/api/freelancer-tasks/:taskId/approve", async (req, res) => {
    try {
      if (!(await canManageFreelancerTasks(req))) return res.status(403).json({ error: "غير مصرح" });
      const task = await storage.getTask(req.params.taskId);
      if (!task) return res.status(404).json({ error: "المهمة غير موجودة" });
      if (task.status === "completed") return res.status(400).json({ error: "المهمة مكتملة بالفعل" });

      const updated = await storage.updateTask(task.id, { status: "completed", completionDate: new Date().toISOString().split("T")[0] });
      if (!updated || updated.status !== "completed") return res.status(409).json({ error: "فشل تحديث حالة المهمة" });

      let taskMeta: any = {};
      try { taskMeta = task.notes ? JSON.parse(task.notes) : {}; } catch {}

      if (task.projectId && task.employeeId && taskMeta.isFreelancerTask) {
        const project = await storage.getProject(task.projectId);
        const employee = (await storage.getEmployees()).find(e => e.id === task.employeeId);
        const assignments = await storage.getAssignments(task.projectId);
        const assignment = assignments.find(a => a.employeeId === task.employeeId);

        const cost = taskMeta.totalCost || assignment?.assignedAmount || 0;
        const costAfterVat = cost / 1.15;

        if (assignment && !assignment.isPaid) {
          await storage.updateAssignment(assignment.id, {
            isPaid: true,
            paidDate: new Date().toISOString().split("T")[0],
          });
        }

        if (project && costAfterVat > 0) {
          const newTotal = Math.max(0, (project.totalValue || 0) - costAfterVat);
          await storage.updateProject(task.projectId, { totalValue: newTotal } as any);
        }

        await storage.createNotification({
          type: "freelancer_completed",
          title: `اكتمال مهمة مستقل: ${employee?.name || ""}`,
          message: `${employee?.name || ""} أنهى "${task.title}" في مشروع "${project?.title || ""}" — التكلفة: ${cost.toLocaleString("ar-SA")} ر.س (بعد الضريبة: ${costAfterVat.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")} ر.س) — تم خصمها من قيمة المشروع`,
          projectId: task.projectId,
          employeeId: null,
          amount: cost,
          isRead: false,
        });

        await storage.createNotification({
          type: "task_approved",
          title: `تمت الموافقة على مهمتك`,
          message: `تمت الموافقة على مهمة "${task.title}" في مشروع "${project?.title || ""}" — مبلغك: ${cost.toLocaleString("ar-SA")} ر.س`,
          projectId: task.projectId,
          employeeId: task.employeeId,
          amount: cost,
          isRead: false,
        });
      }

      res.json({ success: true });
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Assignments
  app.get("/api/assignments/all", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const data = await storage.getAllAssignments();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/projects/:projectId/assignments", async (req, res) => {
    try {
      const data = await storage.getAssignments(req.params.projectId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/assignments", async (req, res) => {
    try {
      if (req.user?.role !== "admin" && req.user?.role !== "interior_manager") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertAssignmentSchema.parse(req.body);
      const data = await storage.createAssignment(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/assignments/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin" && req.user?.role !== "interior_manager") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertAssignmentSchema.partial().parse(req.body);
      const data = await storage.updateAssignment(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/assignments/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin" && req.user?.role !== "interior_manager") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteAssignment(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Attendance
  app.get("/api/attendance", async (req, res) => {
    try {
      const data = await storage.getAllAttendance();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/employees/:employeeId/attendance", async (req, res) => {
    try {
      const data = await storage.getAttendance(req.params.employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/attendance", async (req, res) => {
    try {
      const parsed = insertAttendanceSchema.parse(req.body);
      const data = await storage.createAttendance(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Freelancer Rates
  app.get("/api/freelancer-rates/:employeeId", async (req, res) => {
    try {
      const data = await storage.getFreelancerRates(req.params.employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/freelancer-rates", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertFreelancerRateSchema.parse(req.body);
      const data = await storage.createFreelancerRate(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/freelancer-rates/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const data = await storage.updateFreelancerRate(req.params.id, req.body);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/freelancer-rates/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteFreelancerRate(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/freelancer-rates/calculate/:employeeId", async (req, res) => {
    try {
      const { workType, areaSqm } = req.query;
      const rates = await storage.getFreelancerRates(req.params.employeeId);
      const area = parseFloat(areaSqm as string) || 0;
      const matchingRates = rates.filter(r => r.workType === workType && area >= r.minArea && area <= r.maxArea);
      if (matchingRates.length > 0) {
        const rate = matchingRates[0];
        const cost = rate.fixedPrice || (area * rate.pricePerSqm);
        res.json({ rate: rate.pricePerSqm, fixedPrice: rate.fixedPrice, cost });
      } else {
        res.json({ rate: 0, fixedPrice: null, cost: 0 });
      }
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Salary Deductions
  app.get("/api/salary-deductions", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const month = (req.query.month as string) || new Date().toISOString().slice(0, 7);
      const data = await storage.getSalaryDeductions(month);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/salary-deductions", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertSalaryDeductionSchema.parse(req.body);
      const data = await storage.createSalaryDeduction(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/salary-deductions/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteSalaryDeduction(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Salary Bonuses (زيادات)
  app.get("/api/salary-bonuses", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const month = (req.query.month as string) || new Date().toISOString().slice(0, 7);
      const data = await storage.getSalaryBonuses(month);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/salary-bonuses", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertSalaryBonusSchema.parse(req.body);
      const data = await storage.createSalaryBonus(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/salary-bonuses/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteSalaryBonus(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // User management (admin only)
  app.get("/api/users", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const data = await storage.getUsers();
      const safeUsers = data.map(({ password, ...rest }) => rest);
      res.json(safeUsers);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/users", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const { username, password, name, role, email, employeeId } = req.body;
      if (!username || !password || !name) return res.status(400).json({ error: "الاسم واسم المستخدم وكلمة المرور مطلوبة" });
      const bcrypt = await import("bcryptjs");
      const hashed = await bcrypt.hash(password, 10);
      const user = await storage.createUser({ username, password: hashed, name, role: role || "employee", email: email || null, employeeId: employeeId || null });
      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const { employeeId, role, name, email, password } = req.body;
      const updateData: any = { employeeId, role, name, email };
      if (password) {
        const bcrypt = await import("bcryptjs");
        updateData.password = await bcrypt.hash(password, 10);
      }
      const data = await storage.updateUser(req.params.id, updateData);
      const { password: _, ...safeUser } = data;
      res.json(safeUser);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      if (req.params.id === req.user?.id) return res.status(400).json({ error: "لا يمكن حذف حسابك الخاص" });
      await storage.deleteUser(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Forgot password
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) return res.status(400).json({ error: "البريد الإلكتروني مطلوب" });
      const user = await storage.getUserByEmail(email);
      if (!user) return res.json({ success: true }); // don't reveal if email exists
      const token = crypto.randomBytes(32).toString("hex");
      const expiry = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
      await storage.updateUserResetToken(user.id, token, expiry);
      const emailConfigured = await isEmailConfigured();
      if (emailConfigured) {
        const baseUrl = `${req.protocol}://${req.get("host")}`;
        await sendPasswordResetEmail(email, user.name, token, baseUrl);
        res.json({ success: true, message: "تم إرسال رابط إعادة التعيين على بريدك الإلكتروني" });
      } else {
        res.json({ success: true, message: "لم يتم إعداد البريد الإلكتروني بعد", resetToken: token, devMode: true });
      }
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, newPassword } = req.body;
      if (!token || !newPassword) return res.status(400).json({ error: "البيانات ناقصة" });
      const allUsers = await storage.getUsers();
      const user = allUsers.find((u: any) => u.resetToken === token && u.resetTokenExpiry && new Date(u.resetTokenExpiry) > new Date());
      if (!user) return res.status(400).json({ error: "الرابط غير صالح أو منتهي الصلاحية" });
      const bcrypt = await import("bcryptjs");
      const hashed = await bcrypt.hash(newPassword, 10);
      await storage.updateUserPassword(user.id, hashed);
      res.json({ success: true, message: "تم تغيير كلمة المرور بنجاح" });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Employee-specific endpoints
  function getProjectTypeFilter(emp: any): ((p: any) => boolean) | null {
    const spec = ((emp as any).jobTitle || emp.specialty || "").toLowerCase();
    const isCustService = spec.includes("خدمة عملاء") || spec.includes("تسويق");
    if (isCustService) return null;
    const isInt = spec.includes("التصميم الداخلي") || spec.includes("مصممة داخلية") || spec.includes("مصمم داخلي") || spec.includes("مسؤولة التصميم الداخلي");
    if (isInt) return (p: any) => p.projectType === "interior";
    const isExt = spec.includes("خارجي") || spec.includes("مخطط") || spec.includes("رسم") || spec.includes("هيكل");
    if (isExt) return (p: any) => p.projectType === "exterior" || p.projectType === "facades";
    return null;
  }

  app.get("/api/my/dashboard", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.json({ totalProjects: 0, activeProjects: 0, completedProjects: 0, totalTasks: 0, pendingTasks: 0, completedTasks: 0, totalAssigned: 0, paidAmount: 0 });
      const emp = await storage.getEmployee(employeeId);
      const stats = await storage.getEmployeeDashboardStats(employeeId);
      if (emp) {
        const filter = getProjectTypeFilter(emp);
        if (filter) {
          const allProjects = await storage.getProjectsByEmployee(employeeId);
          const filtered = allProjects.filter(filter);
          stats.totalProjects = filtered.length;
          stats.activeProjects = filtered.filter((p: any) => p.status === "active").length;
          stats.completedProjects = filtered.filter((p: any) => p.status === "completed").length;
        }
      }
      res.json(stats);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/my/projects", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.json([]);
      const data = await storage.getProjectsByEmployee(employeeId);
      const emp = await storage.getEmployee(employeeId);
      if (!emp) return res.json(data);
      const filter = getProjectTypeFilter(emp);
      res.json(filter ? data.filter(filter) : data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/my/tasks", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.json([]);
      const data = await storage.getTasksByEmployee(employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/my/assignments", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.json([]);
      const data = await storage.getAssignmentsByEmployee(employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/my/attendance", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.json([]);
      const data = await storage.getAttendance(employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Employee project creation
  app.post("/api/my/projects", async (req, res) => {
    try {
      const parsed = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(parsed);

      const phasesDef = getPhasesByType(parsed.projectType);

      for (const ph of phasesDef) {
        await storage.createPhase({
          projectId: project.id, phaseName: ph.name, phaseOrder: ph.order,
          status: ph.order === 1 ? "in_progress" : "pending", timePercentage: ph.timePct,
          dueDate: null, completionDate: null, notes: null, isApproved: false,
          responsibleEmployeeId: null, responsibleRole: ph.role,
          phaseType: ph.phaseType || "work",
          paymentPercentage: (ph as any).paymentPct || null,
        });
      }

      const total = parsed.totalValue;
      const paymentCount = parsed.paymentSchedule || 3;
      let paymentDefs: { num: number; pct: number; type: string; amount: number }[] = [];
      if (paymentCount === 1) {
        paymentDefs = [{ num: 1, pct: 100, type: "دفعة كاملة عند توقيع العقد", amount: total }];
      } else if (paymentCount === 2) {
        paymentDefs = [
          { num: 1, pct: 50, type: "عند توقيع العقد", amount: total * 0.50 },
          { num: 2, pct: 50, type: "عند اعتماد التصميم", amount: total * 0.50 },
        ];
      } else {
        paymentDefs = [
          { num: 1, pct: 50, type: "عند توقيع العقد", amount: total * 0.50 },
          { num: 2, pct: 30, type: "عند اعتماد الهيكل الإنشائي وقبل المناقشة والبدء بالتصميم", amount: total * 0.30 },
          { num: 3, pct: 20, type: "بعد اعتماد التصميم وقبل البدء بالمخططات التنفيذية", amount: total * 0.20 },
        ];
      }

      for (const pd of paymentDefs) {
        await storage.createPayment({
          projectId: project.id, paymentNumber: pd.num, amount: pd.amount,
          percentage: pd.pct, paymentType: pd.type, status: "pending",
          dueDate: null, paidDate: null, notes: null,
        });
      }

      if (req.user?.employeeId) {
        await storage.createAssignment({
          projectId: project.id, employeeId: req.user.employeeId,
          role: "مسؤول المشروع", assignedAmount: null, isPaid: false,
        });
      }

      res.status(201).json(project);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Availability schedule
  app.get("/api/my/availability", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.json([]);
      const data = await storage.getAvailability(employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/my/availability", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.status(400).json({ error: "حسابك غير مرتبط بموظف" });
      const data = await storage.upsertAvailability({ ...req.body, employeeId });
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/my/availability/:id", async (req, res) => {
    try {
      await storage.deleteAvailability(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Admin view of all availability
  app.get("/api/availability", async (req, res) => {
    try {
      const data = await storage.getAllAvailability();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Employee capacity
  app.get("/api/my/capacity", async (req, res) => {
    try {
      const employeeId = req.user?.employeeId;
      if (!employeeId) return res.json({ activeProjects: 0, largeActiveProjects: 0, maxLargeProjects: 2, canTakeLargeProject: true, threshold: 300, projects: [] });
      const data = await storage.getEmployeeCapacityInfo(employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Capacity settings (admin)
  app.get("/api/capacity-settings", async (req, res) => {
    try {
      const data = await storage.getCapacitySettings();
      res.json(data || {});
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.put("/api/capacity-settings/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const data = await storage.updateCapacitySettings(req.params.id, req.body);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // AI Project Estimator
  app.post("/api/tools/estimate", async (req, res) => {
    try {
      const { areaSqm, projectType } = req.body;
      const settings = await storage.getCapacitySettings();
      const daysPerSqm = projectType === "interior"
        ? (settings?.daysPerSqmInterior || 0.15)
        : projectType === "facades"
        ? ((settings?.daysPerSqmExterior || 0.1) * 0.8)
        : (settings?.daysPerSqmExterior || 0.1);
      const basePrice = projectType === "interior"
        ? (settings?.basePriceInterior || 250)
        : projectType === "facades"
        ? Math.round((settings?.basePriceExterior || 180) * 0.85)
        : (settings?.basePriceExterior || 180);

      const estimatedDays = Math.ceil(areaSqm * daysPerSqm);
      const estimatedWeeks = Math.ceil(estimatedDays / 5);
      const estimatedMonths = Math.ceil(estimatedDays / 22);
      const totalValue = areaSqm * basePrice;

      let complexity = "بسيط";
      let recommendedTeam = 1;
      let maxConcurrent = 4;
      if (areaSqm > 500) { complexity = "معقد"; recommendedTeam = 3; maxConcurrent = 1; }
      else if (areaSqm > 300) { complexity = "متوسط"; recommendedTeam = 2; maxConcurrent = 2; }

      const sizeCategory = areaSqm > 500 ? "كبير جداً" : areaSqm > 300 ? "كبير" : areaSqm > 150 ? "متوسط" : "صغير";

      const payment1 = totalValue * 0.50;
      const payment2 = totalValue * 0.30;
      const payment3 = totalValue * 0.20;

      const phases = projectType === "interior"
        ? [
            { name: "المخطط", days: Math.ceil(estimatedDays * 0.15), percentage: 15 },
            { name: "المناقشة", days: Math.ceil(estimatedDays * 0.10), percentage: 10 },
            { name: "لوحة الأفكار", days: Math.ceil(estimatedDays * 0.20), percentage: 20 },
            { name: "التصميم", days: Math.ceil(estimatedDays * 0.30), percentage: 30 },
            { name: "المخطط التنفيذي", days: Math.ceil(estimatedDays * 0.25), percentage: 25 },
          ]
        : projectType === "facades"
        ? [
            { name: "التصميم الأولي للواجهات", days: Math.ceil(estimatedDays * 0.25), percentage: 25 },
            { name: "المناقشة والتعديلات", days: Math.ceil(estimatedDays * 0.20), percentage: 20 },
            { name: "التصميم النهائي", days: Math.ceil(estimatedDays * 0.30), percentage: 30 },
            { name: "المخططات التنفيذية", days: Math.ceil(estimatedDays * 0.25), percentage: 25 },
          ]
        : [
            { name: "الهيكل الإنشائي", days: Math.ceil(estimatedDays * 0.20), percentage: 20 },
            { name: "المناقشة", days: Math.ceil(estimatedDays * 0.15), percentage: 15 },
            { name: "التصميم", days: Math.ceil(estimatedDays * 0.35), percentage: 35 },
            { name: "المخططات التنفيذية", days: Math.ceil(estimatedDays * 0.30), percentage: 30 },
          ];

      res.json({
        areaSqm,
        projectType,
        sizeCategory,
        complexity,
        estimatedDays,
        estimatedWeeks,
        estimatedMonths,
        recommendedTeam,
        maxConcurrent,
        totalValue,
        pricePerSqm: basePrice,
        payments: { first: payment1, second: payment2, third: payment3 },
        phases,
      });
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  // Field Visits
  app.get("/api/projects/:projectId/visits", async (req, res) => {
    try {
      const data = await storage.getFieldVisits(req.params.projectId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/visits", async (req, res) => {
    try {
      const parsed = insertFieldVisitSchema.parse(req.body);
      const data = await storage.createFieldVisit(parsed);

      if (parsed.employeeId) {
        const project = await storage.getProject(parsed.projectId);
        await storage.createNotification({
          type: "field_visit",
          title: "زيارة ميدانية جديدة",
          message: `تم تعيينك لزيارة ميدانية للمشروع "${project?.title || ""}" بتاريخ ${parsed.visitDate}${parsed.purpose ? " - " + parsed.purpose : ""}`,
          projectId: parsed.projectId,
          employeeId: parsed.employeeId,
          amount: null,
          isRead: false,
        });
      }

      const projectPayments = await storage.getPayments(parsed.projectId);
      const firstPayment = projectPayments.find(p => p.paymentNumber === 1);
      if (firstPayment && firstPayment.status === "paid") {
        const phases = await storage.getProjectPhases(parsed.projectId);
        const hasVisitPhase = phases.some(p => p.phaseName === "زيارة ميدانية" && p.notes === data.id);
        if (!hasVisitPhase) {
          const firstPaymentPhase = phases.find(p => (p as any).phaseType === "financial" && p.phaseOrder <= 2);
          const insertOrder = firstPaymentPhase ? firstPaymentPhase.phaseOrder + 1 : 2;
          const existingAtOrder = phases.filter(p => p.phaseOrder >= insertOrder);
          for (const ep of existingAtOrder) {
            await storage.updatePhase(ep.id, { phaseOrder: ep.phaseOrder + 1 });
          }
          await storage.createPhase({
            projectId: parsed.projectId,
            phaseName: "زيارة ميدانية",
            phaseOrder: insertOrder,
            status: "pending",
            dueDate: parsed.visitDate,
            notes: data.id,
            phaseType: "work",
            timePercentage: null,
            completionDate: null,
            isApproved: false,
            responsibleEmployeeId: parsed.employeeId || null,
            responsibleRole: null,
            paymentPercentage: null,
          });
        }
      }

      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/visits/:id", async (req, res) => {
    try {
      const parsed = insertFieldVisitSchema.partial().parse(req.body);
      const data = await storage.updateFieldVisit(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/visits/:id", async (req, res) => {
    try {
      await storage.deleteFieldVisit(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Project Files
  app.get("/api/projects/:projectId/files", async (req, res) => {
    try {
      const data = await storage.getProjectFiles(req.params.projectId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/files", async (req, res) => {
    try {
      const parsed = insertProjectFileSchema.parse(req.body);
      const data = await storage.createProjectFile(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      await storage.deleteProjectFile(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // File upload endpoint (multipart)
  app.post("/api/upload", upload.single("file"), (req, res) => {
    try {
      if (!req.file) return res.status(400).json({ error: "لم يتم إرسال أي ملف" });
      const fileUrl = `/uploads/${req.file.filename}`;
      res.json({ url: fileUrl, fileName: req.file.originalname, fileType: req.file.mimetype });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Marketing Contacts (admin only)
  app.get("/api/marketing-contacts", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const data = await storage.getMarketingContacts();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/marketing-contacts/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const data = await storage.getMarketingContact(req.params.id);
      if (!data) return res.status(404).json({ error: "Not found" });
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/marketing-contacts", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertMarketingContactSchema.parse(req.body);
      const data = await storage.createMarketingContact(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/marketing-contacts/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertMarketingContactSchema.partial().parse(req.body);
      const data = await storage.updateMarketingContact(req.params.id, parsed);
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/marketing-contacts/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteMarketingContact(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/notifications", async (req, res) => {
    try {
      const employeeId = req.user?.role === "admin" ? undefined : req.user?.employeeId || undefined;
      const data = await storage.getNotifications(employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/notifications/unread", async (req, res) => {
    try {
      const employeeId = req.user?.role === "admin" ? undefined : req.user?.employeeId || undefined;
      const data = await storage.getUnreadNotifications(employeeId);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.put("/api/notifications/:id/read", async (req, res) => {
    try {
      const data = await storage.markNotificationRead(req.params.id);
      if (!data) return res.status(404).json({ error: "التنبيه غير موجود" });
      res.json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/notifications/read-all", async (req, res) => {
    try {
      const employeeId = req.user?.role === "admin" ? undefined : req.user?.employeeId || undefined;
      await storage.markAllNotificationsRead(employeeId);
      res.json({ success: true });
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.get("/api/salaries/monthly", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const month = (req.query.month as string) || new Date().toISOString().slice(0, 7);
      const [year, mon] = month.split("-").map(Number);
      const monthStart = new Date(year, mon - 1, 1);
      const monthEnd = new Date(year, mon, 0);

      const allEmployees = await storage.getEmployees();
      const allProjects = await storage.getProjects();
      const allPayments = await storage.getAllPayments();
      const allClients = await storage.getClients();
      const allAssignments = await Promise.all(allProjects.map(p => storage.getAssignments(p.id)));
      const allAttendance = await storage.getAllAttendance();
      const monthDeductions = await storage.getSalaryDeductions(month);
      const monthBonuses = await storage.getSalaryBonuses(month);

      const salaries = allEmployees.filter(e => e.isActive).map(emp => {
        const baseSalary = (emp as any).baseSalary || 0;
        const isFreelancer = emp.employeeType === "freelancer";

        const empAbsences = allAttendance.filter(a =>
          a.employeeId === emp.id && a.status === "absent" &&
          a.date >= month + "-01" && a.date <= month + "-31"
        );
        const absenceCount = empAbsences.length;
        const dailyRate = baseSalary > 0 ? baseSalary / 30 : 0;
        const absenceDeduction = Math.round(absenceCount * dailyRate);

        const manualDeductions = monthDeductions.filter(d => d.employeeId === emp.id);
        const totalManualDeductions = manualDeductions.reduce((s, d) => s + d.amount, 0);
        const manualBonuses = monthBonuses.filter(b => b.employeeId === emp.id);
        const totalManualBonuses = manualBonuses.reduce((s, b) => s + b.amount, 0);
        const commissions: {
          projectId: string; projectTitle: string; clientName: string;
          designType: string; contractArea: number; pricePerSqm: number;
          totalExecutedArea: number; totalContractValue: number;
          designExpense: number;
          designCommission: number; executiveCommission: number; structuralCommission: number;
          percentage: number; amount: number; role: string; paymentLabel: string;
          workType?: string;
        }[] = [];

        allProjects.forEach((project, idx) => {
          const assignments = allAssignments[idx];
          const assignment = assignments.find(a => a.employeeId === emp.id);
          if (!assignment) return;

          const client = allClients.find(c => c.id === project.clientId);

          if (isFreelancer && assignment.assignedAmount) {
            const paidDate = assignment.paidDate ? new Date(assignment.paidDate) : null;
            const paidInMonth = assignment.isPaid && paidDate && paidDate >= monthStart && paidDate <= monthEnd;
            commissions.push({
              projectId: project.id,
              projectTitle: project.title,
              clientName: client?.name || "",
              designType: project.projectType === "interior" ? "تصميم داخلي" : project.projectType === "exterior" ? "تصميم خارجي" : "واجهات",
              contractArea: project.areaSqm || 0,
              pricePerSqm: project.pricePerSqm || 0,
              totalExecutedArea: project.areaSqm || 0,
              totalContractValue: project.totalValue,
              designExpense: assignment.assignedAmount,
              designCommission: 0, executiveCommission: 0, structuralCommission: 0,
              percentage: assignment.assignedAmount && project.totalValue > 0
                ? Math.round((assignment.assignedAmount / project.totalValue) * 100 * 100) / 100
                : 0,
              amount: paidInMonth ? assignment.assignedAmount : 0,
              role: assignment.role || "",
              paymentLabel: (assignment as any).workType === "blueprints" ? "مخططات" : (assignment as any).workType === "structural" ? "هيكل إنشائي" : "تصميم",
              workType: (assignment as any).workType || "design",
              isPaid: assignment.isPaid || false,
              paidDate: assignment.paidDate || null,
              assignedAmount: assignment.assignedAmount,
            });
            return;
          }

          const projectPayments = allPayments.filter(p => p.projectId === project.id && p.status === "paid" && p.paidDate);
          const designPct = (emp as any).designPercentage || 0;
          const execPct = (emp as any).executivePercentage || 0;
          const structPct = (emp as any).structuralPercentage || 0;
          const totalPct = designPct + execPct + structPct;
          if (totalPct === 0) return;

          for (const payment of projectPayments) {
            const paidDate = new Date(payment.paidDate!);
            if (paidDate < monthStart || paidDate > monthEnd) continue;

            const netAfterVat = payment.amount / 1.15;
            const designComm = (netAfterVat * designPct) / 100;
            const execComm = (netAfterVat * execPct) / 100;
            const structComm = (netAfterVat * structPct) / 100;
            const commissionAmount = designComm + execComm + structComm;

            commissions.push({
              projectId: project.id,
              projectTitle: project.title,
              clientName: client?.name || "",
              designType: project.projectType === "interior" ? "تصميم داخلي" : project.projectType === "exterior" ? "تصميم خارجي" : "واجهات",
              contractArea: project.areaSqm || 0,
              pricePerSqm: project.pricePerSqm || 0,
              totalExecutedArea: project.areaSqm || 0,
              totalContractValue: project.totalValue,
              designExpense: 0,
              designCommission: designComm,
              executiveCommission: execComm,
              structuralCommission: structComm,
              percentage: totalPct,
              amount: commissionAmount,
              role: assignments.find(a => a.employeeId === emp.id)?.role || "",
              paymentLabel: `دفعة ${payment.paymentNumber} (${payment.percentage}%)`,
            });
          }
        });

        const totalCommission = commissions.reduce((s, c) => s + c.amount, 0);
        const totalDeductions = absenceDeduction + totalManualDeductions;
        return {
          employeeId: emp.id,
          employeeName: emp.name,
          employeeType: emp.employeeType,
          jobTitle: (emp as any).jobTitle || emp.specialty,
          baseSalary,
          designPercentage: (emp as any).designPercentage || 0,
          executivePercentage: (emp as any).executivePercentage || 0,
          structuralPercentage: (emp as any).structuralPercentage || 0,
          commissions,
          totalCommission,
          absenceCount,
          absenceDeduction,
          manualDeductions: manualDeductions.map(d => ({ id: d.id, amount: d.amount, reason: d.reason })),
          totalManualDeductions,
          manualBonuses: manualBonuses.map(b => ({ id: b.id, amount: b.amount, reason: b.reason })),
          totalManualBonuses,
          totalDeductions,
          totalSalary: baseSalary + totalCommission + totalManualBonuses - totalDeductions,
          bankAccount: (emp as any).bankAccount || null,
        };
      });

      const totalPayroll = salaries.reduce((s, e) => s + e.totalSalary, 0);
      res.json({ month, salaries, totalPayroll });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/finance/commitments", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const month = req.query.month as string | undefined;
      const data = await storage.getFinancialCommitments(month);
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/finance/commitments", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const parsed = insertFinancialCommitmentSchema.parse(req.body);
      const data = await storage.createFinancialCommitment(parsed);
      res.status(201).json(data);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/finance/commitments/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deleteFinancialCommitment(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/finance/summary", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const allPayments = await storage.getAllPayments();
      const allProjects = await storage.getProjects();
      const allEmployees = await storage.getEmployees();

      const paidPayments = allPayments.filter(p => p.status === "paid");
      const totalRevenue = paidPayments.reduce((s, p) => s + p.amount, 0);
      const totalVat = totalRevenue - (totalRevenue / 1.15);
      const revenueAfterVat = totalRevenue / 1.15;

      const totalBaseSalaries = allEmployees.filter(e => e.isActive).reduce((s, e) => s + ((e as any).baseSalary || 0), 0);

      let totalCommissions = 0;
      const allAssignments = await Promise.all(allProjects.map(p => storage.getAssignments(p.id)));
      allEmployees.filter(e => e.isActive).forEach(emp => {
        const designPct = (emp as any).designPercentage || 0;
        const execPct = (emp as any).executivePercentage || 0;
        const structPct = (emp as any).structuralPercentage || 0;
        const totalPct = designPct + execPct + structPct;
        if (totalPct === 0) return;

        allProjects.forEach((project, idx) => {
          const assignments = allAssignments[idx];
          if (!assignments.some(a => a.employeeId === emp.id)) return;

          const projectPaidPayments = paidPayments.filter(p => p.projectId === project.id);
          for (const payment of projectPaidPayments) {
            const netAfterVat = payment.amount / 1.15;
            totalCommissions += (netAfterVat * totalPct) / 100;
          }
        });
      });

      const commitments = await storage.getFinancialCommitments();
      const totalManualCommitments = commitments.reduce((s, c) => s + c.amount, 0);

      res.json({
        totalRevenue,
        totalVat,
        revenueAfterVat,
        totalBaseSalaries,
        totalCommissions,
        totalManualCommitments,
        netProfit: revenueAfterVat - totalBaseSalaries - totalCommissions - totalManualCommitments,
        commitments,
      });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/employee-workload", async (req, res) => {
    try {
      if (req.user?.role !== "admin" && req.user?.role !== "interior_manager") return res.status(403).json({ error: "غير مصرح" });
      const allEmployees = await storage.getEmployees();
      const allProjects = await storage.getProjects();
      const allAssignments = await Promise.all(allProjects.map(p => storage.getAssignments(p.id)));
      const allClients = await storage.getClients();

      const workload = allEmployees.filter(e => e.isActive).map(emp => {
        const assignedProjects: any[] = [];
        allProjects.forEach((project, idx) => {
          const assignments = allAssignments[idx];
          const assignment = assignments.find(a => a.employeeId === emp.id);
          if (!assignment) return;
          const client = allClients.find(c => c.id === project.clientId);
          const today = new Date();
          const endDate = project.endDate ? new Date(project.endDate) : null;
          const remainingDays = endDate ? Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)) : null;

          assignedProjects.push({
            projectId: project.id,
            projectTitle: project.title,
            clientName: client?.name || "",
            projectType: project.projectType,
            status: project.status,
            startDate: project.startDate,
            endDate: project.endDate,
            executionDays: project.executionDays,
            remainingDays,
            areaSqm: project.areaSqm,
            totalValue: project.totalValue,
            role: assignment.role,
            workType: (assignment as any).workType,
            assignedAmount: assignment.assignedAmount,
            isPaid: assignment.isPaid,
          });
        });

        return {
          employeeId: emp.id,
          employeeName: emp.name,
          employeeType: emp.employeeType,
          jobTitle: (emp as any).jobTitle || emp.specialty,
          specialty: emp.specialty,
          activeProjects: assignedProjects.filter(p => p.status === "active").length,
          totalProjects: assignedProjects.length,
          projects: assignedProjects,
        };
      });

      res.json(workload);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Partners (الشركاء)
  app.get("/api/partners", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const data = await storage.getPartners();
      res.json(data);
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.post("/api/partners", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const { insertPartnerSchema } = await import("@shared/schema");
      const data = insertPartnerSchema.parse(req.body);
      const partner = await storage.createPartner(data);
      res.status(201).json(partner);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.put("/api/partners/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const { insertPartnerSchema } = await import("@shared/schema");
      const data = insertPartnerSchema.partial().parse(req.body);
      const partner = await storage.updatePartner(req.params.id, data);
      res.json(partner);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  app.delete("/api/partners/:id", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      await storage.deletePartner(req.params.id);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // Financial Reports
  // Monthly Financial Report (for partners - shows monthly net profit breakdown)
  app.get("/api/reports/financial/monthly", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const month = (req.query.month as string) || new Date().toISOString().slice(0, 7);
      const [year, mon] = month.split("-").map(Number);
      const monthStart = new Date(year, mon - 1, 1);
      const monthEnd = new Date(year, mon, 0, 23, 59, 59);

      const allPayments = await storage.getAllPayments();
      const allProjects = await storage.getProjects();
      const allEmployees = await storage.getEmployees();
      const allClients = await storage.getClients();
      const allCommitments = await storage.getFinancialCommitments();
      const partnersList = await storage.getPartners();
      const allAssignments = await Promise.all(allProjects.map(p => storage.getAssignments(p.id)));
      const monthDeductions = await storage.getSalaryDeductions(month);
      const monthBonuses = await storage.getSalaryBonuses(month);

      // Monthly revenue: payments paid in this month
      const monthPaidPayments = allPayments.filter(p => {
        if (p.status !== "paid" || !p.paidDate) return false;
        const pd = new Date(p.paidDate);
        return pd >= monthStart && pd <= monthEnd;
      });

      // Projects with revenue this month
      const monthProjects: any[] = [];
      allProjects.forEach((project, idx) => {
        const projectPaid = monthPaidPayments.filter(p => p.projectId === project.id);
        if (projectPaid.length === 0) return;
        const client = allClients.find(c => c.id === project.clientId);
        const assignments = allAssignments[idx];
        const revenue = projectPaid.reduce((s, p) => s + p.amount, 0);
        const netAfterVat = revenue / 1.15;
        const vatAmount = revenue - netAfterVat;

        // Calculate commissions per employee for this project
        const employeeCommissions: any[] = [];
        allEmployees.filter(e => e.isActive && e.employeeType === "internal").forEach(emp => {
          const assigned = assignments.find(a => a.employeeId === emp.id);
          if (!assigned) return;
          const designPct = (emp as any).designPercentage || 0;
          const execPct = (emp as any).executivePercentage || 0;
          const structPct = (emp as any).structuralPercentage || 0;
          const totalPct = designPct + execPct + structPct;
          if (totalPct === 0) return;
          const commAmount = (netAfterVat * totalPct) / 100;
          employeeCommissions.push({ name: emp.name, percentage: totalPct, amount: commAmount });
        });

        monthProjects.push({
          id: project.id, title: project.title,
          clientName: client?.name || "",
          type: project.projectType,
          totalValue: project.totalValue,
          monthRevenue: revenue,
          netAfterVat,
          vatAmount,
          payments: projectPaid.map(p => ({ paymentNumber: p.paymentNumber, amount: p.amount, percentage: p.percentage, paidDate: p.paidDate })),
          employeeCommissions,
          area: project.areaSqm || 0,
          pricePerSqm: project.pricePerSqm || 0,
        });
      });

      const totalRevenue = monthPaidPayments.reduce((s, p) => s + p.amount, 0);
      const vatAmount = totalRevenue - totalRevenue / 1.15;
      const revenueAfterVat = totalRevenue / 1.15;

      // Monthly base salaries (fixed monthly cost for active internal employees)
      const internalEmployees = allEmployees.filter(e => e.isActive && e.employeeType === "internal");
      const baseSalaries = internalEmployees.map(emp => {
        const base = (emp as any).baseSalary || 0;
        const empDeductions = monthDeductions.filter(d => d.employeeId === emp.id);
        const empBonuses = monthBonuses.filter(b => b.employeeId === emp.id);
        const totalDeductions = empDeductions.reduce((s, d) => s + d.amount, 0);
        const totalBonuses = empBonuses.reduce((s, b) => s + b.amount, 0);
        return {
          name: emp.name,
          jobTitle: (emp as any).jobTitle || emp.specialty || "",
          baseSalary: base,
          bonuses: totalBonuses,
          deductions: totalDeductions,
          net: base + totalBonuses - totalDeductions,
        };
      });
      const totalBaseSalaries = baseSalaries.reduce((s, e) => s + e.net, 0);

      // Monthly commissions (from payments paid this month)
      let totalCommissions = 0;
      internalEmployees.forEach(emp => {
        const designPct = (emp as any).designPercentage || 0;
        const execPct = (emp as any).executivePercentage || 0;
        const structPct = (emp as any).structuralPercentage || 0;
        const totalPct = designPct + execPct + structPct;
        if (totalPct === 0) return;
        allProjects.forEach((project, idx) => {
          if (!allAssignments[idx].some(a => a.employeeId === emp.id)) return;
          monthPaidPayments.filter(p => p.projectId === project.id).forEach(payment => {
            totalCommissions += ((payment.amount / 1.15) * totalPct) / 100;
          });
        });
      });

      // Monthly freelancer costs with breakdown
      const monthFreelancerAssignments = allAssignments.flat().filter(a => {
        const emp = allEmployees.find(e => e.id === a.employeeId);
        if (emp?.employeeType !== "freelancer" || !a.isPaid || !a.paidDate) return false;
        const pd = new Date(a.paidDate);
        return pd >= monthStart && pd <= monthEnd;
      });
      const monthFreelancerCosts = monthFreelancerAssignments.reduce((s, a) => s + (a.assignedAmount || 0), 0);
      const freelancerCostsBreakdown = monthFreelancerAssignments.map(a => {
        const emp = allEmployees.find(e => e.id === a.employeeId);
        const project = allProjects.find(p => p.id === a.projectId);
        const client = allClients.find(c => c.id === project?.clientId);
        return {
          name: emp?.name || "—",
          projectTitle: client?.name || project?.title || "—",
          role: a.role || (a as any).workType || "—",
          amount: a.assignedAmount || 0,
        };
      });

      // Monthly commitments (those with this month)
      const monthlyCommitments = allCommitments.filter(c => (c as any).month === month || !((c as any).month));
      const totalCommitmentsAmount = monthlyCommitments.reduce((s, c) => s + c.amount, 0);

      const netProfit = revenueAfterVat - totalBaseSalaries - totalCommissions - monthFreelancerCosts - totalCommitmentsAmount;

      // Partners: مها and سمر get their %, محمد البلوي gets the rest
      const activePartners = partnersList.filter(p => p.isActive);
      const namedPartnersTotal = activePartners.reduce((s, p) => s + p.profitPercentage, 0);
      const mohammedShare = Math.max(0, netProfit > 0 ? netProfit * (100 - namedPartnersTotal) / 100 : 0);

      const partnersSummary = [
        ...activePartners.map(p => ({
          id: p.id,
          name: p.name,
          percentage: p.profitPercentage,
          shareAmount: netProfit > 0 ? (netProfit * p.profitPercentage) / 100 : 0,
          isMohammed: false,
        })),
        {
          id: "mohammed",
          name: "محمد البلوي",
          percentage: 100 - namedPartnersTotal,
          shareAmount: mohammedShare,
          isMohammed: true,
        },
      ];

      res.json({
        month,
        totalRevenue,
        vatAmount,
        revenueAfterVat,
        monthProjects,
        expenses: {
          baseSalaries: totalBaseSalaries,
          baseSalariesBreakdown: baseSalaries,
          commissions: totalCommissions,
          freelancerCosts: monthFreelancerCosts,
          freelancerCostsBreakdown,
          commitments: totalCommitmentsAmount,
          commitmentDetails: monthlyCommitments,
          total: totalBaseSalaries + totalCommissions + monthFreelancerCosts + totalCommitmentsAmount,
        },
        netProfit,
        partnersSummary,
      });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  app.get("/api/reports/financial", async (req, res) => {
    try {
      if (req.user?.role !== "admin") return res.status(403).json({ error: "غير مصرح" });
      const allPayments = await storage.getAllPayments();
      const allProjects = await storage.getProjects();
      const allEmployees = await storage.getEmployees();
      const allClients = await storage.getClients();
      const allCommitments = await storage.getFinancialCommitments();
      const partnersList = await storage.getPartners();
      const allAssignments = await Promise.all(allProjects.map(p => storage.getAssignments(p.id)));

      const paidPayments = allPayments.filter(p => p.status === "paid");

      // Revenue by project type
      const revenueByType = { interior: 0, exterior: 0, facades: 0 };
      const projectsByType: Record<string, any[]> = { interior: [], exterior: [], facades: [] };

      allProjects.forEach((project, idx) => {
        const projectPaid = paidPayments.filter(p => p.projectId === project.id);
        const projectRevenue = projectPaid.reduce((s, p) => s + p.amount, 0);
        const client = allClients.find(c => c.id === project.clientId);
        const assignments = allAssignments[idx];
        const freelancerCosts = assignments
          .filter(a => {
            const emp = allEmployees.find(e => e.id === a.employeeId);
            return emp?.employeeType === "freelancer" && a.isPaid && a.assignedAmount;
          })
          .reduce((s, a) => s + (a.assignedAmount || 0), 0);

        if (projectRevenue > 0 || project.totalValue > 0) {
          const projectData = {
            id: project.id,
            title: project.title,
            clientName: client?.name || "",
            type: project.projectType,
            totalValue: project.totalValue,
            paidRevenue: projectRevenue,
            pendingRevenue: project.totalValue - projectRevenue,
            freelancerCosts,
            status: project.status,
            endDate: project.endDate,
          };
          if (project.projectType in revenueByType) {
            revenueByType[project.projectType as keyof typeof revenueByType] += projectRevenue;
            projectsByType[project.projectType].push(projectData);
          }
        }
      });

      const totalRevenue = paidPayments.reduce((s, p) => s + p.amount, 0);
      const totalVat = totalRevenue - totalRevenue / 1.15;
      const revenueAfterVat = totalRevenue / 1.15;

      // Expenses breakdown
      const totalBaseSalaries = allEmployees.filter(e => e.isActive && e.employeeType === "internal").reduce((s, e) => s + ((e as any).baseSalary || 0), 0);
      const totalFreelancerCosts = allAssignments.flat()
        .filter(a => {
          const emp = allEmployees.find(e => e.id === a.employeeId);
          return emp?.employeeType === "freelancer" && a.isPaid;
        })
        .reduce((s, a) => s + (a.assignedAmount || 0), 0);

      let totalCommissions = 0;
      allEmployees.filter(e => e.isActive && e.employeeType === "internal").forEach(emp => {
        const designPct = (emp as any).designPercentage || 0;
        const execPct = (emp as any).executivePercentage || 0;
        const structPct = (emp as any).structuralPercentage || 0;
        const totalPct = designPct + execPct + structPct;
        if (totalPct === 0) return;
        allProjects.forEach((project, idx) => {
          if (!allAssignments[idx].some(a => a.employeeId === emp.id)) return;
          paidPayments.filter(p => p.projectId === project.id).forEach(payment => {
            const netAfterVat = payment.amount / 1.15;
            totalCommissions += (netAfterVat * totalPct) / 100;
          });
        });
      });

      const totalCommitmentsAmount = allCommitments.reduce((s, c) => s + c.amount, 0);
      const netProfit = revenueAfterVat - totalBaseSalaries - totalCommissions - totalFreelancerCosts - totalCommitmentsAmount;

      // Partners share
      const partnersSummary = partnersList.filter(p => p.isActive).map(partner => ({
        ...partner,
        shareAmount: netProfit > 0 ? (netProfit * partner.profitPercentage) / 100 : 0,
        netProfit,
      }));

      res.json({
        totalRevenue, totalVat, revenueAfterVat,
        revenueByType, projectsByType,
        expenses: {
          baseSalaries: totalBaseSalaries,
          commissions: totalCommissions,
          freelancerCosts: totalFreelancerCosts,
          commitments: totalCommitmentsAmount,
          commitmentDetails: allCommitments,
          total: totalBaseSalaries + totalCommissions + totalFreelancerCosts + totalCommitmentsAmount,
        },
        netProfit,
        partnersSummary,
      });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  return httpServer;
}
