import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: false,
  auth: {
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
  },
  tls: { rejectUnauthorized: false },
});

export async function sendPasswordResetEmail(toEmail: string, toName: string, resetToken: string, baseUrl: string) {
  const resetLink = `${baseUrl}/reset-password?token=${resetToken}`;

  const html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head><meta charset="UTF-8"><style>
  body { font-family: 'IBM Plex Sans Arabic', Tahoma, sans-serif; background: #f8fafc; margin: 0; padding: 20px; direction: rtl; }
  .container { max-width: 500px; margin: auto; background: #fff; border-radius: 12px; padding: 32px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
  .header { text-align: center; margin-bottom: 24px; }
  .header h1 { color: #1e3a8a; font-size: 20px; margin: 0; }
  .header p { color: #6b7280; font-size: 13px; margin: 4px 0 0; }
  .btn { display: block; width: fit-content; margin: 24px auto; background: #2563EB; color: #fff; text-decoration: none; padding: 12px 28px; border-radius: 8px; font-size: 16px; font-weight: 600; }
  .note { color: #9ca3af; font-size: 12px; text-align: center; margin-top: 16px; }
</style></head>
<body>
<div class="container">
  <div class="header">
    <h1>مؤسسة محمد البلوي</h1>
    <p>للتصميم الداخلي والخارجي</p>
  </div>
  <p>السلام عليكم ${toName}،</p>
  <p>تلقينا طلباً لإعادة تعيين كلمة المرور لحسابك. انقر على الزر أدناه لإتمام العملية:</p>
  <a href="${resetLink}" class="btn">إعادة تعيين كلمة المرور</a>
  <p class="note">هذا الرابط صالح لمدة ساعة واحدة. إذا لم تطلب إعادة التعيين، تجاهل هذا البريد.</p>
  <p class="note">إذا لم يعمل الزر، انسخ الرابط التالي:<br>${resetLink}</p>
</div>
</body>
</html>`;

  await transporter.sendMail({
    from: `"مؤسسة محمد البلوي" <${process.env.SMTP_USER}>`,
    to: toEmail,
    subject: "إعادة تعيين كلمة المرور — مؤسسة محمد البلوي",
    html,
  });
}

export async function isEmailConfigured(): Promise<boolean> {
  return !!(process.env.SMTP_USER && process.env.SMTP_PASS);
}
