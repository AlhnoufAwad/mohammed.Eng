import { drizzle } from "drizzle-orm/node-postgres";
import { eq, desc, and, sql } from "drizzle-orm";
import pg from "pg";
import {
  users, clients, projects, projectPhases, payments, employees, tasks, contracts, employeeAssignments, attendance,
  availabilitySchedule, capacitySettings, fieldVisits, projectFiles, marketingContacts, notifications, financialCommitments,
  freelancerRates, salaryDeductions, salaryBonuses, partners,
  type User, type InsertUser,
  type Client, type InsertClient,
  type Project, type InsertProject,
  type ProjectPhase, type InsertPhase,
  type Payment, type InsertPayment,
  type Employee, type InsertEmployee,
  type Task, type InsertTask,
  type Contract, type InsertContract,
  type EmployeeAssignment, type InsertAssignment,
  type Attendance, type InsertAttendance,
  type AvailabilityScheduleType, type InsertAvailability,
  type CapacitySettingsType, type InsertCapacitySettings,
  type FieldVisit, type InsertFieldVisit,
  type ProjectFile, type InsertProjectFile,
  type MarketingContact, type InsertMarketingContact,
  type Notification, type InsertNotification,
  type ContractTerm, type InsertContractTerm,
  type FreelancerRate, type InsertFreelancerRate,
  type SalaryDeduction, type InsertSalaryDeduction,
  type SalaryBonus, type InsertSalaryBonus,
  type Partner, type InsertPartner,
  contractTerms,
} from "@shared/schema";
import { randomUUID } from "crypto";

const { Pool } = pg;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  updateUserResetToken(id: string, token: string | null, expiry: Date | null): Promise<void>;
  updateUserPassword(id: string, hashedPassword: string): Promise<void>;
  deleteUser(id: string): Promise<void>;

  getClients(): Promise<Client[]>;
  getClient(id: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: string, client: Partial<InsertClient>): Promise<Client>;
  deleteClient(id: string): Promise<void>;

  getProjects(): Promise<Project[]>;
  getProjectsByClient(clientId: string): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: string): Promise<void>;

  getProjectPhases(projectId: string): Promise<ProjectPhase[]>;
  getPhaseById(id: string): Promise<ProjectPhase | undefined>;
  createPhase(phase: InsertPhase): Promise<ProjectPhase>;
  updatePhase(id: string, phase: Partial<InsertPhase>): Promise<ProjectPhase>;

  getPayments(projectId: string): Promise<Payment[]>;
  getAllPayments(): Promise<Payment[]>;
  getPaymentById(id: string): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: string, payment: Partial<InsertPayment>): Promise<Payment>;

  getEmployees(): Promise<Employee[]>;
  getEmployee(id: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: string, employee: Partial<InsertEmployee>): Promise<Employee>;
  deleteEmployee(id: string): Promise<void>;

  getTasks(): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  getTasksByProject(projectId: string): Promise<Task[]>;
  getTasksByEmployee(employeeId: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task>;
  deleteTask(id: string): Promise<void>;

  getContracts(): Promise<Contract[]>;
  getContract(projectId: string): Promise<Contract | undefined>;
  createContract(contract: InsertContract): Promise<Contract>;
  updateContract(id: string, contract: Partial<InsertContract>): Promise<Contract>;

  getContractTerms(contractId: string): Promise<ContractTerm[]>;
  createContractTerm(term: InsertContractTerm): Promise<ContractTerm>;
  updateContractTerm(id: string, data: Partial<InsertContractTerm>): Promise<ContractTerm>;
  deleteContractTerm(id: string): Promise<void>;

  getAllAssignments(): Promise<EmployeeAssignment[]>;
  getAssignments(projectId: string): Promise<EmployeeAssignment[]>;
  createAssignment(assignment: InsertAssignment): Promise<EmployeeAssignment>;
  updateAssignment(id: string, assignment: Partial<InsertAssignment>): Promise<EmployeeAssignment>;
  deleteAssignment(id: string): Promise<void>;

  getAttendance(employeeId: string): Promise<Attendance[]>;
  getAllAttendance(): Promise<Attendance[]>;
  createAttendance(att: InsertAttendance): Promise<Attendance>;

  getDashboardStats(): Promise<any>;

  getUsers(): Promise<User[]>;
  updateUser(id: string, data: Partial<any>): Promise<User>;
  getProjectsByEmployee(employeeId: string): Promise<Project[]>;
  getAssignmentsByEmployee(employeeId: string): Promise<EmployeeAssignment[]>;
  getEmployeeDashboardStats(employeeId: string): Promise<any>;

  getAvailability(employeeId: string): Promise<AvailabilityScheduleType[]>;
  getAllAvailability(): Promise<AvailabilityScheduleType[]>;
  upsertAvailability(data: InsertAvailability): Promise<AvailabilityScheduleType>;
  deleteAvailability(id: string): Promise<void>;
  getCapacitySettings(): Promise<CapacitySettingsType | undefined>;
  updateCapacitySettings(id: string, data: Partial<InsertCapacitySettings>): Promise<CapacitySettingsType>;
  getEmployeeCapacityInfo(employeeId: string): Promise<any>;

  getFieldVisits(projectId: string): Promise<FieldVisit[]>;
  createFieldVisit(visit: InsertFieldVisit): Promise<FieldVisit>;
  updateFieldVisit(id: string, visit: Partial<InsertFieldVisit>): Promise<FieldVisit>;
  deleteFieldVisit(id: string): Promise<void>;

  getProjectFiles(projectId: string): Promise<ProjectFile[]>;
  createProjectFile(file: InsertProjectFile): Promise<ProjectFile>;
  deleteProjectFile(id: string): Promise<void>;

  getMarketingContacts(): Promise<MarketingContact[]>;
  getMarketingContact(id: string): Promise<MarketingContact | undefined>;
  createMarketingContact(contact: InsertMarketingContact): Promise<MarketingContact>;
  updateMarketingContact(id: string, contact: Partial<InsertMarketingContact>): Promise<MarketingContact>;
  deleteMarketingContact(id: string): Promise<void>;

  getNotifications(employeeId?: string): Promise<Notification[]>;
  getUnreadNotifications(employeeId?: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<Notification>;
  markAllNotificationsRead(employeeId?: string): Promise<void>;

  getFinancialCommitments(month?: string): Promise<any[]>;
  createFinancialCommitment(commitment: any): Promise<any>;
  deleteFinancialCommitment(id: string): Promise<void>;

  getFreelancerRates(employeeId: string): Promise<FreelancerRate[]>;
  createFreelancerRate(rate: InsertFreelancerRate): Promise<FreelancerRate>;
  updateFreelancerRate(id: string, data: Partial<InsertFreelancerRate>): Promise<FreelancerRate>;
  deleteFreelancerRate(id: string): Promise<void>;

  getSalaryDeductions(month: string): Promise<SalaryDeduction[]>;
  createSalaryDeduction(deduction: InsertSalaryDeduction): Promise<SalaryDeduction>;
  deleteSalaryDeduction(id: string): Promise<void>;

  getSalaryBonuses(month: string): Promise<SalaryBonus[]>;
  createSalaryBonus(bonus: InsertSalaryBonus): Promise<SalaryBonus>;
  deleteSalaryBonus(id: string): Promise<void>;

  getPartners(): Promise<Partner[]>;
  createPartner(partner: InsertPartner): Promise<Partner>;
  updatePartner(id: string, data: Partial<InsertPartner>): Promise<Partner>;
  deletePartner(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = randomUUID();
    const result = await db.insert(users).values({ ...user, id }).returning();
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async updateUserResetToken(id: string, token: string | null, expiry: Date | null): Promise<void> {
    await db.update(users).set({ resetToken: token, resetTokenExpiry: expiry } as any).where(eq(users.id, id));
  }

  async updateUserPassword(id: string, hashedPassword: string): Promise<void> {
    await db.update(users).set({ password: hashedPassword, resetToken: null, resetTokenExpiry: null } as any).where(eq(users.id, id));
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async getClients(): Promise<Client[]> {
    return db.select().from(clients).orderBy(desc(clients.createdAt));
  }

  async getClient(id: string): Promise<Client | undefined> {
    const result = await db.select().from(clients).where(eq(clients.id, id));
    return result[0];
  }

  async createClient(client: InsertClient): Promise<Client> {
    const id = randomUUID();
    const result = await db.insert(clients).values({ ...client, id }).returning();
    return result[0];
  }

  async updateClient(id: string, client: Partial<InsertClient>): Promise<Client> {
    const result = await db.update(clients).set(client).where(eq(clients.id, id)).returning();
    return result[0];
  }

  async deleteClient(id: string): Promise<void> {
    await db.delete(clients).where(eq(clients.id, id));
  }

  async getProjects(): Promise<Project[]> {
    return db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProjectsByClient(clientId: string): Promise<Project[]> {
    return db.select().from(projects).where(eq(projects.clientId, clientId)).orderBy(desc(projects.createdAt));
  }

  async getProject(id: string): Promise<Project | undefined> {
    const result = await db.select().from(projects).where(eq(projects.id, id));
    return result[0];
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = randomUUID();
    const result = await db.insert(projects).values({ ...project, id }).returning();
    return result[0];
  }

  async updateProject(id: string, project: Partial<InsertProject>): Promise<Project> {
    const result = await db.update(projects).set(project).where(eq(projects.id, id)).returning();
    return result[0];
  }

  async deleteProject(id: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  async getProjectPhases(projectId: string): Promise<ProjectPhase[]> {
    return db.select().from(projectPhases).where(eq(projectPhases.projectId, projectId)).orderBy(projectPhases.phaseOrder);
  }

  async getPhaseById(id: string): Promise<ProjectPhase | undefined> {
    const result = await db.select().from(projectPhases).where(eq(projectPhases.id, id));
    return result[0];
  }

  async createPhase(phase: InsertPhase): Promise<ProjectPhase> {
    const id = randomUUID();
    const result = await db.insert(projectPhases).values({ ...phase, id }).returning();
    return result[0];
  }

  async updatePhase(id: string, phase: Partial<InsertPhase>): Promise<ProjectPhase> {
    const result = await db.update(projectPhases).set(phase).where(eq(projectPhases.id, id)).returning();
    return result[0];
  }

  async getPayments(projectId: string): Promise<Payment[]> {
    return db.select().from(payments).where(eq(payments.projectId, projectId)).orderBy(payments.paymentNumber);
  }

  async getAllPayments(): Promise<Payment[]> {
    return db.select().from(payments).orderBy(desc(payments.dueDate));
  }

  async getPaymentById(id: string): Promise<Payment | undefined> {
    const result = await db.select().from(payments).where(eq(payments.id, id));
    return result[0];
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const id = randomUUID();
    const result = await db.insert(payments).values({ ...payment, id }).returning();
    return result[0];
  }

  async updatePayment(id: string, payment: Partial<InsertPayment>): Promise<Payment> {
    const result = await db.update(payments).set(payment).where(eq(payments.id, id)).returning();
    return result[0];
  }

  async getEmployees(): Promise<Employee[]> {
    return db.select().from(employees).orderBy(desc(employees.createdAt));
  }

  async getEmployee(id: string): Promise<Employee | undefined> {
    const result = await db.select().from(employees).where(eq(employees.id, id));
    return result[0];
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const id = randomUUID();
    const result = await db.insert(employees).values({ ...employee, id }).returning();
    return result[0];
  }

  async updateEmployee(id: string, employee: Partial<InsertEmployee>): Promise<Employee> {
    const result = await db.update(employees).set(employee).where(eq(employees.id, id)).returning();
    return result[0];
  }

  async deleteEmployee(id: string): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  async getTasks(): Promise<Task[]> {
    return db.select().from(tasks).orderBy(desc(tasks.createdAt));
  }

  async getTask(id: string): Promise<Task | undefined> {
    const result = await db.select().from(tasks).where(eq(tasks.id, id));
    return result[0];
  }

  async getTasksByProject(projectId: string): Promise<Task[]> {
    return db.select().from(tasks).where(eq(tasks.projectId, projectId));
  }

  async getTasksByEmployee(employeeId: string): Promise<Task[]> {
    return db.select().from(tasks).where(eq(tasks.employeeId, employeeId));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const id = randomUUID();
    const result = await db.insert(tasks).values({ ...task, id }).returning();
    return result[0];
  }

  async updateTask(id: string, task: Partial<InsertTask>): Promise<Task> {
    const result = await db.update(tasks).set(task).where(eq(tasks.id, id)).returning();
    return result[0];
  }

  async deleteTask(id: string): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  async getContracts(): Promise<Contract[]> {
    return db.select().from(contracts).orderBy(desc(contracts.createdAt));
  }

  async getContract(projectId: string): Promise<Contract | undefined> {
    const result = await db.select().from(contracts).where(eq(contracts.projectId, projectId));
    return result[0];
  }

  async createContract(contract: InsertContract): Promise<Contract> {
    const id = randomUUID();
    const result = await db.insert(contracts).values({ ...contract, id }).returning();
    return result[0];
  }

  async updateContract(id: string, contract: Partial<InsertContract>): Promise<Contract> {
    const result = await db.update(contracts).set(contract).where(eq(contracts.id, id)).returning();
    return result[0];
  }

  async getContractTerms(contractId: string): Promise<ContractTerm[]> {
    return db.select().from(contractTerms).where(eq(contractTerms.contractId, contractId)).orderBy(contractTerms.termOrder);
  }

  async createContractTerm(term: InsertContractTerm): Promise<ContractTerm> {
    const id = randomUUID();
    const result = await db.insert(contractTerms).values({ ...term, id }).returning();
    return result[0];
  }

  async updateContractTerm(id: string, data: Partial<InsertContractTerm>): Promise<ContractTerm> {
    const result = await db.update(contractTerms).set(data).where(eq(contractTerms.id, id)).returning();
    return result[0];
  }

  async deleteContractTerm(id: string): Promise<void> {
    await db.delete(contractTerms).where(eq(contractTerms.id, id));
  }

  async getAllAssignments(): Promise<EmployeeAssignment[]> {
    return db.select().from(employeeAssignments);
  }

  async getAssignments(projectId: string): Promise<EmployeeAssignment[]> {
    return db.select().from(employeeAssignments).where(eq(employeeAssignments.projectId, projectId));
  }

  async createAssignment(assignment: InsertAssignment): Promise<EmployeeAssignment> {
    const id = randomUUID();
    const result = await db.insert(employeeAssignments).values({ ...assignment, id }).returning();
    return result[0];
  }

  async updateAssignment(id: string, assignment: Partial<InsertAssignment>): Promise<EmployeeAssignment> {
    const result = await db.update(employeeAssignments).set(assignment).where(eq(employeeAssignments.id, id)).returning();
    return result[0];
  }

  async deleteAssignment(id: string): Promise<void> {
    await db.delete(employeeAssignments).where(eq(employeeAssignments.id, id));
  }

  async getAttendance(employeeId: string): Promise<Attendance[]> {
    return db.select().from(attendance).where(eq(attendance.employeeId, employeeId)).orderBy(desc(attendance.date));
  }

  async getAllAttendance(): Promise<Attendance[]> {
    return db.select().from(attendance).orderBy(desc(attendance.date));
  }

  async createAttendance(att: InsertAttendance): Promise<Attendance> {
    const id = randomUUID();
    const result = await db.insert(attendance).values({ ...att, id }).returning();
    return result[0];
  }

  async getDashboardStats(): Promise<any> {
    const allProjects = await db.select().from(projects);
    const allClients = await db.select().from(clients);
    const allEmployees = await db.select().from(employees);
    const allPayments = await db.select().from(payments);
    const allTasks = await db.select().from(tasks);

    const activeProjects = allProjects.filter(p => p.status === "active").length;
    const completedProjects = allProjects.filter(p => p.status === "completed").length;
    const totalRevenue = allPayments.filter(p => p.status === "paid").reduce((sum, p) => sum + (p.amount || 0), 0);
    const pendingRevenue = allPayments.filter(p => p.status === "pending").reduce((sum, p) => sum + (p.amount || 0), 0);
    const pendingTasks = allTasks.filter(t => t.status === "pending" || t.status === "in_progress").length;

    return {
      totalProjects: allProjects.length,
      activeProjects,
      completedProjects,
      totalClients: allClients.length,
      totalEmployees: allEmployees.filter(e => e.isActive).length,
      totalRevenue,
      pendingRevenue,
      pendingTasks,
    };
  }

  async getUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUser(id: string, data: Partial<any>): Promise<User> {
    const result = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return result[0];
  }

  async getProjectsByEmployee(employeeId: string): Promise<Project[]> {
    const assigns = await db.select().from(employeeAssignments).where(eq(employeeAssignments.employeeId, employeeId));
    const projectIds = assigns.map(a => a.projectId);
    if (projectIds.length === 0) return [];
    const allProjects = await db.select().from(projects);
    return allProjects.filter(p => projectIds.includes(p.id));
  }

  async getAssignmentsByEmployee(employeeId: string): Promise<EmployeeAssignment[]> {
    return db.select().from(employeeAssignments).where(eq(employeeAssignments.employeeId, employeeId));
  }

  async getEmployeeDashboardStats(employeeId: string): Promise<any> {
    const assigns = await db.select().from(employeeAssignments).where(eq(employeeAssignments.employeeId, employeeId));
    const projectIds = assigns.map(a => a.projectId);
    const myProjects = projectIds.length > 0
      ? (await db.select().from(projects)).filter(p => projectIds.includes(p.id))
      : [];
    const myTasks = await db.select().from(tasks).where(eq(tasks.employeeId, employeeId));
    const activeProjects = myProjects.filter(p => p.status === "active").length;
    const completedProjects = myProjects.filter(p => p.status === "completed").length;
    const pendingTasks = myTasks.filter(t => t.status === "pending" || t.status === "in_progress").length;
    const completedTasks = myTasks.filter(t => t.status === "completed").length;
    const totalAssigned = assigns.reduce((sum, a) => sum + (a.assignedAmount || 0), 0);
    const paidAmount = assigns.filter(a => a.isPaid).reduce((sum, a) => sum + (a.assignedAmount || 0), 0);

    return {
      totalProjects: myProjects.length,
      activeProjects,
      completedProjects,
      totalTasks: myTasks.length,
      pendingTasks,
      completedTasks,
      totalAssigned,
      paidAmount,
    };
  }

  async getAvailability(employeeId: string): Promise<AvailabilityScheduleType[]> {
    return db.select().from(availabilitySchedule).where(eq(availabilitySchedule.employeeId, employeeId)).orderBy(availabilitySchedule.date);
  }

  async getAllAvailability(): Promise<AvailabilityScheduleType[]> {
    return db.select().from(availabilitySchedule).orderBy(availabilitySchedule.date);
  }

  async upsertAvailability(data: InsertAvailability): Promise<AvailabilityScheduleType> {
    const existing = await db.select().from(availabilitySchedule)
      .where(and(eq(availabilitySchedule.employeeId, data.employeeId), eq(availabilitySchedule.date, data.date)));
    if (existing.length > 0) {
      const result = await db.update(availabilitySchedule).set(data).where(eq(availabilitySchedule.id, existing[0].id)).returning();
      return result[0];
    }
    const id = randomUUID();
    const result = await db.insert(availabilitySchedule).values({ ...data, id }).returning();
    return result[0];
  }

  async deleteAvailability(id: string): Promise<void> {
    await db.delete(availabilitySchedule).where(eq(availabilitySchedule.id, id));
  }

  async getCapacitySettings(): Promise<CapacitySettingsType | undefined> {
    const result = await db.select().from(capacitySettings);
    return result[0];
  }

  async updateCapacitySettings(id: string, data: Partial<InsertCapacitySettings>): Promise<CapacitySettingsType> {
    const result = await db.update(capacitySettings).set(data).where(eq(capacitySettings.id, id)).returning();
    return result[0];
  }

  async getEmployeeCapacityInfo(employeeId: string): Promise<any> {
    const assigns = await db.select().from(employeeAssignments).where(eq(employeeAssignments.employeeId, employeeId));
    const projectIds = assigns.map(a => a.projectId);
    const allProjects = projectIds.length > 0
      ? (await db.select().from(projects)).filter(p => projectIds.includes(p.id) && p.status === "active")
      : [];
    const settings = await this.getCapacitySettings();
    const threshold = settings?.largeProjectThreshold || 300;
    const largeActive = allProjects.filter(p => (p.areaSqm || 0) >= threshold);
    const maxLarge = settings?.maxLargeProjects || 2;

    return {
      activeProjects: allProjects.length,
      largeActiveProjects: largeActive.length,
      maxLargeProjects: maxLarge,
      canTakeLargeProject: largeActive.length < maxLarge,
      threshold,
      projects: allProjects.map(p => ({ id: p.id, title: p.title, areaSqm: p.areaSqm, status: p.status })),
    };
  }
  async getFieldVisits(projectId: string): Promise<FieldVisit[]> {
    return db.select().from(fieldVisits).where(eq(fieldVisits.projectId, projectId)).orderBy(desc(fieldVisits.visitDate));
  }

  async createFieldVisit(visit: InsertFieldVisit): Promise<FieldVisit> {
    const id = randomUUID();
    const result = await db.insert(fieldVisits).values({ ...visit, id }).returning();
    return result[0];
  }

  async updateFieldVisit(id: string, visit: Partial<InsertFieldVisit>): Promise<FieldVisit> {
    const result = await db.update(fieldVisits).set(visit).where(eq(fieldVisits.id, id)).returning();
    return result[0];
  }

  async deleteFieldVisit(id: string): Promise<void> {
    await db.delete(fieldVisits).where(eq(fieldVisits.id, id));
  }

  async getProjectFiles(projectId: string): Promise<ProjectFile[]> {
    return db.select().from(projectFiles).where(eq(projectFiles.projectId, projectId)).orderBy(desc(projectFiles.createdAt));
  }

  async createProjectFile(file: InsertProjectFile): Promise<ProjectFile> {
    const id = randomUUID();
    const result = await db.insert(projectFiles).values({ ...file, id }).returning();
    return result[0];
  }

  async deleteProjectFile(id: string): Promise<void> {
    await db.delete(projectFiles).where(eq(projectFiles.id, id));
  }

  async getMarketingContacts(): Promise<MarketingContact[]> {
    return db.select().from(marketingContacts).orderBy(desc(marketingContacts.createdAt));
  }

  async getMarketingContact(id: string): Promise<MarketingContact | undefined> {
    const result = await db.select().from(marketingContacts).where(eq(marketingContacts.id, id));
    return result[0];
  }

  async createMarketingContact(contact: InsertMarketingContact): Promise<MarketingContact> {
    const id = randomUUID();
    const result = await db.insert(marketingContacts).values({ ...contact, id }).returning();
    return result[0];
  }

  async updateMarketingContact(id: string, contact: Partial<InsertMarketingContact>): Promise<MarketingContact> {
    const result = await db.update(marketingContacts).set(contact).where(eq(marketingContacts.id, id)).returning();
    return result[0];
  }

  async deleteMarketingContact(id: string): Promise<void> {
    await db.delete(marketingContacts).where(eq(marketingContacts.id, id));
  }

  async getNotifications(employeeId?: string): Promise<Notification[]> {
    if (employeeId) {
      return db.select().from(notifications).where(eq(notifications.employeeId, employeeId)).orderBy(desc(notifications.createdAt));
    }
    return db.select().from(notifications).orderBy(desc(notifications.createdAt));
  }

  async getUnreadNotifications(employeeId?: string): Promise<Notification[]> {
    if (employeeId) {
      return db.select().from(notifications).where(and(eq(notifications.isRead, false), eq(notifications.employeeId, employeeId))).orderBy(desc(notifications.createdAt));
    }
    return db.select().from(notifications).where(eq(notifications.isRead, false)).orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const id = randomUUID();
    const result = await db.insert(notifications).values({ ...notification, id }).returning();
    return result[0];
  }

  async markNotificationRead(id: string): Promise<Notification> {
    const result = await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id)).returning();
    return result[0];
  }

  async markAllNotificationsRead(employeeId?: string): Promise<void> {
    if (employeeId) {
      await db.update(notifications).set({ isRead: true }).where(and(eq(notifications.isRead, false), eq(notifications.employeeId, employeeId)));
    } else {
      await db.update(notifications).set({ isRead: true }).where(eq(notifications.isRead, false));
    }
  }

  async getFinancialCommitments(month?: string): Promise<any[]> {
    if (month) {
      return db.select().from(financialCommitments).where(eq(financialCommitments.month, month)).orderBy(desc(financialCommitments.createdAt));
    }
    return db.select().from(financialCommitments).orderBy(desc(financialCommitments.createdAt));
  }

  async createFinancialCommitment(commitment: any): Promise<any> {
    const id = randomUUID();
    const result = await db.insert(financialCommitments).values({ ...commitment, id }).returning();
    return result[0];
  }

  async deleteFinancialCommitment(id: string): Promise<void> {
    await db.delete(financialCommitments).where(eq(financialCommitments.id, id));
  }

  async getFreelancerRates(employeeId: string): Promise<FreelancerRate[]> {
    return db.select().from(freelancerRates).where(eq(freelancerRates.employeeId, employeeId));
  }

  async createFreelancerRate(rate: InsertFreelancerRate): Promise<FreelancerRate> {
    const id = randomUUID();
    const result = await db.insert(freelancerRates).values({ ...rate, id }).returning();
    return result[0];
  }

  async updateFreelancerRate(id: string, data: Partial<InsertFreelancerRate>): Promise<FreelancerRate> {
    const result = await db.update(freelancerRates).set(data).where(eq(freelancerRates.id, id)).returning();
    return result[0];
  }

  async deleteFreelancerRate(id: string): Promise<void> {
    await db.delete(freelancerRates).where(eq(freelancerRates.id, id));
  }

  async getSalaryDeductions(month: string): Promise<SalaryDeduction[]> {
    return db.select().from(salaryDeductions).where(eq(salaryDeductions.month, month)).orderBy(desc(salaryDeductions.createdAt));
  }

  async createSalaryDeduction(deduction: InsertSalaryDeduction): Promise<SalaryDeduction> {
    const id = randomUUID();
    const result = await db.insert(salaryDeductions).values({ ...deduction, id }).returning();
    return result[0];
  }

  async deleteSalaryDeduction(id: string): Promise<void> {
    await db.delete(salaryDeductions).where(eq(salaryDeductions.id, id));
  }

  async getSalaryBonuses(month: string): Promise<SalaryBonus[]> {
    return db.select().from(salaryBonuses).where(eq(salaryBonuses.month, month)).orderBy(desc(salaryBonuses.createdAt));
  }

  async createSalaryBonus(bonus: InsertSalaryBonus): Promise<SalaryBonus> {
    const id = randomUUID();
    const result = await db.insert(salaryBonuses).values({ ...bonus, id }).returning();
    return result[0];
  }

  async deleteSalaryBonus(id: string): Promise<void> {
    await db.delete(salaryBonuses).where(eq(salaryBonuses.id, id));
  }

  async getPartners(): Promise<Partner[]> {
    return db.select().from(partners).orderBy(partners.name);
  }

  async createPartner(partner: InsertPartner): Promise<Partner> {
    const id = randomUUID();
    const result = await db.insert(partners).values({ ...partner, id }).returning();
    return result[0];
  }

  async updatePartner(id: string, data: Partial<InsertPartner>): Promise<Partner> {
    const result = await db.update(partners).set(data).where(eq(partners.id, id)).returning();
    return result[0];
  }

  async deletePartner(id: string): Promise<void> {
    await db.delete(partners).where(eq(partners.id, id));
  }
}

export const storage = new DatabaseStorage();
