import { storage } from "./storage";

async function createProjectWithDefaults(projectData: any) {
  const project = await storage.createProject(projectData);

  const phases = projectData.projectType === "exterior"
    ? [
        { name: "الهيكل الإنشائي (الوضع الحالي)", order: 1, timePct: 35 },
        { name: "المناقشة لأخذ الطلبات", order: 2, timePct: 60 },
        { name: "التصميم", order: 3, timePct: 60 },
        { name: "المخططات التنفيذية", order: 4, timePct: 90 },
      ]
    : [
        { name: "المخطط (ثابت الوضع المحلي)", order: 1, timePct: 35 },
        { name: "المناقشة لأخذ الطلبات", order: 2, timePct: 35 },
        { name: "لوحة الأفكار", order: 3, timePct: 60 },
        { name: "التصميم الأولي والنهائي", order: 4, timePct: 60 },
        { name: "المخطط التنفيذي", order: 5, timePct: 90 },
      ];

  const createdPhases = [];
  for (const ph of phases) {
    const phase = await storage.createPhase({
      projectId: project.id,
      phaseName: ph.name,
      phaseOrder: ph.order,
      status: "pending",
      timePercentage: ph.timePct,
      dueDate: null,
      completionDate: null,
      notes: null,
      isApproved: false,
    });
    createdPhases.push(phase);
  }

  const total = projectData.totalValue;
  const paymentDefs = [
    { num: 1, pct: 50, type: "عند توقيع العقد", amount: total * 0.50 },
    { num: 2, pct: 30, type: "عند اعتماد الهيكل الإنشائي", amount: total * 0.30 },
    { num: 3, pct: 20, type: "عند اعتماد التصميم", amount: total * 0.20 },
  ];

  const createdPayments = [];
  for (const pd of paymentDefs) {
    const payment = await storage.createPayment({
      projectId: project.id,
      paymentNumber: pd.num,
      amount: pd.amount,
      percentage: pd.pct,
      paymentType: pd.type,
      status: "pending",
      dueDate: null,
      paidDate: null,
      notes: null,
    });
    createdPayments.push(payment);
  }

  return { project, phases: createdPhases, payments: createdPayments };
}

export async function seedData() {
  try {
    const existingClients = await storage.getClients();
    if (existingClients.length > 0) {
      console.log("[seed] Data already exists, skipping seed.");
      return;
    }

    console.log("[seed] Seeding initial data...");

    const client1 = await storage.createClient({
      name: "عبدالرحمن الغامدي",
      phone: "0501234567",
      email: "abdulrahman@gmail.com",
      city: "الرياض",
      notes: "عميل مميز، يفضل التواصل عبر الواتساب",
    });

    const client2 = await storage.createClient({
      name: "سارة المطيري",
      phone: "0551234567",
      email: "sara.m@hotmail.com",
      city: "جدة",
      notes: "مشروع فيلا سكنية كاملة",
    });

    const client3 = await storage.createClient({
      name: "محمد الحربي",
      phone: "0561234567",
      email: null,
      city: "الدمام",
      notes: "مؤسسة تجارية، تصميم واجهات المبنى",
    });

    const client4 = await storage.createClient({
      name: "نوف القحطاني",
      phone: "0591234567",
      email: "nouf.q@gmail.com",
      city: "الرياض",
      notes: null,
    });

    const emp1 = await storage.createEmployee({
      name: "أحمد العتيبي",
      specialty: "مصمم داخلي",
      department: "قسم التصميم الداخلي",
      employeeType: "internal",
      designPercentage: 10,
      executivePercentage: 7,
      structuralPercentage: 5,
      pricePerSqm: null,
      contractStartDate: "2024-01-15",
      phone: "0512345678",
      bankAccount: "SA1234567890123456789012",
      isActive: true,
      notes: null,
    });

    const emp2 = await storage.createEmployee({
      name: "ليلى الزهراني",
      specialty: "مصممة خارجية",
      department: "قسم التصميم الخارجي",
      employeeType: "internal",
      designPercentage: 10,
      executivePercentage: 7,
      structuralPercentage: 5,
      pricePerSqm: null,
      contractStartDate: "2023-06-01",
      phone: "0523456789",
      bankAccount: "SA9876543210987654321098",
      isActive: true,
      notes: null,
    });

    const emp3 = await storage.createEmployee({
      name: "خالد المالكي",
      specialty: "رسام مخططات تنفيذية",
      department: null,
      employeeType: "freelancer",
      designPercentage: null,
      executivePercentage: null,
      structuralPercentage: null,
      pricePerSqm: 50,
      contractStartDate: "2024-03-01",
      phone: "0534567890",
      bankAccount: "SA1111222233334444555566",
      isActive: true,
      notes: "متخصص في المخططات التنفيذية للواجهات",
    });

    // Project 1 - Exterior Active
    const { project: proj1, phases: phases1, payments: pays1 } = await createProjectWithDefaults({
      clientId: client1.id,
      projectType: "exterior",
      title: "فيلا الغامدي - الرياض",
      description: "تصميم واجهة فيلا سكنية حديثة",
      areaSqm: 350,
      pricePerSqm: 200,
      totalValue: 70000,
      status: "active",
      location: "الرياض، حي النرجس",
      startDate: "2026-01-15",
      endDate: "2026-06-30",
    });

    // Project 2 - Interior Active
    const { project: proj2, phases: phases2, payments: pays2 } = await createProjectWithDefaults({
      clientId: client2.id,
      projectType: "interior",
      title: "فيلا المطيري - جدة",
      description: "تصميم داخلي متكامل لفيلا سكنية فاخرة",
      areaSqm: 500,
      pricePerSqm: 300,
      totalValue: 150000,
      status: "active",
      location: "جدة، حي الروضة",
      startDate: "2026-02-01",
      endDate: "2026-08-01",
    });

    // Project 3 - Exterior Completed
    const { project: proj3, phases: phases3, payments: pays3 } = await createProjectWithDefaults({
      clientId: client3.id,
      projectType: "exterior",
      title: "مبنى الحربي التجاري - الدمام",
      description: "تصميم واجهة مبنى تجاري حديث",
      areaSqm: 800,
      pricePerSqm: 180,
      totalValue: 144000,
      status: "completed",
      location: "الدمام، حي الشاطئ",
      startDate: "2025-06-01",
      endDate: "2025-12-31",
    });

    // Project 4 - Interior Active
    const { project: proj4, phases: phases4, payments: pays4 } = await createProjectWithDefaults({
      clientId: client4.id,
      projectType: "interior",
      title: "شقة القحطاني - الرياض",
      description: "تصميم داخلي لشقة عصرية",
      areaSqm: 180,
      pricePerSqm: 280,
      totalValue: 50400,
      status: "active",
      location: "الرياض، حي الملقا",
      startDate: "2026-02-15",
      endDate: "2026-05-15",
    });

    // Mark proj3 phases as completed
    for (const ph of phases3) {
      await storage.updatePhase(ph.id, { status: "completed", isApproved: true });
    }

    // Mark first two phases of proj1 as done
    if (phases1[0]) await storage.updatePhase(phases1[0].id, { status: "completed", isApproved: true });
    if (phases1[1]) await storage.updatePhase(phases1[1].id, { status: "in_progress" });

    // Mark first phase of proj2 as done
    if (phases2[0]) await storage.updatePhase(phases2[0].id, { status: "completed", isApproved: true });

    // Mark all proj3 payments as paid
    for (const pay of pays3) {
      await storage.updatePayment(pay.id, { status: "paid", paidDate: "2025-12-01" });
    }

    // Mark first payment of proj1 as paid
    if (pays1[0]) await storage.updatePayment(pays1[0].id, { status: "paid", paidDate: "2026-01-15" });

    // Mark first payment of proj2 as paid
    if (pays2[0]) await storage.updatePayment(pays2[0].id, { status: "paid", paidDate: "2026-02-01" });

    // Assign employees
    await storage.createAssignment({
      projectId: proj1.id, employeeId: emp2.id,
      role: "مصممة رئيسية", assignedAmount: 7000, isPaid: false,
    });

    await storage.createAssignment({
      projectId: proj2.id, employeeId: emp1.id,
      role: "مصمم داخلي", assignedAmount: 15000, isPaid: false,
    });

    await storage.createAssignment({
      projectId: proj3.id, employeeId: emp2.id,
      role: "مصممة خارجية", assignedAmount: 14400, isPaid: true,
    });

    await storage.createAssignment({
      projectId: proj3.id, employeeId: emp3.id,
      role: "رسام مخططات", assignedAmount: 8000, isPaid: true,
    });

    await storage.createAssignment({
      projectId: proj4.id, employeeId: emp1.id,
      role: "مصمم داخلي", assignedAmount: 5040, isPaid: false,
    });

    // Tasks
    await storage.createTask({
      projectId: proj1.id, employeeId: emp2.id,
      title: "تسليم لوحة الأفكار الأولية",
      description: "تحضير لوحة الأفكار وعرضها على العميل",
      priority: "high", status: "in_progress",
      dueDate: "2026-03-01", reminderDays: 5, isRecurring: false, notes: null,
    });

    await storage.createTask({
      projectId: proj2.id, employeeId: emp1.id,
      title: "إعداد المخطط التنفيذي للطابق الأرضي",
      description: null, priority: "high", status: "pending",
      dueDate: "2026-03-15", reminderDays: 7, isRecurring: false, notes: null,
    });

    await storage.createTask({
      projectId: proj4.id, employeeId: emp1.id,
      title: "زيارة ميدانية لقياس المساحات",
      description: "قياس دقيق لجميع الغرف والمساحات",
      priority: "medium", status: "pending",
      dueDate: "2026-02-25", reminderDays: 3, isRecurring: false, notes: null,
    });

    await storage.createTask({
      projectId: null, employeeId: null,
      title: "مراجعة الفواتير الشهرية",
      description: "مراجعة جميع فواتير شهر فبراير",
      priority: "medium", status: "pending",
      dueDate: "2026-02-28", reminderDays: 3, isRecurring: true, notes: null,
    });

    await storage.createTask({
      projectId: proj3.id, employeeId: emp2.id,
      title: "تسليم الملف الكامل للمشروع للعميل",
      description: null, priority: "low", status: "completed",
      dueDate: "2025-12-31", reminderDays: 3, isRecurring: false, notes: null,
    });

    // Contracts
    await storage.createContract({
      projectId: proj3.id, contractNumber: "C-2025-001",
      contractDate: "2025-06-01", clientSigned: true, companySigned: true,
      terms: "تلتزم المؤسسة بتسليم التصميم في المدة المحددة، وتشمل الخدمة التصميم الكامل للواجهات الخارجية بما فيها النماذج الثلاثية الأبعاد والمخططات التنفيذية.",
      specialConditions: "يتم تسليم الأعمال على ثلاث مراحل حسب الجدول الزمني المتفق عليه.",
      notes: null,
    });

    await storage.createContract({
      projectId: proj1.id, contractNumber: "C-2026-001",
      contractDate: "2026-01-15", clientSigned: true, companySigned: true,
      terms: "يشمل العقد تصميم الواجهة الخارجية الكاملة للفيلا مع المخططات التنفيذية.",
      specialConditions: null, notes: null,
    });

    // Attendance
    await storage.createAttendance({ employeeId: emp1.id, date: "2026-02-24", status: "present", notes: null });
    await storage.createAttendance({ employeeId: emp2.id, date: "2026-02-24", status: "present", notes: null });
    await storage.createAttendance({ employeeId: emp1.id, date: "2026-02-23", status: "present", notes: null });
    await storage.createAttendance({ employeeId: emp2.id, date: "2026-02-23", status: "late", notes: "تأخر 30 دقيقة" });

    console.log("[seed] Seed data created successfully!");
  } catch (error) {
    console.error("[seed] Error seeding data:", error);
  }
}
